export interface NodeData {
  label: string;
  description: string;
}

export interface AgentNodeData extends NodeData {
  type?: 'agent';
  config?: any;
}

export interface ToolNodeData extends NodeData {
  type?: 'tool';
  apiEndpoint?: string;
  config?: any;
}

export interface DataSourceNodeData extends NodeData {
  type?: 'dataSource';
  connectionString?: string;
  config?: any;
}

export interface DecisionNodeData extends NodeData {
  type?: 'decision';
  condition?: string;
  config?: any;
}