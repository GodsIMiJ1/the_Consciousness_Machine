import { useCallback } from 'react';
import {
  ReactFlow,
  addEdge,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  Connection,
  Edge,
  Node,
  BackgroundVariant,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import { AgentNode } from './nodes/AgentNode';
import { ToolNode } from './nodes/ToolNode';
import { DataSourceNode } from './nodes/DataSourceNode';
import { DecisionNode } from './nodes/DecisionNode';

const nodeTypes = {
  agent: AgentNode,
  tool: ToolNode,
  dataSource: DataSourceNode,
  decision: DecisionNode,
};

const initialNodes: Node[] = [
  {
    id: 'demo-agent',
    type: 'agent',
    position: { x: 300, y: 100 },
    data: { 
      label: 'Support Agent',
      description: 'Handles customer support queries'
    },
  },
  {
    id: 'demo-tool',
    type: 'tool',
    position: { x: 100, y: 250 },
    data: { 
      label: 'FAQ Search',
      description: 'Searches knowledge base'
    },
  },
  {
    id: 'demo-data',
    type: 'dataSource',
    position: { x: 500, y: 250 },
    data: { 
      label: 'Postgres DB',
      description: 'Customer data storage'
    },
  },
];

const initialEdges: Edge[] = [
  {
    id: 'e1-2',
    source: 'demo-agent',
    target: 'demo-tool',
    type: 'smoothstep',
    animated: true,
  },
  {
    id: 'e1-3',
    source: 'demo-agent',
    target: 'demo-data',
    type: 'smoothstep',
  },
];

export const WorkbenchCanvas = () => {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges],
  );

  return (
    <div className="flex-1 bg-workbench-canvas">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={nodeTypes}
        fitView
        className="workbench-flow"
        proOptions={{ hideAttribution: true }}
      >
        <Background 
          variant={BackgroundVariant.Dots} 
          gap={20} 
          size={1}
          className="bg-workbench-canvas"
        />
        <Controls className="workbench-controls" />
        <MiniMap 
          className="workbench-minimap"
          maskColor="hsl(215 25% 8% / 0.8)"
          nodeColor="#3b82f6"
        />
      </ReactFlow>
    </div>
  );
};