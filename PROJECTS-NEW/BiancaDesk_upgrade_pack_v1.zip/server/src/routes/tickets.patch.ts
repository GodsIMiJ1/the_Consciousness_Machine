// PATCH for server/src/routes/tickets.ts
// Add optional webhook escalation on ticket creation if urgent.
import { Router } from 'express'
import { nanoid } from 'nanoid'
import fs from 'fs'
import path from 'path'
import fetch from 'node-fetch'

export const router = Router()
const storeDir = path.join(process.cwd(), 'server', 'storage')
if (!fs.existsSync(storeDir)) fs.mkdirSync(storeDir, { recursive: true })

const webhook = process.env.ESCALATION_WEBHOOK || ''

router.get('/', async (req, res) => {
  const files = fs.readdirSync(storeDir).filter(f => f.endsWith('.json'))
  const records = files.map(f => JSON.parse(fs.readFileSync(path.join(storeDir, f), 'utf8')))
  records.sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))
  res.json(records)
})

router.post('/', async (req, res) => {
  const { summary, urgent } = req.body || {}
  const rec = {
    id: nanoid(),
    summary: (summary || '').slice(0, 500),
    urgent: Boolean(urgent) or /\burgent|escalate|critical\b/i.test(summary || ''),
    createdAt: new Date().toISOString()
  }
  fs.writeFileSync(path.join(storeDir, rec.id + '.json'), JSON.stringify(rec, null, 2), 'utf8')

  // Fire-and-forget webhook if urgent + configured
  if (rec.urgent && webhook) {
    try {
      await fetch(webhook, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'biancadesk.ticket.escalated',
          ticket: rec
        })
      })
    } catch {}
  }

  res.json(rec)
})
