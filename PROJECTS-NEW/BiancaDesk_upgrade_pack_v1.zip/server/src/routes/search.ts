import { Router } from 'express'
import fs from 'fs'
import path from 'path'

export const router = Router()

// Simple TF-IDF style search over kb/index.json
function tokenize(s) {
  return (s || '')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter(Boolean)
}

router.get('/', async (req, res) => {
  try {
    const q = String(req.query.q || '').trim()
    if (!q) return res.json({ query: q, results: [] })

    const kbPath = path.join(process.cwd(), 'kb', 'index.json')
    if (!fs.existsSync(kbPath)) return res.json({ query: q, results: [] })

    const { docs = [] } = JSON.parse(fs.readFileSync(kbPath, 'utf8'))
    const terms = tokenize(q)
    if (terms.length === 0) return res.json({ query: q, results: [] })

    // Build IDF map
    const df = {}
    for (const d of docs) {
      const seen = new Set(tokenize(d.content))
      for (const t of seen) df[t] = (df[t] || 0) + 1
    }
    const N = docs.length || 1
    const idf = {}
    for (const [t, c] of Object.entries(df)) {
      idf[t] = Math.log((N + 1) / (c + 1)) + 1
    }

    // Score each doc: sum(idf(term) * termFreqInDoc)
    const scores = docs.map((d, idx) => {
      const toks = tokenize(d.content)
      const tf = {}
      for (const t of toks) tf[t] = (tf[t] || 0) + 1
      let score = 0
      for (const t of terms) {
        score += (idf[t] || 0) * (tf[t] || 0)
      }
      return { idx, score }
    }).sort((a,b) => b.score - a.score)

    const results = scores.slice(0, 8).filter(r => r.score > 0).map(({ idx, score }) => {
      const d = docs[idx]
      return {
        id: d.id,
        title: d.title,
        excerpt: (d.content || '').slice(0, 400),
        updatedAt: d.updatedAt,
        score
      }
    })

    res.json({ query: q, results })
  } catch (e) {
    console.error('search error', e)
    res.json({ query: String(req.query.q || ''), results: [] })
  }
})
