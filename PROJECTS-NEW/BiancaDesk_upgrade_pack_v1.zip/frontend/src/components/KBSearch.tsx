import React, { useEffect, useState } from 'react'

type Hit = { id: string; title: string; excerpt: string; updatedAt: string; score: number }

export default function KBSearch() {
  const [q, setQ] = useState('')
  const [hits, setHits] = useState<Hit[]>([])
  const [loading, setLoading] = useState(false)

  const run = async () => {
    const query = q.trim()
    if (!query) { setHits([]); return }
    setLoading(true)
    try {
      const r = await fetch('/api/search?q=' + encodeURIComponent(query))
      const j = await r.json()
      setHits(j.results || [])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-[var(--panel)] border border-neutral-800 rounded-2xl p-4 space-y-3">
      <div className="flex gap-2">
        <input
          className="flex-1 bg-black/60 border border-neutral-800 rounded-xl px-3 py-2 outline-none focus:border-orange-500"
          placeholder="Search clinic policies, SOPs, and docs…"
          value={q}
          onChange={e => setQ(e.target.value)}
          onKeyDown={e => e.key === 'Enter' ? run() : undefined}
        />
        <button onClick={run} className="px-3 py-2 rounded-xl border border-neutral-800 hover:border-orange-500">Search</button>
      </div>
      <ul className="space-y-2">
        {hits.map(h => (
          <li key={h.id} className="text-sm bg-black/40 border border-neutral-800 rounded-lg p-3">
            <div className="font-medium text-neutral-100">{h.title}</div>
            <div className="text-xs text-neutral-400">{new Date(h.updatedAt).toLocaleString()} · score {h.score.toFixed(2)}</div>
            <div className="text-neutral-300 whitespace-pre-wrap mt-1">{h.excerpt}</div>
          </li>
        ))}
        {(!loading && hits.length === 0) && <div className="text-sm text-neutral-500">No results yet.</div>}
      </ul>
    </div>
  )
}
