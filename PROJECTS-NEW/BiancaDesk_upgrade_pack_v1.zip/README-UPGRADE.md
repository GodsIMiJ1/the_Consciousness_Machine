# BiancaDesk Upgrade Pack v1

This pack adds:
1) **KB search (RAG-lite)** over `/kb` (Markdown + optional PDFs)
2) **Escalation webhook** on urgent tickets
3) **KB search UI** wiring
4) **Nginx** + **systemd** samples

## Apply patches

### 1) Server
- Copy `server/src/routes/search.ts` into your project.
- Merge `server/src/routes/tickets.patch.ts` into `server/src/routes/tickets.ts` (replace file if you prefer).
- Edit `server/src/index.ts` and add:
  ```ts
  import { router as searchRouter } from './routes/search.js'
  app.use('/api/search', searchRouter)
  ```
- Append the new env var to `server/.env`:
  ```
  ESCALATION_WEBHOOK=
  ```

Install deps (for dev tooling only):
```
cd server && npm i node-fetch nanoid
npm run dev
```

### 2) Knowledge ingestion
- Put `.md` and `.pdf` files into `/kb`
- Install PDF parser (optional, for PDFs):
  ```
  npm i pdf-parse
  ```
- Run:
  ```
  node scripts/ingest-all.mjs --pdf   # include PDFs
  # or: node scripts/ingest-all.mjs   # MD only
  ```

### 3) Frontend
- Add the new component: copy `frontend/src/components/KBSearch.tsx`
- In `frontend/src/pages/App.tsx`, replace the KB placeholder with `<KBSearch />`.
- (Optional) In `ChatPanel.tsx`, add the "urgent" checkbox per `ChatPanel PATCH` notes.

### 4) Ops
- Use `ops/nginx.sample.conf` for your domain.
- Use `ops/biancadesk-server.service` to run server via systemd.

## Notes
- Search is TF-IDF style, fast and local. For full semantic RAG later, we can route embeddings through FlameRouter or a local model (Ollama) and add citation chunks.
- Webhook can point to Slack, Discord, email-gateway, etc. Only fires on urgent tickets.
- Keep PHI out of tickets; store references/IDs only.
