// Ingest Markdown and (optionally) PDFs into kb/index.json
// Usage:
//   node scripts/ingest-all.mjs             # MD only
//   node scripts/ingest-all.mjs --pdf       # include PDFs (requires `npm i pdf-parse`)
import fs from 'fs'
import path from 'path'

const kbDir = path.resolve('kb')
const out = path.join(kbDir, 'index.json')
const args = new Set(process.argv.slice(2))
const includePdf = args.has('--pdf')
let pdfParse = null

if (includePdf) {
  try {
    pdfParse = (await import('pdf-parse')).default
  } catch (e) {
    console.error('pdf-parse not installed. Run: npm i pdf-parse')
    process.exit(1)
  }
}

const files = fs.readdirSync(kbDir).filter(f => f.endsWith('.md') || (includePdf && f.endsWith('.pdf')))
const docs = []
for (const f of files) {
  const p = path.join(kbDir, f)
  let text = ''
  if (f.endsWith('.md')) {
    text = fs.readFileSync(p, 'utf8')
  } else if (f.endsWith('.pdf') && pdfParse) {
    const buf = fs.readFileSync(p)
    const data = await pdfParse(buf)
    text = data.text || ''
  }
  docs.push({
    id: f.replace(/\.(md|pdf)$/, ''),
    title: f.replace(/[-_]/g, ' ').replace(/\.(md|pdf)$/, ''),
    content: text,
    updatedAt: new Date().toISOString()
  })
}

fs.writeFileSync(out, JSON.stringify({ docs }, null, 2), 'utf8')
console.log('Wrote', out, 'with', docs.length, 'docs')
