import { defineConfig } from 'cypress'

export default defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
    baseUrl: 'http://localhost:5173',
    supportFile: 'cypress/support/e2e.ts',
    specPattern: 'cypress/e2e/**/*.cy.{js,jsx,ts,tsx}',
    viewportWidth: 1280,
    viewportHeight: 720,
    video: false,
    screenshotOnRunFailure: true,
    chromeWebSecurity: false
  },
  env: {
    SUPABASE_URL: 'https://wixzqilqithhlybhyite.supabase.co',
    SUPABASE_ANON_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndpeHpxaWxxaXRoaGx5Ymh5aXRlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY0MjE2NTksImV4cCI6MjA3MTk5NzY1OX0.XnAj1YksRuxvUjC4oLDQSN0mx-ArJOH23JhjUC5vWUQ'
  },
  component: {
    devServer: {
      framework: 'react',
      bundler: 'vite',
    },
  },
})