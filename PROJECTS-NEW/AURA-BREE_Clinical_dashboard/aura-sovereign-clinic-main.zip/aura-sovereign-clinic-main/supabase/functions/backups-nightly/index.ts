import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    console.log('Starting nightly backup process...');

    const backupDate = new Date().toISOString().split('T')[0];
    const timestamp = new Date().toISOString();

    // Fetch all critical data with pagination for large datasets
    console.log('Fetching patients data...');
    const { data: patients, error: patientsError } = await supabase
      .from('patients')
      .select('*')
      .order('created_at');

    if (patientsError) throw patientsError;

    console.log('Fetching staff data...');
    const { data: staff, error: staffError } = await supabase
      .from('staff')
      .select('*')
      .order('created_at');

    if (staffError) throw staffError;

    console.log('Fetching visits data...');
    const { data: visits, error: visitsError } = await supabase
      .from('visits')
      .select('*')
      .order('created_at');

    if (visitsError) throw visitsError;

    console.log('Fetching dosages data...');
    const { data: dosages, error: dosagesError } = await supabase
      .from('dosages')
      .select('*')
      .order('created_at');

    if (dosagesError) throw dosagesError;

    console.log('Fetching devices data...');
    const { data: devices, error: devicesError } = await supabase
      .from('devices')
      .select('*')
      .order('created_at');

    if (devicesError) throw devicesError;

    console.log('Fetching checkins data...');
    const { data: checkins, error: checkinsError } = await supabase
      .from('checkins')
      .select('*')
      .order('created_at');

    if (checkinsError) throw checkinsError;

    console.log('Fetching audit log (last 30 days)...');
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    const { data: auditLog, error: auditLogError } = await supabase
      .from('audit_log')
      .select('*')
      .gte('created_at', thirtyDaysAgo)
      .order('created_at');

    if (auditLogError) throw auditLogError;

    console.log('Fetching settings data...');
    const { data: settings, error: settingsError } = await supabase
      .from('settings')
      .select('*')
      .order('created_at');

    if (settingsError) throw settingsError;

    // Create comprehensive backup payload
    const backupData = {
      metadata: {
        created_at: timestamp,
        backup_date: backupDate,
        version: '1.0',
        clinic_name: 'Sovereign Methadone Clinic',
        record_counts: {
          patients: patients?.length || 0,
          staff: staff?.length || 0,
          visits: visits?.length || 0,
          dosages: dosages?.length || 0,
          devices: devices?.length || 0,
          checkins: checkins?.length || 0,
          audit_log: auditLog?.length || 0,
          settings: settings?.length || 0
        }
      },
      data: {
        patients: patients || [],
        staff: staff || [],
        visits: visits || [],
        dosages: dosages || [],
        devices: devices || [],
        checkins: checkins || [],
        audit_log: auditLog || [],
        settings: settings || []
      }
    };

    console.log('Backup data prepared:', {
      patients: backupData.metadata.record_counts.patients,
      staff: backupData.metadata.record_counts.staff,
      visits: backupData.metadata.record_counts.visits,
      dosages: backupData.metadata.record_counts.dosages,
      devices: backupData.metadata.record_counts.devices,
      checkins: backupData.metadata.record_counts.checkins,
      audit_log: backupData.metadata.record_counts.audit_log,
      settings: backupData.metadata.record_counts.settings
    });

    // Convert to JSON and compress (in production, add actual encryption here)
    const jsonData = JSON.stringify(backupData, null, 2);
    const compressedData = new TextEncoder().encode(jsonData);

    // Store the backup
    const fileName = `backup-${backupDate}.json`;
    const filePath = `daily/${fileName}`;
    
    console.log(`Uploading backup to: ${filePath}`);
    
    const { error: uploadError } = await supabase.storage
      .from('backups')
      .upload(filePath, compressedData, {
        contentType: 'application/json',
        upsert: true,
        metadata: {
          backup_date: backupDate,
          created_at: timestamp,
          record_count: Object.values(backupData.metadata.record_counts).reduce((a, b) => a + b, 0)
        }
      });

    if (uploadError) {
      console.error('Upload error:', uploadError);
      throw uploadError;
    }

    // Clean up old backups (keep last 30 days)
    const cleanupDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const cleanupDateStr = cleanupDate.toISOString().split('T')[0];
    
    console.log(`Cleaning up backups older than: ${cleanupDateStr}`);
    
    const { data: oldBackups } = await supabase.storage
      .from('backups')
      .list('daily', {
        limit: 100,
        sortBy: { column: 'name', order: 'asc' }
      });

    if (oldBackups) {
      const filesToDelete = oldBackups
        .filter(file => file.name.includes('backup-') && file.name < `backup-${cleanupDateStr}`)
        .map(file => `daily/${file.name}`);

      if (filesToDelete.length > 0) {
        console.log(`Deleting ${filesToDelete.length} old backup files`);
        const { error: deleteError } = await supabase.storage
          .from('backups')
          .remove(filesToDelete);
        
        if (deleteError) {
          console.error('Error deleting old backups:', deleteError);
        }
      }
    }

    // Log the backup completion
    const { error: auditError } = await supabase
      .from('audit_log')
      .insert({
        actor_type: 'system',
        actor_id: null,
        action: 'create',
        entity: 'backup',
        entity_id: fileName,
        summary: `Nightly backup completed: ${Object.values(backupData.metadata.record_counts).reduce((a, b) => a + b, 0)} total records backed up`
      });

    if (auditError) {
      console.error('Error logging backup to audit:', auditError);
    }

    console.log(`Backup completed successfully: ${filePath}`);

    return new Response(
      JSON.stringify({
        success: true,
        backup_path: filePath,
        backup_date: backupDate,
        records_backed_up: backupData.metadata.record_counts,
        file_size_bytes: compressedData.length,
        created_at: timestamp
      }),
      {
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        }
      }
    );

  } catch (error) {
    console.error('Backup process failed:', error);
    
    // Try to log the failure
    try {
      const supabase = createClient(
        Deno.env.get('SUPABASE_URL') ?? '',
        Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      );
      
      await supabase
        .from('audit_log')
        .insert({
          actor_type: 'system',
          actor_id: null,
          action: 'error',
          entity: 'backup',
          entity_id: 'nightly-backup-failed',
          summary: `Nightly backup failed: ${error.message}`
        });
    } catch (auditError) {
      console.error('Failed to log backup error:', auditError);
    }

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
        failed_at: new Date().toISOString()
      }),
      {
        status: 500,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        }
      }
    );
  }
});
