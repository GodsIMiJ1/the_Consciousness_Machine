import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface WeeklyMetrics {
  attendancePct: number;
  totalVisits: number;
  completedVisits: number;
  missedVisits: number;
  avgDosage: number;
  medianDosage: number;
  uniquePatients: number;
  period: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
    );

    console.log('Starting weekly compliance report generation...');

    // Calculate date range for last 7 days
    const endDate = new Date();
    const startDate = new Date(endDate.getTime() - 7 * 24 * 60 * 60 * 1000);
    const periodString = `${startDate.toISOString().split('T')[0]} to ${endDate.toISOString().split('T')[0]}`;

    console.log(`Analyzing period: ${periodString}`);

    // Fetch visits from last 7 days
    const { data: visits, error: visitsError } = await supabase
      .from('visits')
      .select('id, patient_id, triage_status, arrived_at, notes')
      .gte('arrived_at', startDate.toISOString())
      .lte('arrived_at', endDate.toISOString());

    if (visitsError) {
      console.error('Error fetching visits:', visitsError);
      throw visitsError;
    }

    // Fetch dosages from last 7 days
    const { data: dosages, error: dosagesError } = await supabase
      .from('dosages')
      .select('id, patient_id, dose_mg, administered_at, medication')
      .gte('administered_at', startDate.toISOString())
      .lte('administered_at', endDate.toISOString());

    if (dosagesError) {
      console.error('Error fetching dosages:', dosagesError);
      throw dosagesError;
    }

    console.log(`Found ${visits?.length || 0} visits and ${dosages?.length || 0} dosages`);

    // Calculate metrics
    const totalVisits = visits?.length || 0;
    const completedVisits = visits?.filter(v => v.triage_status === 'complete').length || 0;
    const missedVisits = visits?.filter(v => v.triage_status === 'no_show').length || 0;
    const attendancePct = totalVisits > 0 ? Math.round((completedVisits / totalVisits) * 100) : 0;

    const doses = (dosages || []).map(d => Number(d.dose_mg)).filter(d => !isNaN(d));
    const avgDosage = doses.length > 0 ? Math.round(doses.reduce((a, b) => a + b, 0) / doses.length) : 0;
    
    // Calculate median
    const sortedDoses = [...doses].sort((a, b) => a - b);
    const medianDosage = sortedDoses.length > 0 
      ? sortedDoses.length % 2 === 0 
        ? Math.round((sortedDoses[sortedDoses.length / 2 - 1] + sortedDoses[sortedDoses.length / 2]) / 2)
        : sortedDoses[Math.floor(sortedDoses.length / 2)]
      : 0;

    const uniquePatients = new Set([
      ...(visits || []).map(v => v.patient_id),
      ...(dosages || []).map(d => d.patient_id)
    ]).size;

    const metrics: WeeklyMetrics = {
      attendancePct,
      totalVisits,
      completedVisits,
      missedVisits,
      avgDosage,
      medianDosage,
      uniquePatients,
      period: periodString
    };

    console.log('Generated metrics:', metrics);

    // Store the report summary in audit log
    const { error: auditError } = await supabase
      .from('audit_log')
      .insert({
        actor_type: 'system',
        actor_id: null,
        action: 'generate',
        entity: 'weekly_compliance_report',
        entity_id: crypto.randomUUID(),
        summary: `Weekly compliance report generated for ${periodString}. Attendance: ${attendancePct}%, Total visits: ${totalVisits}, Unique patients: ${uniquePatients}`
      });

    if (auditError) {
      console.error('Error logging to audit:', auditError);
    }

    // Generate report file name
    const reportDate = endDate.toISOString().split('T')[0];
    const fileName = `weekly-compliance-${reportDate}.json`;

    // Store the detailed report in storage
    const reportData = {
      generated_at: new Date().toISOString(),
      period: {
        start: startDate.toISOString(),
        end: endDate.toISOString(),
        description: periodString
      },
      metrics,
      raw_data: {
        visits: visits || [],
        dosages: dosages || []
      }
    };

    const { error: storageError } = await supabase.storage
      .from('reports')
      .upload(`weekly/${fileName}`, JSON.stringify(reportData, null, 2), {
        contentType: 'application/json',
        upsert: true
      });

    if (storageError) {
      console.error('Error storing report:', storageError);
      throw storageError;
    }

    console.log(`Report stored as: weekly/${fileName}`);

    return new Response(
      JSON.stringify({
        success: true,
        metrics,
        report_path: `weekly/${fileName}`,
        generated_at: new Date().toISOString()
      }),
      {
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        }
      }
    );

  } catch (error) {
    console.error('Error generating weekly report:', error);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message
      }),
      {
        status: 500,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json' 
        }
      }
    );
  }
});