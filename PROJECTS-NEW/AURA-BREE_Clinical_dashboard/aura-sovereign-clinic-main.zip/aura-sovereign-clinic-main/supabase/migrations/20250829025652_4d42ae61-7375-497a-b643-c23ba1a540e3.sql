-- 006_checkin_visit_trigger.sql
-- Auto-create visit when patient checks in

CREATE OR REPLACE FUNCTION public.ensure_visit_on_checkin()
RETURNS trigger 
LANGUAGE plpgsql 
SET search_path = public
AS $$
DECLARE
  _today_start timestamptz := date_trunc('day', timezone('utc', now()));
  _today_end   timestamptz := _today_start + interval '1 day';
  _visit_id uuid;
BEGIN
  -- Does a waiting/active visit already exist today?
  SELECT v.id INTO _visit_id
  FROM public.visits v
  WHERE v.patient_id = NEW.patient_id
    AND v.arrived_at >= _today_start
    AND v.arrived_at <  _today_end
    AND v.triage_status IN ('waiting','active')
  ORDER BY v.arrived_at DESC
  LIMIT 1;

  IF _visit_id IS NULL THEN
    INSERT INTO public.visits (patient_id, arrived_at, triage_status, notes)
    VALUES (NEW.patient_id, now(), 'waiting', 'Auto-created from check-in')
    RETURNING id INTO _visit_id;
    
    -- Log the auto-creation
    INSERT INTO public.audit_log (actor_type, actor_id, action, entity, entity_id, summary)
    VALUES ('system', NULL, 'create', 'visit', _visit_id, 'Auto-created visit from patient check-in');
  END IF;

  RETURN NEW;
END;
$$;

-- Create the trigger
DROP TRIGGER IF EXISTS trg_checkins_ensure_visit ON public.checkins;
CREATE TRIGGER trg_checkins_ensure_visit
  AFTER INSERT ON public.checkins
  FOR EACH ROW 
  EXECUTE FUNCTION public.ensure_visit_on_checkin();

-- Create storage buckets for reports and backups
INSERT INTO storage.buckets (id, name, public) 
VALUES 
  ('reports', 'reports', false),
  ('backups', 'backups', false)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for reports bucket (admin only)
CREATE POLICY "Admins can manage reports" ON storage.objects
FOR ALL USING (
  bucket_id = 'reports' AND 
  EXISTS (SELECT 1 FROM public.staff WHERE user_id = auth.uid() AND role = 'admin' AND active = true)
);

-- Storage policies for backups bucket (system only)
CREATE POLICY "System can manage backups" ON storage.objects
FOR ALL USING (bucket_id = 'backups');