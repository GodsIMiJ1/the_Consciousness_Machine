-- Create RLS policies for all tables

-- Staff table policies (authenticated staff can see all staff for role management)
CREATE POLICY "Authenticated staff can view all staff" 
ON public.staff 
FOR SELECT 
TO authenticated 
USING (true);

CREATE POLICY "Only admins can insert staff" 
ON public.staff 
FOR INSERT 
TO authenticated 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND role = 'admin'
  ) OR NOT EXISTS (SELECT 1 FROM public.staff LIMIT 1)
);

CREATE POLICY "Only admins can update staff" 
ON public.staff 
FOR UPDATE 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND role = 'admin'
  )
);

-- Patients table policies (all authenticated staff can access)
CREATE POLICY "Staff can view all patients" 
ON public.patients 
FOR SELECT 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

CREATE POLICY "Staff can create patients" 
ON public.patients 
FOR INSERT 
TO authenticated 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

CREATE POLICY "Staff can update patients" 
ON public.patients 
FOR UPDATE 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

-- Visits table policies
CREATE POLICY "Staff can view all visits" 
ON public.visits 
FOR SELECT 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

CREATE POLICY "Staff can create visits" 
ON public.visits 
FOR INSERT 
TO authenticated 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

CREATE POLICY "Staff can update visits" 
ON public.visits 
FOR UPDATE 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

-- Dosages table policies
CREATE POLICY "Staff can view all dosages" 
ON public.dosages 
FOR SELECT 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

CREATE POLICY "Staff can create dosages" 
ON public.dosages 
FOR INSERT 
TO authenticated 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

-- Devices table policies (staff can view, system can manage)
CREATE POLICY "Staff can view devices" 
ON public.devices 
FOR SELECT 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

CREATE POLICY "System can manage devices" 
ON public.devices 
FOR ALL 
TO service_role 
USING (true);

-- Checkins table policies (staff can view, system can create)
CREATE POLICY "Staff can view checkins" 
ON public.checkins 
FOR SELECT 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

CREATE POLICY "System can create checkins" 
ON public.checkins 
FOR INSERT 
TO service_role 
WITH CHECK (true);

-- Audit log policies (read-only for staff, system can write)
CREATE POLICY "Staff can view audit log" 
ON public.audit_log 
FOR SELECT 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND active = true
  )
);

CREATE POLICY "System can write to audit log" 
ON public.audit_log 
FOR INSERT 
TO service_role 
WITH CHECK (true);

-- Settings policies (admin only)
CREATE POLICY "Admins can manage settings" 
ON public.settings 
FOR ALL 
TO authenticated 
USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() AND role = 'admin' AND active = true
  )
);