-- Core Tables for Sovereign Methadone Clinic Dashboard

-- Patients table
CREATE TABLE public.patients (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mrn TEXT NOT NULL UNIQUE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  dob DATE NOT NULL,
  phone TEXT,
  status TEXT NOT NULL CHECK (status IN ('new', 'active', 'hold', 'discharged', 'transferred')) DEFAULT 'new',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Staff table
CREATE TABLE public.staff (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id),
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin', 'nurse', 'reception', 'auditor')) DEFAULT 'reception',
  username TEXT UNIQUE,
  active BOOLEAN NOT NULL DEFAULT true,
  mfa_enabled BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Visits table
CREATE TABLE public.visits (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  staff_id UUID REFERENCES public.staff(id),
  arrived_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  triage_status TEXT CHECK (triage_status IN ('waiting', 'in_progress', 'completed', 'cancelled')) DEFAULT 'waiting',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Dosages table
CREATE TABLE public.dosages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  visit_id UUID REFERENCES public.visits(id) ON DELETE CASCADE,
  medication TEXT NOT NULL DEFAULT 'Methadone',
  dose_mg INTEGER NOT NULL CHECK (dose_mg > 0),
  administered_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  administered_by UUID NOT NULL REFERENCES public.staff(id),
  observed BOOLEAN NOT NULL DEFAULT true,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Devices table for AURA-BREE sync
CREATE TABLE public.devices (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  patient_id UUID REFERENCES public.patients(id) ON DELETE CASCADE,
  device_uuid TEXT NOT NULL UNIQUE,
  public_key TEXT,
  device_name TEXT,
  first_seen_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  last_seen_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  status TEXT CHECK (status IN ('active', 'revoked', 'suspended')) DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Check-ins table for AURA-BREE sync events
CREATE TABLE public.checkins (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  patient_id UUID NOT NULL REFERENCES public.patients(id) ON DELETE CASCADE,
  device_id UUID REFERENCES public.devices(id) ON DELETE CASCADE,
  arrived_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  geo_hint TEXT,
  rssi INTEGER,
  method TEXT CHECK (method IN ('wifi', 'bluetooth', 'manual')) DEFAULT 'wifi',
  app_version TEXT,
  sync_data JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Audit log with hash chaining
CREATE TABLE public.audit_log (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  ts TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  actor_type TEXT NOT NULL CHECK (actor_type IN ('staff', 'system', 'device')),
  actor_id UUID,
  action TEXT NOT NULL,
  entity TEXT NOT NULL,
  entity_id UUID,
  summary TEXT NOT NULL,
  prev_hash TEXT,
  hash TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Settings table for clinic configuration
CREATE TABLE public.settings (
  key TEXT PRIMARY KEY,
  value_json JSONB NOT NULL DEFAULT '{}',
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dosages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.checkins ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

-- Create indexes for performance
CREATE INDEX idx_patients_mrn ON public.patients(mrn);
CREATE INDEX idx_patients_last_name ON public.patients(last_name);
CREATE INDEX idx_patients_status ON public.patients(status);

CREATE INDEX idx_visits_patient_id ON public.visits(patient_id);
CREATE INDEX idx_visits_arrived_at ON public.visits(arrived_at DESC);
CREATE INDEX idx_visits_status ON public.visits(triage_status);

CREATE INDEX idx_dosages_patient_id ON public.dosages(patient_id);
CREATE INDEX idx_dosages_administered_at ON public.dosages(administered_at DESC);
CREATE INDEX idx_dosages_visit_id ON public.dosages(visit_id);

CREATE INDEX idx_checkins_patient_id ON public.checkins(patient_id);
CREATE INDEX idx_checkins_arrived_at ON public.checkins(arrived_at DESC);
CREATE INDEX idx_checkins_device_id ON public.checkins(device_id);

CREATE INDEX idx_devices_patient_id ON public.devices(patient_id);
CREATE INDEX idx_devices_uuid ON public.devices(device_uuid);
CREATE INDEX idx_devices_status ON public.devices(status);

CREATE INDEX idx_audit_log_ts ON public.audit_log(ts DESC);
CREATE INDEX idx_audit_log_entity ON public.audit_log(entity, entity_id);
CREATE INDEX idx_audit_log_actor ON public.audit_log(actor_type, actor_id);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_patients_updated_at
  BEFORE UPDATE ON public.patients
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_staff_updated_at
  BEFORE UPDATE ON public.staff
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_visits_updated_at
  BEFORE UPDATE ON public.visits
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_devices_updated_at
  BEFORE UPDATE ON public.devices
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_settings_updated_at
  BEFORE UPDATE ON public.settings
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Function for audit log hash chaining
CREATE OR REPLACE FUNCTION public.calculate_audit_hash(
  p_ts TIMESTAMP WITH TIME ZONE,
  p_actor_type TEXT,
  p_actor_id UUID,
  p_action TEXT,
  p_entity TEXT,
  p_entity_id UUID,
  p_summary TEXT,
  p_prev_hash TEXT
) RETURNS TEXT AS $$
BEGIN
  RETURN encode(
    digest(
      COALESCE(p_prev_hash, '') || 
      p_ts::text || 
      p_actor_type || 
      COALESCE(p_actor_id::text, '') || 
      p_action || 
      p_entity || 
      COALESCE(p_entity_id::text, '') || 
      p_summary,
      'sha256'
    ),
    'hex'
  );
END;
$$ LANGUAGE plpgsql;

-- Trigger to calculate audit hash on insert
CREATE OR REPLACE FUNCTION public.audit_hash_trigger()
RETURNS TRIGGER AS $$
DECLARE
  last_hash TEXT;
BEGIN
  -- Get the previous hash from the last audit entry
  SELECT hash INTO last_hash 
  FROM public.audit_log 
  ORDER BY ts DESC 
  LIMIT 1;
  
  -- Calculate the hash for this entry
  NEW.hash = public.calculate_audit_hash(
    NEW.ts,
    NEW.actor_type,
    NEW.actor_id,
    NEW.action,
    NEW.entity,
    NEW.entity_id,
    NEW.summary,
    last_hash
  );
  
  NEW.prev_hash = last_hash;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER audit_log_hash_trigger
  BEFORE INSERT ON public.audit_log
  FOR EACH ROW
  EXECUTE FUNCTION public.audit_hash_trigger();

-- Enable realtime for live updates
ALTER TABLE public.patients REPLICA IDENTITY FULL;
ALTER TABLE public.visits REPLICA IDENTITY FULL;
ALTER TABLE public.dosages REPLICA IDENTITY FULL;
ALTER TABLE public.checkins REPLICA IDENTITY FULL;
ALTER TABLE public.audit_log REPLICA IDENTITY FULL;

-- Add tables to realtime publication
ALTER PUBLICATION supabase_realtime ADD TABLE public.patients;
ALTER PUBLICATION supabase_realtime ADD TABLE public.visits;
ALTER PUBLICATION supabase_realtime ADD TABLE public.dosages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.checkins;
ALTER PUBLICATION supabase_realtime ADD TABLE public.audit_log;