-- 001_staff_min.sql
create type role_type as enum ('admin','clinician','reception');

create table if not exists public.staff (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role role_type not null default 'reception',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.staff enable row level security;

create policy "staff self view" on public.staff
for select using (auth.uid() = user_id);

create policy "admin manage staff" on public.staff
for all using (
  exists (select 1 from public.staff where user_id = auth.uid() and role='admin' and active)
) with check (
  exists (select 1 from public.staff where user_id = auth.uid() and role='admin' and active)
);

-- Onboarding RPC
create or replace function public.register_staff(_full_name text, _role role_type default 'reception')
returns void language plpgsql security definer as $$
begin
  insert into public.staff (user_id, full_name, role)
  values (auth.uid(), _full_name, coalesce(_role,'reception'))
  on conflict (user_id) do update set full_name=excluded.full_name, role=excluded.role, active=true;
end; $$;
grant execute on function public.register_staff(text, role_type) to authenticated;