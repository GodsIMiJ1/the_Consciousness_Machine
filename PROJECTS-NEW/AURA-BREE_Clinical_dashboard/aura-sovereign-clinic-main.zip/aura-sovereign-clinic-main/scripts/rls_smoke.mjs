import 'dotenv/config';
import { createClient } from '@supabase/supabase-js';

const url = process.env.VITE_SUPABASE_URL;
const anon = process.env.VITE_SUPABASE_ANON_KEY;

async function signUpAndRole(email, password, fullName, role='reception') {
  const c = createClient(url, anon);
  await c.auth.signUp({ email, password });
  await c.auth.signInWithPassword({ email, password });
  await c.rpc('register_staff', { _full_name: fullName, _role: role });
  return c;
}

(async () => {
  try {
    console.log('🔥 Starting RLS Smoke Test...\n');

    const admin = await signUpAndRole('admin@test.com','Password!23','Admin User','admin');
    const receptionist = await signUpAndRole('front@test.com','Password!23','Front Desk','reception');

    console.log('✅ Created test users\n');

    // Admin should insert patient
    let r = await admin.from('patients').insert({ 
      mrn:'MRN-1000', 
      first_name:'Test', 
      last_name:'Patient',
      dob: '1990-01-01',
      status: 'active'
    }).select();
    console.log('Admin insert patient:', r.error ? `❌ FAIL: ${r.error.message}` : '✅ PASS');

    // Get patient ID for dosage test
    const patientId = r.data?.[0]?.id;

    // Reception should NOT insert dosage (if policy restricts to clinician/admin)
    if (patientId) {
      const adminUserId = (await admin.auth.getUser()).data.user?.id;
      r = await receptionist.from('dosages').insert({ 
        patient_id: patientId, 
        dose_mg: 10, 
        administered_by: adminUserId,
        medication: 'Methadone'
      });
      console.log('Reception insert dosage blocked:', r.error ? '✅ PASS (blocked)' : '❌ FAIL (should be blocked)');
    }

    // Admin should be able to insert dosage
    if (patientId) {
      const adminUserId = (await admin.auth.getUser()).data.user?.id;
      r = await admin.from('dosages').insert({ 
        patient_id: patientId, 
        dose_mg: 15, 
        administered_by: adminUserId,
        medication: 'Methadone'
      });
      console.log('Admin insert dosage:', r.error ? `❌ FAIL: ${r.error.message}` : '✅ PASS');
    }

    // Test staff table access
    r = await admin.from('staff').select('*');
    console.log('Admin view staff:', r.error ? `❌ FAIL: ${r.error.message}` : '✅ PASS');

    r = await receptionist.from('staff').select('*');
    console.log('Reception view staff:', r.error ? `❌ FAIL: ${r.error.message}` : '✅ PASS');

    console.log('\n🎉 RLS Smoke Test Complete!');

  } catch (error) {
    console.error('💥 Test failed:', error.message);
  }
})();