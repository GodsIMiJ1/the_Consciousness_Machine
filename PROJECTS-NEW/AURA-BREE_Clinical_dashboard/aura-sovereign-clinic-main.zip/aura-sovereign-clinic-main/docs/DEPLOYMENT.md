# Production Deployment Guide

This guide covers deploying MethaClinic to production with proper security, monitoring, and compliance considerations.

## 🏗️ Infrastructure Requirements

### Minimum System Requirements
- **CPU**: 2+ cores
- **Memory**: 4GB+ RAM
- **Storage**: 50GB+ SSD
- **Network**: Stable internet connection with SSL/TLS

### Recommended Stack
- **Frontend Hosting**: Vercel, Netlify, or Cloudflare Pages
- **Backend**: Supabase (managed) or self-hosted PostgreSQL + Deno Deploy
- **CDN**: Cloudflare for global performance
- **Monitoring**: Sentry, LogRocket, or similar
- **Backups**: Automated to secure cloud storage

## 🚀 Deployment Options

### Option 1: Lovable + Supabase (Recommended)

**Pros**: Fastest deployment, managed infrastructure, automatic updates
**Cons**: Less control over hosting environment

#### Steps:
1. **Deploy Frontend**
   ```bash
   # In Lovable
   Share → Publish → Configure Domain
   ```

2. **Supabase Configuration**
   - Production project setup
   - Environment-specific secrets
   - Backup and monitoring configuration

3. **Custom Domain Setup**
   ```bash
   # In Lovable Project Settings
   Domains → Connect Domain → yourdomain.com
   ```

### Option 2: Self-Hosted

**Pros**: Full control, custom infrastructure, cost optimization
**Cons**: More complex setup and maintenance

#### Frontend Deployment
```bash
# Build for production
npm run build

# Deploy to your hosting provider
# Example with Vercel
vercel --prod

# Example with Docker
docker build -t methadone-clinic .
docker run -p 3000:3000 methadone-clinic
```

#### Backend Deployment
```bash
# Self-hosted Supabase (Advanced)
git clone https://github.com/supabase/supabase
cd supabase/docker
docker-compose up -d

# Or use Supabase managed service (Recommended)
```

## 🔧 Environment Configuration

### Production Environment Variables

Create environment-specific configurations:

```bash
# Production Supabase Settings
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Edge Function Secrets
BACKUP_ENCRYPTION_KEY=your-32-character-key
SMTP_CONFIG=your-email-provider-config
COMPLIANCE_REPORT_RECIPIENTS=admin@clinic.com
```

### Security Configuration

```sql
-- Production RLS Policies (run in Supabase SQL Editor)

-- Ensure all tables have RLS enabled
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.dosages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.checkins ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

-- Production-specific policies
CREATE POLICY "prod_admin_full_access" ON public.patients
FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'admin' 
    AND active = true
  )
);
```

## 🔒 Security Hardening

### Database Security
- [ ] RLS enabled on all tables
- [ ] Service role key secured
- [ ] Database connection limits configured
- [ ] Regular security updates applied

### Application Security
- [ ] HTTPS/SSL certificates configured
- [ ] Content Security Policy (CSP) headers
- [ ] CORS properly configured
- [ ] Rate limiting implemented
- [ ] Input validation and sanitization

### Infrastructure Security
- [ ] Firewall rules configured
- [ ] VPN access for admin operations
- [ ] Regular security scans
- [ ] Monitoring and alerting setup

## 📊 Monitoring Setup

### Application Monitoring

```typescript
// Error tracking setup
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "your-sentry-dsn",
  environment: "production",
  integrations: [
    new Sentry.BrowserTracing(),
  ],
  tracesSampleRate: 1.0,
});
```

### Database Monitoring

```sql
-- Setup monitoring queries
CREATE OR REPLACE FUNCTION public.monitor_system_health()
RETURNS json AS $$
DECLARE
  result json;
BEGIN
  SELECT json_build_object(
    'active_patients', (SELECT COUNT(*) FROM public.patients WHERE active = true),
    'pending_visits', (SELECT COUNT(*) FROM public.visits WHERE status = 'waiting'),
    'daily_checkins', (SELECT COUNT(*) FROM public.checkins WHERE created_at > CURRENT_DATE),
    'system_load', pg_stat_activity.state
  ) INTO result
  FROM pg_stat_activity 
  WHERE application_name = 'methadone-clinic'
  LIMIT 1;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

### Edge Function Monitoring

```typescript
// In your edge functions
const logMetrics = async (functionName: string, duration: number, success: boolean) => {
  await supabase.from('function_metrics').insert({
    function_name: functionName,
    execution_time: duration,
    success,
    timestamp: new Date().toISOString()
  });
};
```

## 🔄 Backup Strategy

### Automated Backups

The system includes nightly encrypted backups via Edge Functions:

```typescript
// Backup configuration in Supabase dashboard
{
  "schedule": "0 2 * * *", // Daily at 2 AM
  "retention_days": 30,
  "encryption_enabled": true,
  "compression": "gzip"
}
```

### Manual Backup Procedures

```bash
# Database backup
pg_dump -h your-host -U postgres -d your-db > backup_$(date +%Y%m%d).sql

# Application backup
tar -czf app_backup_$(date +%Y%m%d).tar.gz src/ public/ package.json

# Upload to secure storage
aws s3 cp backup_$(date +%Y%m%d).sql s3://your-backup-bucket/
```

### Recovery Procedures

```bash
# Database restore
psql -h your-host -U postgres -d your-db < backup_20240829.sql

# Application restore
tar -xzf app_backup_20240829.tar.gz
npm install
npm run build
```

## 📈 Performance Optimization

### Frontend Optimization
- [ ] Bundle size analysis and optimization
- [ ] Image compression and WebP conversion
- [ ] CDN configuration for static assets
- [ ] Service worker for caching

### Database Optimization
- [ ] Index analysis and optimization
- [ ] Query performance monitoring
- [ ] Connection pooling configuration
- [ ] Read replicas for reporting

### Caching Strategy
- [ ] Browser caching headers
- [ ] API response caching
- [ ] Static asset caching
- [ ] Database query caching

## 🧪 Testing in Production

### Smoke Tests
```bash
# Run production smoke tests
npm run test:smoke

# Check critical user flows
cypress run --spec "cypress/e2e/critical-flows.cy.ts" --env baseUrl=https://yourdomain.com
```

### Load Testing
```bash
# Install load testing tools
npm install -g artillery

# Run load tests
artillery run load-test-config.yml
```

### Health Checks
```typescript
// Health check endpoint
export const healthCheck = async () => {
  const checks = {
    database: await checkDatabaseConnection(),
    storage: await checkStorageAccess(),
    functions: await checkEdgeFunctions(),
    authentication: await checkAuthService()
  };
  
  return {
    status: Object.values(checks).every(Boolean) ? 'healthy' : 'unhealthy',
    checks,
    timestamp: new Date().toISOString()
  };
};
```

## 📋 Deployment Checklist

### Pre-Deployment
- [ ] All tests passing
- [ ] Security scan completed
- [ ] Performance benchmarks met
- [ ] Database migrations reviewed
- [ ] Backup procedures tested

### Deployment
- [ ] Blue/green deployment strategy
- [ ] Database migrations applied
- [ ] Edge functions deployed
- [ ] Environment variables configured
- [ ] SSL certificates installed

### Post-Deployment
- [ ] Health checks passing
- [ ] Monitoring alerts configured
- [ ] Performance metrics baseline
- [ ] User acceptance testing
- [ ] Documentation updated

## 🚨 Incident Response

### Monitoring Alerts
- Database connection failures
- Edge function errors
- Authentication issues
- Performance degradation
- Security violations

### Response Procedures
1. **Immediate Assessment**
   - Check system health dashboard
   - Review recent deployments
   - Analyze error logs

2. **Mitigation Steps**
   - Rollback if necessary
   - Scale resources if needed
   - Implement temporary fixes

3. **Communication**
   - Notify stakeholders
   - Update status page
   - Document incident

4. **Post-Incident**
   - Conduct root cause analysis
   - Implement preventive measures
   - Update procedures

## 📞 Support Contacts

### Technical Support
- **Development Team**: dev-team@clinic.com
- **Infrastructure**: ops-team@clinic.com
- **Security**: security-team@clinic.com

### Vendor Support
- **Supabase Support**: https://supabase.com/support
- **Lovable Support**: https://lovable.dev/support

---

**Remember**: Always test deployment procedures in a staging environment before applying to production!