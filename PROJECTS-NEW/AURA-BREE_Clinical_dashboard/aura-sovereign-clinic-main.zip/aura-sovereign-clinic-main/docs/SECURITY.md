# Security Documentation

MethaClinic implements comprehensive security measures to protect sensitive healthcare data and ensure HIPAA compliance. This document outlines the security architecture, policies, and best practices.

## 🛡️ Security Architecture

### Defense in Depth

```mermaid
graph TD
    A[User Request] --> B[HTTPS/TLS]
    B --> C[Authentication Layer]
    C --> D[Authorization/RBAC]
    D --> E[Row Level Security]
    E --> F[Database Encryption]
    F --> G[Audit Logging]
    G --> H[Data Storage]
    
    style A fill:#e1f5fe
    style B fill:#f3e5f5
    style C fill:#fff3e0
    style D fill:#e8f5e8
    style E fill:#fce4ec
    style F fill:#f1f8e9
    style G fill:#fff8e1
    style H fill:#e3f2fd
```

### Security Layers

1. **Transport Security** - HTTPS/TLS encryption
2. **Authentication** - Supabase Auth with JWT tokens
3. **Authorization** - Role-Based Access Control (RBAC)
4. **Data Security** - Row Level Security (RLS) policies
5. **Encryption** - At-rest and in-transit encryption
6. **Auditing** - Comprehensive audit logging with hash chains
7. **Network Security** - Firewall and access controls

## 🔐 Authentication & Authorization

### User Roles and Permissions

| Role | Permissions | Access Level |
|------|-------------|--------------|
| **Admin** | Full system access, user management, audit logs | 🔴 **Full Access** |
| **Clinician** | Patient care, dosage management, clinical reports | 🔵 **Clinical Access** |
| **Reception** | Check-ins, queue management, basic patient info | ⚪ **Limited Access** |

### Role-Based Access Control (RBAC)

```sql
-- Staff role enumeration
CREATE TYPE role_type AS ENUM ('admin', 'clinician', 'reception');

-- Staff table with role assignments
CREATE TABLE public.staff (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL UNIQUE REFERENCES auth.users(id),
  full_name text NOT NULL,
  role role_type NOT NULL DEFAULT 'reception',
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
```

## 🔒 Row Level Security (RLS) Policies

All tables implement comprehensive RLS policies to ensure data isolation and access control.

### Patients Table Policies

```sql
-- Enable RLS
ALTER TABLE public.patients ENABLE ROW LEVEL SECURITY;

-- Admin: Full access to all patients
CREATE POLICY "admin_patients_all" ON public.patients
FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'admin' 
    AND active = true
  )
);

-- Clinician: Full access to all patients
CREATE POLICY "clinician_patients_all" ON public.patients
FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'clinician' 
    AND active = true
  )
);

-- Reception: Read-only access to basic patient info
CREATE POLICY "reception_patients_read" ON public.patients
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'reception' 
    AND active = true
  )
);
```

### Dosages Table Policies

```sql
-- Enable RLS
ALTER TABLE public.dosages ENABLE ROW LEVEL SECURITY;

-- Admin: Full access to all dosages
CREATE POLICY "admin_dosages_all" ON public.dosages
FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'admin' 
    AND active = true
  )
);

-- Clinician: Full access to all dosages
CREATE POLICY "clinician_dosages_all" ON public.dosages
FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'clinician' 
    AND active = true
  )
);

-- Reception: No access to dosages (HIPAA compliance)
-- No policy = no access for reception role
```

### Visits Table Policies

```sql
-- Enable RLS
ALTER TABLE public.visits ENABLE ROW LEVEL SECURITY;

-- Admin: Full access to all visits
CREATE POLICY "admin_visits_all" ON public.visits
FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'admin' 
    AND active = true
  )
);

-- Clinician: Full access to all visits
CREATE POLICY "clinician_visits_all" ON public.visits
FOR ALL USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'clinician' 
    AND active = true
  )
);

-- Reception: Can view and update visit status for queue management
CREATE POLICY "reception_visits_limited" ON public.visits
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'reception' 
    AND active = true
  )
);

CREATE POLICY "reception_visits_update_status" ON public.visits
FOR UPDATE USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'reception' 
    AND active = true
  )
) WITH CHECK (
  -- Reception can only update triage_status
  OLD.patient_id = NEW.patient_id 
  AND OLD.created_by = NEW.created_by
  AND OLD.scheduled_at = NEW.scheduled_at
);
```

### Check-ins Table Policies

```sql
-- Enable RLS
ALTER TABLE public.checkins ENABLE ROW LEVEL SECURITY;

-- All staff can view check-ins (for real-time notifications)
CREATE POLICY "staff_checkins_read" ON public.checkins
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND active = true
  )
);

-- All staff can create check-ins (reception primarily, but others can help)
CREATE POLICY "staff_checkins_create" ON public.checkins
FOR INSERT WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND active = true
  )
  AND created_by = auth.uid()
);

-- Only admin can update/delete check-ins
CREATE POLICY "admin_checkins_modify" ON public.checkins
FOR UPDATE USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'admin' 
    AND active = true
  )
);
```

### Audit Log Policies

```sql
-- Enable RLS
ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

-- Admin: Full access to all audit logs
CREATE POLICY "admin_audit_all" ON public.audit_log
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'admin' 
    AND active = true
  )
);

-- Clinician: Can view patient-related audit entries only
CREATE POLICY "clinician_audit_patient_related" ON public.audit_log
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.staff 
    WHERE user_id = auth.uid() 
    AND role = 'clinician' 
    AND active = true
  )
  AND entity IN ('patient', 'visit', 'dosage')
);

-- System can insert audit logs
CREATE POLICY "system_audit_insert" ON public.audit_log
FOR INSERT WITH CHECK (actor_type = 'system' OR actor_type = 'user');
```

## 🔑 Authentication Security

### JWT Token Configuration

```typescript
// Supabase client configuration with security settings
const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: 'pkce' // Proof Key for Code Exchange
  }
});
```

### Password Requirements

```sql
-- Password policy (implemented via Supabase Auth)
-- Minimum 8 characters
-- Must include uppercase, lowercase, number, special character
-- Cannot be common passwords
-- Cannot reuse last 5 passwords
```

### Session Management

```typescript
// Secure session handling
const AuthProvider = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  
  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  // Auto-logout on inactivity (30 minutes)
  useEffect(() => {
    let timeout: NodeJS.Timeout;
    
    const resetTimeout = () => {
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        supabase.auth.signOut();
      }, 30 * 60 * 1000); // 30 minutes
    };

    if (session) {
      resetTimeout();
      window.addEventListener('mousemove', resetTimeout);
      window.addEventListener('keypress', resetTimeout);
    }

    return () => {
      clearTimeout(timeout);
      window.removeEventListener('mousemove', resetTimeout);
      window.removeEventListener('keypress', resetTimeout);
    };
  }, [session]);
};
```

## 🔍 Audit Logging & Hash Chains

### Tamper-Evident Audit System

```sql
-- Audit log with hash chain for tamper detection
CREATE TABLE public.audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ts timestamptz NOT NULL DEFAULT now(),
  actor_type text NOT NULL, -- 'user' | 'system'
  actor_id uuid,           -- user_id if actor_type = 'user'
  action text NOT NULL,    -- 'create' | 'update' | 'delete' | 'login' | etc.
  entity text NOT NULL,    -- 'patient' | 'visit' | 'dosage' | etc.
  entity_id uuid,          -- ID of affected entity
  summary text NOT NULL,   -- Human-readable description
  details jsonb,           -- Additional context data
  hash text NOT NULL,      -- SHA-256 hash of this entry + previous hash
  prev_hash text           -- Hash of previous audit entry
);

-- Function to calculate audit hash
CREATE OR REPLACE FUNCTION public.calculate_audit_hash(
  p_ts timestamptz,
  p_actor_type text,
  p_actor_id uuid,
  p_action text,
  p_entity text,
  p_entity_id uuid,
  p_summary text,
  p_prev_hash text
) RETURNS text AS $$
BEGIN
  RETURN encode(
    digest(
      COALESCE(p_prev_hash, '') || 
      p_ts::text || 
      p_actor_type || 
      COALESCE(p_actor_id::text, '') || 
      p_action || 
      p_entity || 
      COALESCE(p_entity_id::text, '') || 
      p_summary,
      'sha256'
    ),
    'hex'
  );
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically calculate hashes
CREATE OR REPLACE FUNCTION public.audit_hash_trigger()
RETURNS trigger AS $$
DECLARE
  last_hash text;
BEGIN
  -- Get the previous hash from the last audit entry
  SELECT hash INTO last_hash 
  FROM public.audit_log 
  ORDER BY ts DESC 
  LIMIT 1;
  
  -- Calculate the hash for this entry
  NEW.hash = public.calculate_audit_hash(
    NEW.ts,
    NEW.actor_type,
    NEW.actor_id,
    NEW.action,
    NEW.entity,
    NEW.entity_id,
    NEW.summary,
    last_hash
  );
  
  NEW.prev_hash = last_hash;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER audit_hash_trigger
  BEFORE INSERT ON public.audit_log
  FOR EACH ROW
  EXECUTE FUNCTION public.audit_hash_trigger();
```

### Hash Chain Verification

```typescript
// Function to verify audit log integrity
export const verifyAuditIntegrity = async () => {
  const { data: auditLogs } = await supabase
    .from('audit_log')
    .select('*')
    .order('ts', { ascending: true });

  if (!auditLogs || auditLogs.length === 0) {
    return { valid: true, message: 'No audit logs to verify' };
  }

  let prevHash: string | null = null;
  
  for (const log of auditLogs) {
    const expectedHash = calculateHash({
      ts: log.ts,
      actor_type: log.actor_type,
      actor_id: log.actor_id,
      action: log.action,
      entity: log.entity,
      entity_id: log.entity_id,
      summary: log.summary,
      prev_hash: prevHash
    });

    if (log.hash !== expectedHash) {
      return {
        valid: false,
        message: `Hash mismatch at entry ${log.id}`,
        entry: log
      };
    }

    if (log.prev_hash !== prevHash) {
      return {
        valid: false,
        message: `Previous hash mismatch at entry ${log.id}`,
        entry: log
      };
    }

    prevHash = log.hash;
  }

  return { valid: true, message: 'Audit log integrity verified' };
};
```

## 🔐 Data Encryption

### At-Rest Encryption

```sql
-- Encrypted storage for sensitive data
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Function for symmetric encryption
CREATE OR REPLACE FUNCTION encrypt_sensitive_data(data text, key text)
RETURNS text AS $$
BEGIN
  RETURN encode(
    pgp_sym_encrypt(data, key),
    'base64'
  );
END;
$$ LANGUAGE plpgsql;

-- Function for decryption
CREATE OR REPLACE FUNCTION decrypt_sensitive_data(encrypted_data text, key text)
RETURNS text AS $$
BEGIN
  RETURN pgp_sym_decrypt(
    decode(encrypted_data, 'base64'),
    key
  );
END;
$$ LANGUAGE plpgsql;
```

### Backup Encryption

```typescript
// Encrypted backup implementation
const encryptBackupData = async (data: string, key: string): Promise<string> => {
  const encoder = new TextEncoder();
  const keyData = await crypto.subtle.importKey(
    'raw',
    encoder.encode(key.padEnd(32, '0').slice(0, 32)),
    { name: 'AES-GCM' },
    false,
    ['encrypt']
  );

  const iv = crypto.getRandomValues(new Uint8Array(12));
  const encodedData = encoder.encode(data);
  
  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    keyData,
    encodedData
  );

  // Combine IV and encrypted data
  const result = new Uint8Array(iv.length + encrypted.byteLength);
  result.set(iv);
  result.set(new Uint8Array(encrypted), iv.length);
  
  return btoa(String.fromCharCode(...result));
};
```

## 🛡️ Security Best Practices

### Input Validation & Sanitization

```typescript
import { z } from 'zod';

// Comprehensive input validation schemas
const PatientSchema = z.object({
  first_name: z.string().min(1).max(100).regex(/^[a-zA-Z\s'-]+$/),
  last_name: z.string().min(1).max(100).regex(/^[a-zA-Z\s'-]+$/),
  date_of_birth: z.string().datetime(),
  mrn: z.string().regex(/^[A-Z0-9]{6,12}$/),
  phone: z.string().regex(/^\+?[\d\s()-]{10,15}$/).optional(),
  email: z.string().email().optional()
});

const DosageSchema = z.object({
  patient_id: z.string().uuid(),
  amount_mg: z.number().min(1).max(200),
  administered_at: z.string().datetime(),
  notes: z.string().max(500).optional()
});

// Sanitize HTML content
const sanitizeInput = (input: string): string => {
  return input
    .replace(/[<>]/g, '') // Remove HTML tags
    .replace(/['"]/g, '') // Remove quotes
    .trim()
    .slice(0, 1000); // Limit length
};
```

### SQL Injection Prevention

```typescript
// Always use parameterized queries via Supabase client
const getPatients = async (searchTerm: string) => {
  // ✅ SAFE: Using Supabase client methods
  const { data } = await supabase
    .from('patients')
    .select('*')
    .or(`first_name.ilike.%${searchTerm}%,last_name.ilike.%${searchTerm}%`);
  
  return data;
};

// ❌ NEVER: Direct SQL with string concatenation
// const query = `SELECT * FROM patients WHERE name = '${searchTerm}'`;
```

### Cross-Site Scripting (XSS) Prevention

```typescript
// Content Security Policy headers
const cspDirectives = {
  'default-src': "'self'",
  'script-src': "'self' 'unsafe-inline' https://unpkg.com",
  'style-src': "'self' 'unsafe-inline'",
  'img-src': "'self' data: https:",
  'connect-src': "'self' https://*.supabase.co",
  'font-src': "'self'",
  'object-src': "'none'",
  'base-uri': "'self'",
  'form-action': "'self'",
  'frame-ancestors': "'none'"
};

// Sanitize user-generated content
import DOMPurify from 'dompurify';

const sanitizeHtml = (dirty: string): string => {
  return DOMPurify.sanitize(dirty, {
    ALLOWED_TAGS: [], // No HTML tags allowed
    ALLOWED_ATTR: []
  });
};
```

## 🔍 Security Monitoring

### Real-Time Threat Detection

```sql
-- Monitor suspicious activities
CREATE OR REPLACE VIEW security_alerts AS
SELECT 
  ts,
  actor_id,
  action,
  entity,
  summary,
  CASE 
    WHEN action = 'login' AND ts > now() - interval '1 hour' THEN 'multiple_logins'
    WHEN action IN ('delete', 'update') AND entity = 'audit_log' THEN 'audit_tampering'
    WHEN action = 'create' AND entity = 'dosage' AND ts NOT BETWEEN '06:00' AND '18:00' THEN 'off_hours_dosage'
    ELSE NULL
  END as alert_type
FROM audit_log
WHERE ts > now() - interval '24 hours'
AND (
  -- Multiple login attempts
  (action = 'login' AND actor_id IN (
    SELECT actor_id FROM audit_log 
    WHERE action = 'login' 
    AND ts > now() - interval '1 hour'
    GROUP BY actor_id 
    HAVING COUNT(*) > 3
  ))
  -- Audit log tampering attempts
  OR (action IN ('delete', 'update') AND entity = 'audit_log')
  -- Off-hours medication administration
  OR (action = 'create' AND entity = 'dosage' AND EXTRACT(hour FROM ts) NOT BETWEEN 6 AND 18)
);
```

### Automated Security Alerts

```typescript
// Security monitoring function
export const checkSecurityAlerts = async () => {
  const { data: alerts } = await supabase
    .from('security_alerts')
    .select('*')
    .not('alert_type', 'is', null);

  if (alerts && alerts.length > 0) {
    // Send alerts to security team
    await Promise.all(alerts.map(alert => 
      sendSecurityAlert({
        type: alert.alert_type,
        timestamp: alert.ts,
        actor: alert.actor_id,
        details: alert.summary
      })
    ));
  }
};

// Run security checks every 5 minutes
setInterval(checkSecurityAlerts, 5 * 60 * 1000);
```

## 📋 HIPAA Compliance

### Required Safeguards

#### Administrative Safeguards
- [x] Security Officer designation
- [x] Workforce training and access management
- [x] Contingency plan for emergencies
- [x] Regular security evaluations

#### Physical Safeguards
- [x] Facility access controls
- [x] Workstation security
- [x] Device and media controls

#### Technical Safeguards
- [x] Access control (Role-based)
- [x] Audit controls (Complete audit logging)
- [x] Integrity controls (Hash chains)
- [x] Person or entity authentication
- [x] Transmission security (HTTPS/TLS)

### Data Handling Procedures

```typescript
// HIPAA-compliant data access logging
const logDataAccess = async (
  userId: string, 
  action: string, 
  entityType: string, 
  entityId: string
) => {
  await supabase.from('audit_log').insert({
    actor_type: 'user',
    actor_id: userId,
    action,
    entity: entityType,
    entity_id: entityId,
    summary: `User accessed ${entityType} record`,
    details: {
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      ipAddress: await getUserIpAddress()
    }
  });
};

// Automatic data access logging
const useAuditedQuery = (query: string, params: any) => {
  const { data, error } = useQuery(query, params);
  
  useEffect(() => {
    if (data && !error) {
      logDataAccess(
        currentUser.id,
        'read',
        'patient_data',
        params.patientId
      );
    }
  }, [data, error]);
  
  return { data, error };
};
```

## 🚨 Incident Response

### Security Incident Procedures

1. **Detection & Analysis**
   - Monitor security alerts
   - Analyze audit logs
   - Assess impact and scope

2. **Containment & Eradication**
   - Isolate affected systems
   - Revoke compromised credentials
   - Apply security patches

3. **Recovery**
   - Restore from clean backups
   - Verify system integrity
   - Monitor for persistent threats

4. **Post-Incident Activities**
   - Document lessons learned
   - Update security procedures
   - Conduct security training

### Emergency Contacts

```typescript
const SecurityContacts = {
  CISO: 'security@clinic.com',
  IT_ADMIN: 'admin@clinic.com',
  COMPLIANCE_OFFICER: 'compliance@clinic.com',
  LEGAL: 'legal@clinic.com'
};

const notifySecurityIncident = async (incident: SecurityIncident) => {
  const notifications = Object.entries(SecurityContacts).map(
    ([role, email]) => sendAlert({
      to: email,
      subject: `SECURITY INCIDENT: ${incident.type}`,
      body: `Incident detected at ${incident.timestamp}\n\nDetails: ${incident.description}`,
      priority: 'HIGH'
    })
  );
  
  await Promise.all(notifications);
};
```

## 🔒 Security Testing

### Automated Security Scans

```typescript
// Security test suite
describe('Security Tests', () => {
  test('SQL injection prevention', async () => {
    const maliciousInput = "'; DROP TABLE patients; --";
    
    const { error } = await supabase
      .from('patients')
      .select()
      .ilike('first_name', maliciousInput);
    
    expect(error).toBeNull(); // Query should be safely parameterized
  });

  test('XSS prevention', () => {
    const maliciousScript = '<script>alert("XSS")</script>';
    const sanitized = sanitizeInput(maliciousScript);
    
    expect(sanitized).not.toContain('<script>');
    expect(sanitized).not.toContain('alert');
  });

  test('Access control enforcement', async () => {
    // Test that reception user cannot access dosages
    await signInAsRole('reception');
    
    const { data, error } = await supabase
      .from('dosages')
      .select();
    
    expect(data).toHaveLength(0); // Should be empty due to RLS
  });
});
```

### Penetration Testing Checklist

- [ ] Authentication bypass attempts
- [ ] Authorization escalation tests
- [ ] SQL injection vulnerability scans
- [ ] Cross-site scripting (XSS) tests
- [ ] Cross-site request forgery (CSRF) tests
- [ ] Session management security
- [ ] Input validation testing
- [ ] File upload security tests
- [ ] API endpoint security assessment

---

**🔒 Remember**: Security is an ongoing process. Regularly review and update these policies as threats evolve and new features are added to the system.