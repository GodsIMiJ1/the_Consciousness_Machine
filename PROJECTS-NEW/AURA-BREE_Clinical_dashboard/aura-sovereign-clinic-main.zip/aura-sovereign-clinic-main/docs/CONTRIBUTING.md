# Contributing to MethaClinic

Thank you for your interest in contributing to MethaClinic! This guide will help you get started with development, testing, and contributing to our secure clinic management system.

## 🚀 Quick Start

### Prerequisites

- **Node.js** 18+ and npm
- **Git** for version control
- **Supabase CLI** for database operations
- **Visual Studio Code** (recommended) with extensions:
  - TypeScript and JavaScript Language Features
  - Tailwind CSS IntelliSense
  - ES7+ React/Redux/React-Native snippets
  - Prettier - Code formatter
  - ESLint

### Development Setup

1. **Clone and Setup**
   ```bash
   git clone <repository-url>
   cd methadone-clinic-dashboard
   npm install
   ```

2. **Environment Configuration**
   ```bash
   # Copy environment template
   cp .env.example .env.local
   
   # Update with your Supabase credentials
   # Note: Credentials are embedded in src/integrations/supabase/client.ts
   ```

3. **Database Setup**
   ```bash
   # Install Supabase CLI
   npm install -g @supabase/cli
   
   # Start local development database
   supabase start
   
   # Run migrations
   supabase db reset
   ```

4. **Start Development**
   ```bash
   npm run dev
   ```

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── ui/             # shadcn/ui base components
│   ├── DashboardLayout.tsx
│   ├── PatientStatusGrid.tsx
│   └── ...
├── pages/              # Route components (main application pages)
│   ├── Index.tsx       # Dashboard home page
│   ├── Patients.tsx    # Patient management
│   ├── Dosages.tsx     # Medication tracking
│   ├── Settings.tsx    # System configuration
│   └── ...
├── hooks/              # Custom React hooks
│   ├── useRealtimeCheckins.ts
│   ├── useOfflineCache.ts
│   ├── useStaffProfile.ts
│   └── ...
├── utils/              # Utility functions
│   ├── exports.ts      # CSV/PDF export utilities
│   └── ...
├── integrations/       # External service integrations
│   └── supabase/       # Supabase client and types
└── ...
```

## 🎨 Design System

MethaClinic uses a comprehensive design system built on Tailwind CSS and shadcn/ui.

### Design Tokens

Always use semantic design tokens from `src/index.css`:

```css
/* ✅ Good - Use semantic tokens */
.button-primary {
  @apply bg-primary text-primary-foreground hover:bg-primary/90;
}

/* ❌ Bad - Direct color values */
.button-primary {
  @apply bg-blue-600 text-white hover:bg-blue-700;
}
```

### Component Variants

Create reusable component variants using `class-variance-authority`:

```typescript
// components/ui/button.tsx
import { cva, type VariantProps } from "class-variance-authority";

const buttonVariants = cva(
  "inline-flex items-center justify-center rounded-md transition-colors",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);
```

### Dark Mode Support

All components must support both light and dark modes:

```css
/* Light mode */
.card {
  @apply bg-card text-card-foreground border border-border;
}

/* Dark mode automatically handled by CSS variables */
:root.dark {
  --card: 222.2 84% 4.9%;
  --card-foreground: 210 40% 98%;
}
```

## 🧪 Testing Standards

### Testing Philosophy

- **Unit Tests**: Individual component and utility function testing
- **Integration Tests**: Database operations and API interactions
- **E2E Tests**: Complete user workflows and role-based access
- **Security Tests**: Authentication, authorization, and data protection

### Writing Tests

#### Component Tests

```typescript
// __tests__/components/PatientCard.test.tsx
import { render, screen } from '@testing-library/react';
import { PatientCard } from '@/components/PatientCard';

describe('PatientCard', () => {
  const mockPatient = {
    id: '123',
    first_name: 'John',
    last_name: 'Doe',
    mrn: 'MRN001',
    date_of_birth: '1990-01-01'
  };

  test('displays patient information correctly', () => {
    render(<PatientCard patient={mockPatient} />);
    
    expect(screen.getByText('John Doe')).toBeInTheDocument();
    expect(screen.getByText('MRN001')).toBeInTheDocument();
  });

  test('handles missing patient data gracefully', () => {
    render(<PatientCard patient={null} />);
    
    expect(screen.getByText(/no patient data/i)).toBeInTheDocument();
  });
});
```

#### Cypress E2E Tests

```typescript
// cypress/e2e/patient-management.cy.ts
describe('Patient Management', () => {
  beforeEach(() => {
    cy.login('clinician@test.com', 'Password123!');
    cy.visit('/patients');
  });

  it('should create a new patient', () => {
    cy.findByRole('button', { name: /add patient/i }).click();
    
    cy.findByLabelText(/first name/i).type('Jane');
    cy.findByLabelText(/last name/i).type('Smith');
    cy.findByLabelText(/mrn/i).type('MRN002');
    
    cy.findByRole('button', { name: /save/i }).click();
    
    cy.findByText('Jane Smith').should('be.visible');
    cy.findByText('MRN002').should('be.visible');
  });

  it('should validate required fields', () => {
    cy.findByRole('button', { name: /add patient/i }).click();
    cy.findByRole('button', { name: /save/i }).click();
    
    cy.findByText(/first name is required/i).should('be.visible');
    cy.findByText(/last name is required/i).should('be.visible');
  });
});
```

#### Security Tests

```typescript
// __tests__/security/rls.test.ts
describe('Row Level Security', () => {
  test('reception cannot access dosages', async () => {
    const receptionUser = await createTestUser('reception');
    
    const { data, error } = await supabase
      .auth
      .signInWithPassword({
        email: receptionUser.email,
        password: 'testpassword'
      });
      
    expect(error).toBeNull();
    
    const { data: dosages } = await supabase
      .from('dosages')
      .select();
      
    expect(dosages).toHaveLength(0); // Should be empty due to RLS
  });
});
```

### Running Tests

```bash
# Unit and integration tests
npm test

# Watch mode for development
npm run test:watch

# E2E tests
npm run e2e

# Open Cypress UI
npm run e2e:open

# Security tests
npm run test:security

# Coverage report
npm run test:coverage
```

## 🔒 Security Guidelines

### Authentication & Authorization

```typescript
// Always verify user permissions before sensitive operations
const useRequireRole = (requiredRole: 'admin' | 'clinician' | 'reception') => {
  const { data: profile } = useStaffProfile();
  
  useEffect(() => {
    if (profile && profile.role !== requiredRole && profile.role !== 'admin') {
      throw new Error(`Access denied. Required role: ${requiredRole}`);
    }
  }, [profile, requiredRole]);
  
  return profile;
};

// Usage in components
const DosagePage = () => {
  const profile = useRequireRole('clinician'); // Only clinicians can access
  
  if (!profile) return <div>Loading...</div>;
  
  return <DosageManagement />;
};
```

### Data Handling

```typescript
// Always validate and sanitize inputs
import { z } from 'zod';

const PatientSchema = z.object({
  first_name: z.string().min(1).max(100).regex(/^[a-zA-Z\s'-]+$/),
  last_name: z.string().min(1).max(100).regex(/^[a-zA-Z\s'-]+$/),
  date_of_birth: z.string().datetime(),
  mrn: z.string().regex(/^[A-Z0-9]{6,12}$/)
});

const createPatient = async (data: unknown) => {
  // Validate input
  const validatedData = PatientSchema.parse(data);
  
  // Use Supabase client (never raw SQL)
  const { data: patient, error } = await supabase
    .from('patients')
    .insert(validatedData)
    .select()
    .single();
    
  if (error) throw error;
  return patient;
};
```

### Audit Logging

```typescript
// All data modifications must be logged
const useAuditLogger = () => {
  const { data: profile } = useStaffProfile();
  
  const logAction = useCallback(async (
    action: string,
    entity: string,
    entityId: string,
    summary: string,
    details?: any
  ) => {
    await supabase.from('audit_log').insert({
      actor_type: 'user',
      actor_id: profile?.user_id,
      action,
      entity,
      entity_id: entityId,
      summary,
      details
    });
  }, [profile]);
  
  return { logAction };
};
```

## 📝 Code Style Guidelines

### TypeScript Standards

```typescript
// Use strict typing
interface Patient {
  id: string;
  first_name: string;
  last_name: string;
  date_of_birth: string; // ISO date string
  mrn: string;
  active: boolean;
  created_at: string;
  updated_at: string;
}

// Prefer type unions over enums for simple cases
type Role = 'admin' | 'clinician' | 'reception';
type VisitStatus = 'waiting' | 'active' | 'complete' | 'no_show' | 'cancelled';

// Use generic types for reusable components
interface DataTableProps<T> {
  data: T[];
  columns: ColumnDef<T>[];
  onRowSelect?: (row: T) => void;
}

const DataTable = <T,>({ data, columns, onRowSelect }: DataTableProps<T>) => {
  // Component implementation
};
```

### React Patterns

```typescript
// Use custom hooks for complex logic
const usePatients = () => {
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  
  const fetchPatients = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await supabase
        .from('patients')
        .select('*')
        .eq('active', true)
        .order('last_name');
      
      setPatients(data || []);
    } catch (error) {
      toast.error('Failed to load patients');
    } finally {
      setLoading(false);
    }
  }, []);
  
  useEffect(() => {
    fetchPatients();
  }, [fetchPatients]);
  
  return { patients, loading, refetch: fetchPatients };
};

// Prefer composition over complex props
const PatientCard = ({ patient }: { patient: Patient }) => (
  <Card>
    <CardHeader>
      <PatientName patient={patient} />
      <PatientMRN mrn={patient.mrn} />
    </CardHeader>
    <CardContent>
      <PatientDetails patient={patient} />
    </CardContent>
  </Card>
);
```

### File Organization

```
components/
├── ui/                 # Base components (shadcn/ui)
├── forms/             # Form-specific components
│   ├── PatientForm.tsx
│   └── DosageForm.tsx
├── tables/            # Data table components
│   ├── PatientsTable.tsx
│   └── VisitsTable.tsx
└── charts/            # Chart and visualization components
    ├── AttendanceChart.tsx
    └── DosageChart.tsx
```

## 🔄 Git Workflow

### Branch Naming

```bash
# Feature branches
feature/patient-search-enhancement
feature/dosage-validation

# Bug fixes
fix/login-redirect-issue
fix/date-formatting-bug

# Security patches
security/xss-prevention
security/rls-policy-update

# Documentation
docs/api-documentation
docs/deployment-guide
```

### Commit Messages

Follow the [Conventional Commits](https://www.conventionalcommits.org/) specification:

```bash
# Features
feat(patients): add advanced search functionality
feat(auth): implement role-based dashboard

# Bug fixes
fix(dosages): correct date validation logic
fix(ui): resolve mobile responsive issues

# Security
security(auth): implement session timeout
security(rls): strengthen dosage access policies

# Documentation
docs(api): add edge functions documentation
docs(setup): update development environment guide

# Tests
test(e2e): add patient management workflows
test(unit): increase form validation coverage
```

### Pull Request Process

1. **Create Feature Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make Changes & Test**
   ```bash
   npm test
   npm run e2e
   npm run lint
   npm run type-check
   ```

3. **Commit Changes**
   ```bash
   git add .
   git commit -m "feat(component): add new functionality"
   ```

4. **Push & Create PR**
   ```bash
   git push origin feature/your-feature-name
   ```

5. **PR Requirements**
   - [ ] All tests passing
   - [ ] Code coverage maintained
   - [ ] Security review completed
   - [ ] Documentation updated
   - [ ] Breaking changes documented

### Code Review Checklist

#### Security Review
- [ ] Input validation implemented
- [ ] Authentication verified
- [ ] Authorization checked
- [ ] Audit logging added
- [ ] No sensitive data in logs

#### Performance Review
- [ ] Efficient database queries
- [ ] Proper caching strategies
- [ ] Bundle size impact minimal
- [ ] No memory leaks

#### Code Quality Review
- [ ] TypeScript strict mode
- [ ] Error handling comprehensive
- [ ] Components properly tested
- [ ] Documentation updated

## 🚀 Deployment Process

### Development Deployment

```bash
# Build and test
npm run build
npm run test:coverage

# Deploy to staging
npm run deploy:staging

# Run smoke tests
npm run test:smoke
```

### Production Deployment

```bash
# Security checklist
npm run security:scan
npm run test:security

# Performance audit
npm run audit:performance

# Deploy to production
npm run deploy:production

# Monitor deployment
npm run monitor:health
```

## 📚 Learning Resources

### Required Reading
- [React Documentation](https://react.dev/)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Supabase Documentation](https://supabase.com/docs)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [shadcn/ui Components](https://ui.shadcn.com/)

### Security Resources
- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [HIPAA Security Guidelines](https://www.hhs.gov/hipaa/for-professionals/security/index.html)
- [Supabase Security Best Practices](https://supabase.com/docs/guides/auth/row-level-security)

### Testing Resources
- [Testing Library Documentation](https://testing-library.com/)
- [Cypress Best Practices](https://docs.cypress.io/guides/references/best-practices)
- [Jest Testing Framework](https://jestjs.io/docs/getting-started)

## 🤝 Community Guidelines

### Communication
- Use clear, professional language
- Be respectful and inclusive
- Focus on constructive feedback
- Ask questions when unclear

### Issue Reporting
1. Search existing issues first
2. Use appropriate templates
3. Include reproduction steps
4. Provide environment details
5. Add relevant labels

### Feature Requests
1. Explain the use case
2. Consider security implications
3. Provide mockups if applicable
4. Discuss implementation approach

## 📞 Support

### Development Support
- **Tech Lead**: tech-lead@clinic.com
- **Security Team**: security@clinic.com
- **DevOps**: devops@clinic.com

### Resources
- GitHub Issues for bug reports
- Discord/Slack for real-time discussion
- Weekly development meetings
- Monthly security reviews

---

**🚀 Thank you for contributing to MethaClinic! Together we're building a secure, reliable system for healthcare providers.**