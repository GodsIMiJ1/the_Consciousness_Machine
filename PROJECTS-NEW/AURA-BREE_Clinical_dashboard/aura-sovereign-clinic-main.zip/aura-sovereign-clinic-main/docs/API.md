# API Documentation

MethaClinic uses Supabase Edge Functions for server-side operations, automated reporting, and background tasks. All functions run on the Deno runtime with TypeScript support.

## 🔗 Base URL

```
https://wixzqilqithhlybhyite.supabase.co/functions/v1/
```

## 🔐 Authentication

All functions require proper authentication unless explicitly configured as public. Include the Authorization header with a valid JWT token:

```typescript
const { data, error } = await supabase.functions.invoke('function-name', {
  body: { /* your data */ }
});
```

## 📊 Edge Functions

### 1. Weekly Compliance Reports

**Endpoint**: `/reports-weekly`  
**Method**: `POST`  
**Authentication**: Required (Admin/Clinician only)

Generates automated weekly compliance reports with attendance metrics, dosage analytics, and regulatory summaries.

#### Request

```typescript
// Invoke via Supabase client
const { data, error } = await supabase.functions.invoke('reports-weekly', {
  body: {
    startDate?: string,  // ISO date, defaults to 7 days ago
    endDate?: string,    // ISO date, defaults to now
    includePatientData?: boolean, // Default: false
    format?: 'json' | 'pdf'       // Default: 'json'
  }
});
```

#### Response

```typescript
interface WeeklyReportResponse {
  success: boolean;
  data: {
    summary: {
      attendancePct: number;        // Overall attendance percentage
      missed: number;               // Number of missed appointments
      medianDose: number;          // Median dosage in mg
      total: number;               // Total scheduled visits
      since: string;               // Report start date
    };
    metrics: {
      patientCount: number;
      averageDailyCheckIns: number;
      complianceRate: number;
      dosageConsistency: number;
    };
    reportId: string;             // Generated report identifier
    generatedAt: string;          // ISO timestamp
  };
  error?: string;
}
```

#### Usage Example

```typescript
// Generate weekly report
const generateWeeklyReport = async () => {
  const { data, error } = await supabase.functions.invoke('reports-weekly', {
    body: {
      includePatientData: true,
      format: 'json'
    }
  });
  
  if (error) {
    console.error('Report generation failed:', error);
    return;
  }
  
  console.log('Compliance Report:', data.summary);
  // Handle report data...
};
```

### 2. Nightly Backup System

**Endpoint**: `/backups-nightly`  
**Method**: `POST`  
**Authentication**: Service Role (System only)

Performs encrypted backups of critical clinic data to secure Supabase storage.

#### Request

```typescript
const { data, error } = await supabase.functions.invoke('backups-nightly', {
  body: {
    tables?: string[],           // Specific tables to backup
    retentionDays?: number,      // Backup retention period
    compression?: boolean,       // Enable compression
    encryption?: boolean         // Enable encryption (recommended)
  }
});
```

#### Response

```typescript
interface BackupResponse {
  success: boolean;
  data: {
    backupId: string;           // Unique backup identifier
    filePath: string;           // Storage path
    fileSize: number;           // Backup size in bytes
    recordCount: {              // Records backed up per table
      patients: number;
      visits: number;
      dosages: number;
      staff: number;
      checkins: number;
      audit_log: number;
    };
    encryptionEnabled: boolean;
    compressionRatio?: number;  // If compression enabled
    executionTime: number;      // Milliseconds
  };
  error?: string;
}
```

#### Automated Scheduling

The backup function is scheduled to run automatically via pg_cron:

```sql
-- Schedule nightly backups at 2:00 AM UTC
SELECT cron.schedule(
  'nightly-backup',
  '0 2 * * *',
  $$
  SELECT net.http_post(
    url := 'https://wixzqilqithhlybhyite.supabase.co/functions/v1/backups-nightly',
    headers := '{"Authorization": "Bearer ' || current_setting('app.service_role_key') || '"}'::jsonb,
    body := '{"retentionDays": 30, "compression": true, "encryption": true}'::jsonb
  );
  $$
);
```

## 🔧 Function Development

### Local Development

```bash
# Install Supabase CLI
npm install -g @supabase/cli

# Start local development
supabase start
supabase functions serve

# Deploy function
supabase functions deploy function-name
```

### Function Template

```typescript
import 'jsr:@supabase/functions-js/edge-runtime.d.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Initialize Supabase client
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    // Parse request body
    const { data: requestData } = await req.json();
    
    // Your function logic here
    const result = await processFunctionLogic(supabase, requestData);

    return new Response(
      JSON.stringify({ success: true, data: result }),
      { 
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    );

  } catch (error) {
    console.error('Function error:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 500,
        headers: { 
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    );
  }
});
```

## 🔒 Security Considerations

### Authentication & Authorization

```typescript
// Verify user permissions in functions
const verifyUserRole = async (supabase: any, requiredRole: string) => {
  const { data: { user }, error } = await supabase.auth.getUser();
  
  if (error || !user) {
    throw new Error('Unauthorized');
  }

  const { data: staff } = await supabase
    .from('staff')
    .select('role, active')
    .eq('user_id', user.id)
    .single();

  if (!staff?.active || staff.role !== requiredRole) {
    throw new Error('Insufficient permissions');
  }

  return staff;
};
```

### Rate Limiting

```typescript
// Basic rate limiting implementation
const rateLimitCache = new Map<string, number[]>();

const checkRateLimit = (userId: string, limit = 10, window = 60000) => {
  const now = Date.now();
  const userRequests = rateLimitCache.get(userId) || [];
  
  // Remove old requests outside window
  const recentRequests = userRequests.filter(time => now - time < window);
  
  if (recentRequests.length >= limit) {
    throw new Error('Rate limit exceeded');
  }
  
  recentRequests.push(now);
  rateLimitCache.set(userId, recentRequests);
};
```

### Input Validation

```typescript
import { z } from 'https://esm.sh/zod';

const ReportRequestSchema = z.object({
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  includePatientData: z.boolean().default(false),
  format: z.enum(['json', 'pdf']).default('json')
});

// Validate request data
const validateRequest = (data: unknown) => {
  try {
    return ReportRequestSchema.parse(data);
  } catch (error) {
    throw new Error(`Invalid request data: ${error.message}`);
  }
};
```

## 📝 Error Handling

### Standard Error Responses

```typescript
interface ErrorResponse {
  success: false;
  error: {
    code: string;           // Error code for client handling
    message: string;        // Human-readable message
    details?: any;          // Additional error context
    timestamp: string;      // ISO timestamp
  };
}

// Error types
const ErrorCodes = {
  UNAUTHORIZED: 'UNAUTHORIZED',
  INVALID_INPUT: 'INVALID_INPUT',
  DATABASE_ERROR: 'DATABASE_ERROR',
  RATE_LIMITED: 'RATE_LIMITED',
  INTERNAL_ERROR: 'INTERNAL_ERROR'
} as const;
```

### Logging

```typescript
const logError = async (supabase: any, error: Error, context: any) => {
  await supabase.from('function_logs').insert({
    level: 'error',
    message: error.message,
    stack: error.stack,
    context: JSON.stringify(context),
    timestamp: new Date().toISOString()
  });
};
```

## 📊 Monitoring & Analytics

### Function Metrics

```typescript
// Track function performance
const trackMetrics = async (supabase: any, functionName: string, metrics: any) => {
  await supabase.from('function_metrics').insert({
    function_name: functionName,
    execution_time: metrics.duration,
    memory_usage: metrics.memory,
    success: metrics.success,
    timestamp: new Date().toISOString()
  });
};
```

### Health Checks

```typescript
// Function health check endpoint
export const healthCheck = async () => {
  return {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    uptime: performance.now(),
    checks: {
      database: await checkDatabaseConnection(),
      storage: await checkStorageAccess(),
      memory: await checkMemoryUsage()
    }
  };
};
```

## 🚀 Deployment

### CI/CD Pipeline

```yaml
# .github/workflows/deploy-functions.yml
name: Deploy Edge Functions
on:
  push:
    branches: [main]
    paths: ['supabase/functions/**']

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Setup Supabase CLI
        uses: supabase/setup-cli@v1
      - name: Deploy functions
        run: |
          supabase functions deploy --project-ref ${{ secrets.SUPABASE_PROJECT_REF }}
        env:
          SUPABASE_ACCESS_TOKEN: ${{ secrets.SUPABASE_ACCESS_TOKEN }}
```

### Environment Management

```typescript
// Environment-specific configuration
const getConfig = () => {
  const env = Deno.env.get('ENVIRONMENT') || 'development';
  
  const configs = {
    development: {
      logLevel: 'debug',
      rateLimit: { requests: 100, window: 60000 }
    },
    production: {
      logLevel: 'warn',
      rateLimit: { requests: 10, window: 60000 }
    }
  };
  
  return configs[env as keyof typeof configs];
};
```

## 📚 Testing

### Unit Tests

```typescript
// Function unit tests
import { assertEquals } from 'https://deno.land/std/testing/asserts.ts';

Deno.test('Weekly report generation', async () => {
  const mockData = {
    visits: [{ status: 'complete' }, { status: 'no_show' }],
    dosages: [{ amount_mg: 30 }, { amount_mg: 40 }]
  };
  
  const result = calculateMetrics(mockData);
  
  assertEquals(result.attendancePct, 50);
  assertEquals(result.medianDose, 35);
});
```

### Integration Tests

```typescript
// Integration test with test database
Deno.test('Backup function integration', async () => {
  const testSupabase = createTestClient();
  
  // Create test data
  await seedTestData(testSupabase);
  
  // Run backup function
  const result = await runBackupFunction(testSupabase);
  
  // Verify results
  assertEquals(result.success, true);
  assert(result.data.backupId);
});
```

---

**📝 Note**: All Edge Functions automatically include comprehensive logging and error handling. Check the Supabase dashboard for real-time logs and performance metrics.