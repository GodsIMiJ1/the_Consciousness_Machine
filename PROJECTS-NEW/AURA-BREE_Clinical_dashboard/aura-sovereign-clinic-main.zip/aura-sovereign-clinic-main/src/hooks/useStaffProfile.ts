import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/AuthProvider';

export interface StaffProfile {
  user_id: string;
  name: string;
  role: 'admin' | 'clinician' | 'reception';
  active: boolean;
  created_at: string;
  updated_at: string;
}

export const useStaffProfile = () => {
  const { user } = useAuth();

  return useQuery({
    queryKey: ['staff-profile', user?.id],
    queryFn: async (): Promise<StaffProfile | null> => {
      if (!user?.id) return null;

      const { data, error } = await supabase
        .from('staff')
        .select('user_id, name, role, active, created_at, updated_at')
        .eq('user_id', user.id)
        .eq('active', true)
        .single();

      if (error) {
        console.error('Error fetching staff profile:', error);
        return null;
      }

      return data as StaffProfile;
    },
    enabled: !!user?.id,
  });
};