import { useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useQueryClient } from '@tanstack/react-query';
import { useToast } from '@/hooks/use-toast';

export const useRealtimeCheckins = () => {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    const channel = supabase
      .channel('checkins-stream')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'checkins' },
        async (payload) => {
          const checkin = payload.new;
          console.log('New check-in detected:', checkin);

          // Get patient info
          const { data: patient } = await supabase
            .from('patients')
            .select('first_name, last_name, mrn')
            .eq('id', checkin.patient_id)
            .single();

          if (patient) {
            toast({
              title: "Patient Check-in Detected",
              description: `${patient.first_name} ${patient.last_name} (${patient.mrn}) has arrived`,
            });

            // Check if visit exists for today
            const today = new Date().toISOString().split('T')[0];
            const { data: existingVisit } = await supabase
              .from('visits')
              .select('id')
              .eq('patient_id', checkin.patient_id)
              .gte('arrived_at', `${today}T00:00:00.000Z`)
              .lt('arrived_at', `${today}T23:59:59.999Z`)
              .single();

            if (!existingVisit) {
              // Create new visit
              await supabase
                .from('visits')
                .insert({
                  patient_id: checkin.patient_id,
                  triage_status: 'waiting',
                  arrived_at: checkin.arrived_at
                });
            } else {
              // Update existing visit status
              await supabase
                .from('visits')
                .update({ triage_status: 'waiting' })
                .eq('id', existingVisit.id);
            }

            // Invalidate relevant queries
            queryClient.invalidateQueries({ queryKey: ['visits'] });
            queryClient.invalidateQueries({ queryKey: ['patients'] });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [queryClient, toast]);
};