import { useState, useEffect } from 'react';

// Simple in-memory cache for offline functionality
// In production, use idb-keyval or similar IndexedDB wrapper
class OfflineCache {
  private cache = new Map<string, any>();
  private timestamps = new Map<string, number>();

  set(key: string, value: any) {
    this.cache.set(key, value);
    this.timestamps.set(key, Date.now());
    // Store in localStorage for persistence
    try {
      localStorage.setItem(`offline_cache_${key}`, JSON.stringify({
        value,
        timestamp: Date.now()
      }));
    } catch (e) {
      console.warn('Failed to store in localStorage:', e);
    }
  }

  get(key: string) {
    // Try memory first, then localStorage
    if (this.cache.has(key)) {
      return this.cache.get(key);
    }
    
    try {
      const stored = localStorage.getItem(`offline_cache_${key}`);
      if (stored) {
        const { value, timestamp } = JSON.parse(stored);
        // Only use if less than 5 minutes old
        if (Date.now() - timestamp < 5 * 60 * 1000) {
          this.cache.set(key, value);
          this.timestamps.set(key, timestamp);
          return value;
        }
      }
    } catch (e) {
      console.warn('Failed to read from localStorage:', e);
    }
    
    return null;
  }

  clear(key?: string) {
    if (key) {
      this.cache.delete(key);
      this.timestamps.delete(key);
      localStorage.removeItem(`offline_cache_${key}`);
    } else {
      this.cache.clear();
      this.timestamps.clear();
      // Clear all offline cache items
      Object.keys(localStorage).forEach(key => {
        if (key.startsWith('offline_cache_')) {
          localStorage.removeItem(key);
        }
      });
    }
  }
}

const cache = new OfflineCache();

export function useOfflineCache<T>(key: string, fetcher: () => Promise<T>) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  useEffect(() => {
    let mounted = true;

    const loadData = async () => {
      setLoading(true);
      setError(null);

      // Try to load from cache first
      const cached = cache.get(key);
      if (cached && mounted) {
        setData(cached);
        setLoading(false);
      }

      // If online, try to fetch fresh data
      if (navigator.onLine) {
        try {
          const fresh = await fetcher();
          if (mounted) {
            setData(fresh);
            cache.set(key, fresh);
            setLoading(false);
          }
        } catch (err) {
          if (mounted) {
            setError(err as Error);
            // If we have cached data, keep using it
            if (!cached) {
              setLoading(false);
            }
          }
        }
      } else {
        // Offline mode
        if (!cached && mounted) {
          setError(new Error('No cached data available offline'));
        }
        setLoading(false);
      }
    };

    loadData();
    return () => { mounted = false; };
  }, [key, fetcher]);

  const refetch = () => {
    if (navigator.onLine) {
      const loadFresh = async () => {
        try {
          const fresh = await fetcher();
          setData(fresh);
          cache.set(key, fresh);
          setError(null);
        } catch (err) {
          setError(err as Error);
        }
      };
      loadFresh();
    }
  };

  return { data, loading, error, isOffline, refetch };
}
