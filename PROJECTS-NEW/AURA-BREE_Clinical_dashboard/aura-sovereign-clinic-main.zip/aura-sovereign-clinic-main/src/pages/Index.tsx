import { DashboardLayout } from "@/components/DashboardLayout";
import { StatsOverview } from "@/components/StatsOverview";
import { PatientStatusGrid } from "@/components/PatientStatusGrid";
import { RecentActivity } from "@/components/RecentActivity";

const Index = () => {
  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            Sovereign Methadone Clinic Dashboard
          </h1>
          <p className="text-muted-foreground">
            Real-time patient monitoring with AURA-BREE integration • All data remains locally secured
          </p>
        </div>

        <StatsOverview />
        
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          <div className="xl:col-span-2">
            <PatientStatusGrid />
          </div>
          <div>
            <RecentActivity />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Index;
