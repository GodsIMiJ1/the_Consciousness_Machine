import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Clock, User, Activity, Filter, RefreshCw } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

const Appointments = () => {
  const [visits, setVisits] = useState([]);
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState("all");
  const { toast } = useToast();

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      
      const [visitsResult, patientsResult] = await Promise.all([
        supabase
          .from('visits')
          .select(`
            *,
            patients:patient_id (first_name, last_name, mrn)
          `)
          .order('arrived_at', { ascending: false }),
        supabase
          .from('patients')
          .select('id, first_name, last_name, mrn')
      ]);

      if (visitsResult.error) throw visitsResult.error;
      if (patientsResult.error) throw patientsResult.error;

      setVisits(visitsResult.data || []);
      setPatients(patientsResult.data || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to load appointments",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateVisitStatus = async (visitId, newStatus) => {
    try {
      const { error } = await supabase
        .from('visits')
        .update({ triage_status: newStatus })
        .eq('id', visitId);

      if (error) throw error;

      setVisits(prev => prev.map(visit => 
        visit.id === visitId ? { ...visit, triage_status: newStatus } : visit
      ));

      toast({
        title: "Success",
        description: "Visit status updated"
      });
    } catch (error) {
      console.error('Error updating visit:', error);
      toast({
        title: "Error",
        description: "Failed to update visit status",
        variant: "destructive"
      });
    }
  };

  const filteredVisits = visits.filter(visit => 
    statusFilter === "all" || visit.triage_status === statusFilter
  );

  const getStatusColor = (status) => {
    switch (status) {
      case 'waiting': return 'bg-warning text-warning-foreground';
      case 'in_progress': return 'bg-primary text-primary-foreground';
      case 'completed': return 'bg-success text-success-foreground';
      case 'cancelled': return 'bg-destructive text-destructive-foreground';
      default: return 'bg-secondary text-secondary-foreground';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'waiting': return Clock;
      case 'in_progress': return Activity;
      case 'completed': return Calendar;
      default: return Clock;
    }
  };

  const todayVisits = visits.filter(visit => 
    new Date(visit.arrived_at).toDateString() === new Date().toDateString()
  );

  const stats = [
    {
      title: "Today's Visits",
      value: todayVisits.length,
      icon: Calendar,
      color: "text-primary"
    },
    {
      title: "Waiting",
      value: visits.filter(v => v.triage_status === 'waiting').length,
      icon: Clock,
      color: "text-warning"
    },
    {
      title: "In Progress",
      value: visits.filter(v => v.triage_status === 'in_progress').length,
      icon: Activity,
      color: "text-primary"
    },
    {
      title: "Completed Today",
      value: todayVisits.filter(v => v.triage_status === 'completed').length,
      icon: Calendar,
      color: "text-success"
    }
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Appointments</h1>
            <p className="text-muted-foreground">
              Track patient visits and appointment status
            </p>
          </div>
          <Button onClick={fetchData} variant="outline">
            <RefreshCw className="w-4 h-4 mr-2" />
            Refresh
          </Button>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      {stat.title}
                    </p>
                    <p className="text-3xl font-bold text-foreground">
                      {stat.value}
                    </p>
                  </div>
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Visit Queue</CardTitle>
                <CardDescription>
                  {filteredVisits.length} visits found
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[150px]">
                    <Filter className="w-4 h-4 mr-2" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="waiting">Waiting</SelectItem>
                    <SelectItem value="in_progress">In Progress</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="cancelled">Cancelled</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Patient</TableHead>
                  <TableHead>MRN</TableHead>
                  <TableHead>Arrival Time</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      Loading visits...
                    </TableCell>
                  </TableRow>
                ) : filteredVisits.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8">
                      No visits found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredVisits.map((visit) => {
                    const StatusIcon = getStatusIcon(visit.triage_status);
                    return (
                      <TableRow key={visit.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                              <User className="w-4 h-4 text-primary" />
                            </div>
                            <div>
                              <div className="font-medium">
                                {visit.patients?.first_name} {visit.patients?.last_name}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="font-mono">
                          {visit.patients?.mrn}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-muted-foreground" />
                            <div>
                              <div className="font-medium">
                                {new Date(visit.arrived_at).toLocaleDateString()}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {new Date(visit.arrived_at).toLocaleTimeString()}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={`${getStatusColor(visit.triage_status)} flex items-center gap-1 w-fit`}>
                            <StatusIcon className="w-3 h-3" />
                            {visit.triage_status.replace('_', ' ')}
                          </Badge>
                        </TableCell>
                        <TableCell className="max-w-[200px]">
                          <p className="text-sm text-muted-foreground truncate">
                            {visit.notes || "No notes"}
                          </p>
                        </TableCell>
                        <TableCell>
                          <Select
                            value={visit.triage_status}
                            onValueChange={(value) => updateVisitStatus(visit.id, value)}
                          >
                            <SelectTrigger className="w-[130px]">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="waiting">Waiting</SelectItem>
                              <SelectItem value="in_progress">In Progress</SelectItem>
                              <SelectItem value="completed">Completed</SelectItem>
                              <SelectItem value="cancelled">Cancelled</SelectItem>
                            </SelectContent>
                          </Select>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default Appointments;