import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Lock, Eye, FileText, Database, Users } from "lucide-react";

const Privacy = () => {
  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Privacy Policy</h1>
          <p className="text-muted-foreground">
            Understanding how we protect and handle your sensitive healthcare information
          </p>
        </div>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Shield className="w-6 h-6 text-primary" />
                <div>
                  <CardTitle>HIPAA Compliance</CardTitle>
                  <CardDescription>
                    Our commitment to healthcare privacy standards
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-foreground leading-relaxed">
                The Sovereign Methadone Clinic Management System is designed to be fully compliant with the Health Insurance Portability and Accountability Act (HIPAA) and other relevant healthcare privacy regulations. We implement comprehensive safeguards to protect patient health information.
              </p>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <h4 className="font-medium flex items-center gap-2">
                    <Lock className="w-4 h-4 text-success" />
                    Administrative Safeguards
                  </h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• Designated Privacy Officer</li>
                    <li>• Employee training programs</li>
                    <li>• Access management procedures</li>
                    <li>• Regular risk assessments</li>
                  </ul>
                </div>
                <div className="space-y-2">
                  <h4 className="font-medium flex items-center gap-2">
                    <Database className="w-4 h-4 text-primary" />
                    Technical Safeguards
                  </h4>
                  <ul className="text-sm text-muted-foreground space-y-1">
                    <li>• End-to-end encryption</li>
                    <li>• Secure authentication</li>
                    <li>• Audit logging</li>
                    <li>• Automatic session timeouts</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Eye className="w-6 h-6 text-accent" />
                <div>
                  <CardTitle>Data Collection & Usage</CardTitle>
                  <CardDescription>
                    What information we collect and how it's used
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Patient Information</h4>
                  <p className="text-sm text-muted-foreground">
                    We collect and store patient demographics, medical record numbers, visit information, 
                    dosage records, and treatment notes solely for the purpose of providing methadone 
                    treatment and maintaining required medical records.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Device Data</h4>
                  <p className="text-sm text-muted-foreground">
                    AURA-BREE device integration collects check-in data, location hints, and synchronization 
                    information to verify patient compliance and treatment adherence. This data is encrypted 
                    and stored securely within our local systems.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Staff Activity</h4>
                  <p className="text-sm text-muted-foreground">
                    All staff actions are logged for audit purposes, including login times, patient record 
                    access, and system modifications. This ensures accountability and maintains a complete 
                    audit trail as required by regulations.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Users className="w-6 h-6 text-warning" />
                <div>
                  <CardTitle>Access Controls</CardTitle>
                  <CardDescription>
                    Role-based permissions and data access policies
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Administrative Staff</h4>
                  <p className="text-sm text-muted-foreground">
                    Full system access including patient management, staff administration, 
                    system settings, and audit log review.
                  </p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Clinical Staff</h4>
                  <p className="text-sm text-muted-foreground">
                    Patient care access including visit management, dosage administration, 
                    and clinical notes. Cannot modify system settings or manage staff.
                  </p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-medium mb-2">Reception Staff</h4>
                  <p className="text-sm text-muted-foreground">
                    Limited access to patient check-in, appointment scheduling, 
                    and basic demographic information.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <FileText className="w-6 h-6 text-secondary" />
                <div>
                  <CardTitle>Data Retention & Disposal</CardTitle>
                  <CardDescription>
                    How long we keep your information and secure disposal practices
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Medical Records</h4>
                  <p className="text-sm text-muted-foreground">
                    Patient medical records are retained according to federal and state regulations, 
                    typically for a minimum of 7 years after the last treatment date or as required 
                    by applicable law.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Audit Logs</h4>
                  <p className="text-sm text-muted-foreground">
                    System audit logs are maintained for security and compliance purposes. 
                    Logs are retained for 2 years and then securely archived or destroyed 
                    according to our data retention schedule.
                  </p>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Secure Disposal</h4>
                  <p className="text-sm text-muted-foreground">
                    When data is no longer needed, it is securely destroyed using 
                    industry-standard methods including secure deletion, physical 
                    destruction of media, and certificate of destruction documentation.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Patient Rights</CardTitle>
              <CardDescription>
                Your rights regarding your healthcare information
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2"></div>
                  <div>
                    <p className="font-medium text-sm">Right to Access</p>
                    <p className="text-sm text-muted-foreground">
                      Request copies of your medical records and treatment information
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2"></div>
                  <div>
                    <p className="font-medium text-sm">Right to Amend</p>
                    <p className="text-sm text-muted-foreground">
                      Request corrections to inaccurate or incomplete information
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2"></div>
                  <div>
                    <p className="font-medium text-sm">Right to Accounting</p>
                    <p className="text-sm text-muted-foreground">
                      Receive a list of disclosures of your health information
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 rounded-full bg-primary mt-2"></div>
                  <div>
                    <p className="font-medium text-sm">Right to Restrict</p>
                    <p className="text-sm text-muted-foreground">
                      Request limits on how your health information is used or disclosed
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
              <CardDescription>
                How to reach us regarding privacy matters
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 text-sm">
                <div>
                  <p className="font-medium">Privacy Officer</p>
                  <p className="text-muted-foreground">Sovereign Methadone Clinic</p>
                </div>
                <div>
                  <p className="font-medium">For Privacy Complaints or Questions:</p>
                  <p className="text-muted-foreground">
                    Contact your clinic administrator or file a complaint with the 
                    U.S. Department of Health and Human Services if you believe 
                    your privacy rights have been violated.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Privacy;