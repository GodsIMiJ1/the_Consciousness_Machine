import { useState } from 'react';
import { DashboardLayout } from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Shield, Search, Filter, Calendar, FileText, Hash, User, Activity } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';

interface AuditEntry {
  id: string;
  ts: string;
  actor_type: string;
  actor_id: string | null;
  action: string;
  entity: string;
  entity_id: string | null;
  summary: string;
  hash: string;
  prev_hash: string | null;
  created_at: string;
}

const AuditLog = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [actionFilter, setActionFilter] = useState('');
  const [entityFilter, setEntityFilter] = useState('');
  const [dateRange, setDateRange] = useState('7'); // days

  // Fetch audit log entries
  const { data: auditEntries = [], isLoading } = useQuery({
    queryKey: ['audit-log', searchTerm, actionFilter, entityFilter, dateRange],
    queryFn: async (): Promise<AuditEntry[]> => {
      let query = supabase
        .from('audit_log')
        .select('*')
        .order('ts', { ascending: false });

      // Apply date range filter
      if (dateRange !== 'all') {
        const daysAgo = new Date();
        daysAgo.setDate(daysAgo.getDate() - parseInt(dateRange));
        query = query.gte('ts', daysAgo.toISOString());
      }

      // Apply search filter
      if (searchTerm) {
        query = query.or(`summary.ilike.%${searchTerm}%,action.ilike.%${searchTerm}%,entity.ilike.%${searchTerm}%`);
      }

      // Apply action filter
      if (actionFilter) {
        query = query.eq('action', actionFilter);
      }

      // Apply entity filter
      if (entityFilter) {
        query = query.eq('entity', entityFilter);
      }

      const { data, error } = await query.limit(100);
      if (error) throw error;
      return data || [];
    }
  });

  // Get unique actions and entities for filter dropdowns
  const { data: filterOptions } = useQuery({
    queryKey: ['audit-filter-options'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('audit_log')
        .select('action, entity');
      
      if (error) throw error;

      const actions = [...new Set(data?.map(entry => entry.action) || [])];
      const entities = [...new Set(data?.map(entry => entry.entity) || [])];

      return { actions, entities };
    }
  });

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  };

  const getActionBadgeVariant = (action: string) => {
    switch (action.toLowerCase()) {
      case 'create':
      case 'insert':
        return 'default';
      case 'update':
      case 'modify':
        return 'secondary';
      case 'delete':
      case 'remove':
        return 'destructive';
      case 'login':
      case 'authenticate':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  const getEntityIcon = (entity: string) => {
    switch (entity.toLowerCase()) {
      case 'patient':
      case 'patients':
        return <User className="h-3 w-3" />;
      case 'dosage':
      case 'dosages':
        return <Activity className="h-3 w-3" />;
      case 'visit':
      case 'visits':
        return <Calendar className="h-3 w-3" />;
      default:
        return <FileText className="h-3 w-3" />;
    }
  };

  const exportAuditLog = () => {
    // Create CSV content
    const headers = ['Timestamp', 'Actor Type', 'Action', 'Entity', 'Summary', 'Hash'];
    const csvContent = [
      headers.join(','),
      ...auditEntries.map(entry => [
        `"${formatDateTime(entry.ts)}"`,
        `"${entry.actor_type}"`,
        `"${entry.action}"`,
        `"${entry.entity}"`,
        `"${entry.summary.replace(/"/g, '""')}"`,
        `"${entry.hash}"`
      ].join(','))
    ].join('\n');

    // Download CSV
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `audit-log-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
              <Shield className="h-8 w-8 text-primary" />
              Audit Log
            </h1>
            <p className="text-muted-foreground">
              Immutable security trail • HIPAA compliance monitoring
            </p>
          </div>
          
          <Button onClick={exportAuditLog} variant="outline" className="gap-2">
            <FileText className="h-4 w-4" />
            Export CSV
          </Button>
        </div>

        {/* Filters Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Search & Filter
            </CardTitle>
            <CardDescription>
              Filter audit entries by content, action type, or date range
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <Label htmlFor="search">Search</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="search"
                    placeholder="Search entries..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="action">Action</Label>
                <Select value={actionFilter} onValueChange={setActionFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All actions" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All actions</SelectItem>
                    {filterOptions?.actions.map((action) => (
                      <SelectItem key={action} value={action}>
                        {action}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="entity">Entity</Label>
                <Select value={entityFilter} onValueChange={setEntityFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All entities" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">All entities</SelectItem>
                    {filterOptions?.entities.map((entity) => (
                      <SelectItem key={entity} value={entity}>
                        {entity}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="dateRange">Date Range</Label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Last 24 hours</SelectItem>
                    <SelectItem value="7">Last 7 days</SelectItem>
                    <SelectItem value="30">Last 30 days</SelectItem>
                    <SelectItem value="90">Last 90 days</SelectItem>
                    <SelectItem value="all">All time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Audit Entries Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Hash className="h-5 w-5" />
              Security Events
            </CardTitle>
            <CardDescription>
              Cryptographically secured audit trail with blockchain-style hashing
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="space-y-2">
                {[...Array(10)].map((_, i) => (
                  <div key={i} className="h-16 bg-muted/50 rounded animate-pulse" />
                ))}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Timestamp</TableHead>
                      <TableHead>Actor</TableHead>
                      <TableHead>Action</TableHead>
                      <TableHead>Entity</TableHead>
                      <TableHead>Summary</TableHead>
                      <TableHead>Integrity Hash</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {auditEntries.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                          No audit entries found
                        </TableCell>
                      </TableRow>
                    ) : (
                      auditEntries.map((entry) => (
                        <TableRow key={entry.id}>
                          <TableCell className="font-mono text-sm">
                            {formatDateTime(entry.ts)}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">
                              {entry.actor_type}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Badge variant={getActionBadgeVariant(entry.action)}>
                              {entry.action}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {getEntityIcon(entry.entity)}
                              <span>{entry.entity}</span>
                            </div>
                          </TableCell>
                          <TableCell className="max-w-80">
                            <div className="truncate" title={entry.summary}>
                              {entry.summary}
                            </div>
                          </TableCell>
                          <TableCell>
                            <code className="text-xs bg-muted px-2 py-1 rounded font-mono">
                              {entry.hash.substring(0, 16)}...
                            </code>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Security Notice */}
        <Card className="border-primary/20 bg-primary/5">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <Shield className="h-5 w-5 text-primary mt-0.5" />
              <div className="space-y-1">
                <h3 className="font-semibold text-foreground">Security & Compliance</h3>
                <p className="text-sm text-muted-foreground">
                  This audit log is cryptographically secured using blockchain-style hashing. Each entry is linked to the previous entry through its hash, creating an immutable chain that detects tampering. All actions are automatically logged for HIPAA compliance and security monitoring.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default AuditLog;