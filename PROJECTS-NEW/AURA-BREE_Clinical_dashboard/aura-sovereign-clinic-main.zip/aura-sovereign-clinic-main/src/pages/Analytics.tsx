import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, Calendar, Activity, TrendingUp, Clock, Shield, Database } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

const Analytics = () => {
  const [analytics, setAnalytics] = useState({
    totalPatients: 0,
    totalVisits: 0,
    totalDosages: 0,
    activeDevices: 0,
    recentCheckins: 0,
    auditEntries: 0
  });
  const [visitTrends, setVisitTrends] = useState([]);
  const [patientStatus, setPatientStatus] = useState([]);
  const [dosageData, setDosageData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [timeRange, setTimeRange] = useState("7d");
  const { toast } = useToast();

  useEffect(() => {
    fetchAnalytics();
  }, [timeRange]);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      
      // Calculate date range
      const now = new Date();
      const daysBack = timeRange === "7d" ? 7 : timeRange === "30d" ? 30 : 90;
      const startDate = new Date(now.getTime() - (daysBack * 24 * 60 * 60 * 1000));

      // Fetch basic counts
      const [
        patientsResult,
        visitsResult,
        dosagesResult,
        devicesResult,
        checkinsResult,
        auditResult
      ] = await Promise.all([
        supabase.from('patients').select('*', { count: 'exact', head: true }),
        supabase.from('visits').select('*', { count: 'exact', head: true }),
        supabase.from('dosages').select('*', { count: 'exact', head: true }),
        supabase.from('devices').select('*').eq('status', 'active'),
        supabase.from('checkins').select('*').gte('created_at', startDate.toISOString()),
        supabase.from('audit_log').select('*', { count: 'exact', head: true })
      ]);

      // Fetch detailed data for charts
      const [
        visitTrendsResult,
        patientStatusResult,
        dosageDetailResult
      ] = await Promise.all([
        supabase.from('visits').select('arrived_at, triage_status').gte('arrived_at', startDate.toISOString()),
        supabase.from('patients').select('status'),
        supabase.from('dosages').select('administered_at, dose_mg').gte('administered_at', startDate.toISOString())
      ]);

      // Process analytics data
      setAnalytics({
        totalPatients: patientsResult.count || 0,
        totalVisits: visitsResult.count || 0,
        totalDosages: dosagesResult.count || 0,
        activeDevices: devicesResult.data?.length || 0,
        recentCheckins: checkinsResult.data?.length || 0,
        auditEntries: auditResult.count || 0
      });

      // Process visit trends
      const visitsByDay = {};
      visitTrendsResult.data?.forEach(visit => {
        const date = new Date(visit.arrived_at).toLocaleDateString();
        visitsByDay[date] = (visitsByDay[date] || 0) + 1;
      });

      const trendsArray = Object.entries(visitsByDay).map(([date, count]) => ({
        date,
        visits: count
      })).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

      setVisitTrends(trendsArray);

      // Process patient status distribution
      const statusCounts = {};
      patientStatusResult.data?.forEach(patient => {
        statusCounts[patient.status] = (statusCounts[patient.status] || 0) + 1;
      });

      const statusArray = Object.entries(statusCounts).map(([status, count]) => ({
        name: status,
        value: count
      }));

      setPatientStatus(statusArray);

      // Process dosage data
      const dosagesByDay: Record<string, { date: string; count: number; totalDose: number }> = {};
      dosageDetailResult.data?.forEach(dosage => {
        const date = new Date(dosage.administered_at).toLocaleDateString();
        if (!dosagesByDay[date]) {
          dosagesByDay[date] = { date, count: 0, totalDose: 0 };
        }
        dosagesByDay[date].count += 1;
        dosagesByDay[date].totalDose += (dosage.dose_mg || 0);
      });

      const dosagesArray = Object.values(dosagesByDay).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      setDosageData(dosagesArray);

    } catch (error) {
      console.error('Error fetching analytics:', error);
      toast({
        title: "Error",
        description: "Failed to load analytics data",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  const mainStats = [
    {
      title: "Total Patients",
      value: analytics.totalPatients,
      icon: Users,
      color: "text-primary",
      description: "Active patient records"
    },
    {
      title: "Total Visits",
      value: analytics.totalVisits,
      icon: Calendar,
      color: "text-success",
      description: "All time visits"
    },
    {
      title: "Dosages Given",
      value: analytics.totalDosages,
      icon: Activity,
      color: "text-warning",
      description: "Medication administered"
    },
    {
      title: "Active Devices",
      value: analytics.activeDevices,
      icon: Shield,
      color: "text-accent",
      description: "Connected devices"
    },
    {
      title: `Check-ins (${timeRange})`,
      value: analytics.recentCheckins,
      icon: Clock,
      color: "text-primary",
      description: "Recent device check-ins"
    },
    {
      title: "Audit Entries",
      value: analytics.auditEntries,
      icon: Database,
      color: "text-muted-foreground",
      description: "Total audit log entries"
    }
  ];

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Analytics</h1>
            <p className="text-muted-foreground">
              Clinic performance metrics and insights
            </p>
          </div>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[150px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Main Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {mainStats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">
                      {stat.title}
                    </p>
                    <p className="text-3xl font-bold text-foreground">
                      {stat.value}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {stat.description}
                    </p>
                  </div>
                  <stat.icon className={`w-8 h-8 ${stat.color}`} />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
          <Card>
            <CardHeader>
              <CardTitle>Visit Trends</CardTitle>
              <CardDescription>Daily visits over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={visitTrends}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="visits" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={2}
                    dot={{ fill: "hsl(var(--primary))", strokeWidth: 2 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Patient Status Distribution</CardTitle>
              <CardDescription>Breakdown by patient status</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={patientStatus}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {patientStatus.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Daily Dosage Administration</CardTitle>
              <CardDescription>Medication dispensing trends</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={dosageData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Bar 
                    dataKey="count" 
                    fill="hsl(var(--success))" 
                    radius={[4, 4, 0, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>System Health</CardTitle>
              <CardDescription>Overall system status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Database Status</span>
                <Badge className="bg-success text-success-foreground">
                  Operational
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Active Devices</span>
                <Badge className="bg-primary text-primary-foreground">
                  {analytics.activeDevices} Connected
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Recent Activity</span>
                <Badge className="bg-accent text-accent-foreground">
                  {analytics.recentCheckins} Check-ins
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Audit Trail</span>
                <Badge className="bg-secondary text-secondary-foreground">
                  {analytics.auditEntries} Entries
                </Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Analytics;