import { useState } from 'react';
import { DashboardLayout } from '@/components/DashboardLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Pill, Plus, Search, Filter, Calendar, User, FileText } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useStaffProfile } from '@/hooks/useStaffProfile';

interface Dosage {
  id: string;
  patient_id: string;
  dose_mg: number;
  medication: string;
  administered_at: string;
  administered_by: string;
  observed: boolean;
  notes: string | null;
  visit_id: string | null;
  patients: {
    first_name: string;
    last_name: string;
    mrn: string;
  };
  staff: {
    name: string;
  };
}

interface Patient {
  id: string;
  first_name: string;
  last_name: string;
  mrn: string;
}

const Dosages = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPatient, setSelectedPatient] = useState('');
  const [doseMg, setDoseMg] = useState('');
  const [medication, setMedication] = useState('Methadone');
  const [observed, setObserved] = useState('true');
  const [notes, setNotes] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: staffProfile } = useStaffProfile();

  // Fetch dosages with related data
  const { data: dosages = [], isLoading: dosagesLoading } = useQuery({
    queryKey: ['dosages', searchTerm],
    queryFn: async (): Promise<Dosage[]> => {
      let query = supabase
        .from('dosages')
        .select(`
          *,
          patients!inner(first_name, last_name, mrn),
          staff!inner(name)
        `)
        .order('administered_at', { ascending: false });

      if (searchTerm) {
        query = query.or(
          `patients.first_name.ilike.%${searchTerm}%,patients.last_name.ilike.%${searchTerm}%,patients.mrn.ilike.%${searchTerm}%`
        );
      }

      const { data, error } = await query;
      if (error) throw error;
      return data || [];
    }
  });

  // Fetch patients for dropdown
  const { data: patients = [] } = useQuery({
    queryKey: ['patients-list'],
    queryFn: async (): Promise<Patient[]> => {
      const { data, error } = await supabase
        .from('patients')
        .select('id, first_name, last_name, mrn')
        .eq('status', 'active')
        .order('last_name');
      if (error) throw error;
      return data || [];
    }
  });

  // Create dosage mutation
  const createDosageMutation = useMutation({
    mutationFn: async (dosageData: any) => {
      const { data, error } = await supabase
        .from('dosages')
        .insert([{
          patient_id: dosageData.patient_id,
          dose_mg: parseInt(dosageData.dose_mg),
          medication: dosageData.medication,
          observed: dosageData.observed === 'true',
          notes: dosageData.notes || null,
          administered_by: staffProfile?.user_id,
          administered_at: new Date().toISOString(),
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['dosages'] });
      toast({
        title: "Dosage recorded",
        description: "Medication administration has been logged successfully.",
      });
      setIsDialogOpen(false);
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Error recording dosage",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  const resetForm = () => {
    setSelectedPatient('');
    setDoseMg('');
    setMedication('Methadone');
    setObserved('true');
    setNotes('');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient || !doseMg || !staffProfile?.user_id) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    createDosageMutation.mutate({
      patient_id: selectedPatient,
      dose_mg: doseMg,
      medication,
      observed,
      notes,
    });
  };

  const formatDateTime = (dateString: string) => {
    return new Date(dateString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Dosage Management</h1>
            <p className="text-muted-foreground">
              Record and track medication administration
            </p>
          </div>
          
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Record Dosage
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <form onSubmit={handleSubmit}>
                <DialogHeader>
                  <DialogTitle>Record New Dosage</DialogTitle>
                  <DialogDescription>
                    Log medication administration for a patient
                  </DialogDescription>
                </DialogHeader>
                
                <div className="grid gap-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="patient">Patient *</Label>
                    <Select value={selectedPatient} onValueChange={setSelectedPatient}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a patient" />
                      </SelectTrigger>
                      <SelectContent>
                        {patients.map((patient) => (
                          <SelectItem key={patient.id} value={patient.id}>
                            {patient.last_name}, {patient.first_name} (MRN: {patient.mrn})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="medication">Medication</Label>
                      <Select value={medication} onValueChange={setMedication}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Methadone">Methadone</SelectItem>
                          <SelectItem value="Buprenorphine">Buprenorphine</SelectItem>
                          <SelectItem value="Naloxone">Naloxone</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="dose">Dose (mg) *</Label>
                      <Input
                        id="dose"
                        type="number"
                        min="1"
                        max="300"
                        value={doseMg}
                        onChange={(e) => setDoseMg(e.target.value)}
                        placeholder="Enter dose"
                        required
                      />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="observed">Administration Type</Label>
                    <Select value={observed} onValueChange={setObserved}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="true">Observed (Directly supervised)</SelectItem>
                        <SelectItem value="false">Take-home</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="notes">Notes (Optional)</Label>
                    <Textarea
                      id="notes"
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="Any additional notes..."
                      rows={3}
                    />
                  </div>
                </div>
                
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setIsDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button type="submit" disabled={createDosageMutation.isPending}>
                    {createDosageMutation.isPending ? 'Recording...' : 'Record Dosage'}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search and Filters */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Search & Filter
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by patient name or MRN..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Dosages Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Pill className="h-5 w-5" />
              Recent Dosages
            </CardTitle>
            <CardDescription>
              Medication administration records
            </CardDescription>
          </CardHeader>
          <CardContent>
            {dosagesLoading ? (
              <div className="space-y-2">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="h-12 bg-muted/50 rounded animate-pulse" />
                ))}
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Patient</TableHead>
                      <TableHead>MRN</TableHead>
                      <TableHead>Medication</TableHead>
                      <TableHead>Dose</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Administered By</TableHead>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Notes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {dosages.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                          No dosage records found
                        </TableCell>
                      </TableRow>
                    ) : (
                      dosages.map((dosage) => (
                        <TableRow key={dosage.id}>
                          <TableCell className="font-medium">
                            {dosage.patients.last_name}, {dosage.patients.first_name}
                          </TableCell>
                          <TableCell className="font-mono text-sm">
                            {dosage.patients.mrn}
                          </TableCell>
                          <TableCell>{dosage.medication}</TableCell>
                          <TableCell>{dosage.dose_mg}mg</TableCell>
                          <TableCell>
                            <Badge variant={dosage.observed ? "default" : "secondary"}>
                              {dosage.observed ? "Observed" : "Take-home"}
                            </Badge>
                          </TableCell>
                          <TableCell>{dosage.staff.name}</TableCell>
                          <TableCell className="text-sm">
                            {formatDateTime(dosage.administered_at)}
                          </TableCell>
                          <TableCell className="max-w-32 truncate">
                            {dosage.notes && (
                              <span title={dosage.notes} className="text-sm text-muted-foreground">
                                {dosage.notes}
                              </span>
                            )}
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default Dosages;