import { DashboardLayout } from "@/components/DashboardLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BookOpen, Users, Calendar, Activity, Settings, Shield, Wifi, Download } from "lucide-react";

const Documentation = () => {
  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Documentation</h1>
          <p className="text-muted-foreground">
            Complete guide to using the Sovereign Methadone Clinic Management System
          </p>
        </div>

        <div className="grid gap-6">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <BookOpen className="w-6 h-6 text-primary" />
                <div>
                  <CardTitle>Getting Started</CardTitle>
                  <CardDescription>
                    Essential information for new users
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="overview">
                  <AccordionTrigger>System Overview</AccordionTrigger>
                  <AccordionContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      The Sovereign Methadone Clinic Management System is a comprehensive platform designed 
                      specifically for methadone treatment facilities. It integrates patient management, 
                      dosage tracking, visit scheduling, and AURA-BREE device connectivity.
                    </p>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <h4 className="font-medium mb-2">Key Features</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• Patient record management</li>
                          <li>• Visit tracking and scheduling</li>
                          <li>• Dosage administration logs</li>
                          <li>• Device integration (AURA-BREE)</li>
                          <li>• Real-time analytics</li>
                          <li>• Audit trail compliance</li>
                        </ul>
                      </div>
                      <div>
                        <h4 className="font-medium mb-2">User Roles</h4>
                        <ul className="text-sm text-muted-foreground space-y-1">
                          <li>• <Badge variant="secondary" className="mr-1">Admin</Badge> Full system access</li>
                          <li>• <Badge variant="secondary" className="mr-1">Clinical</Badge> Patient care focused</li>
                          <li>• <Badge variant="secondary" className="mr-1">Reception</Badge> Limited access</li>
                        </ul>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="login">
                  <AccordionTrigger>Logging In</AccordionTrigger>
                  <AccordionContent>
                    <p className="text-sm text-muted-foreground mb-3">
                      Access to the system requires authentication. Contact your system administrator 
                      to obtain login credentials.
                    </p>
                    <div className="space-y-2 text-sm">
                      <p><strong>Step 1:</strong> Enter your username and password</p>
                      <p><strong>Step 2:</strong> Complete two-factor authentication if enabled</p>
                      <p><strong>Step 3:</strong> Access the dashboard based on your role permissions</p>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Users className="w-6 h-6 text-success" />
                <div>
                  <CardTitle>Patient Management</CardTitle>
                  <CardDescription>
                    Managing patient records and information
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="add-patient">
                  <AccordionTrigger>Adding New Patients</AccordionTrigger>
                  <AccordionContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      To add a new patient to the system, navigate to the Patients page and click "Add Patient".
                    </p>
                    <div className="space-y-2 text-sm">
                      <p><strong>Required Fields:</strong></p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li>First Name and Last Name</li>
                        <li>Medical Record Number (MRN)</li>
                        <li>Date of Birth</li>
                        <li>Initial Status (New, Active, Inactive)</li>
                      </ul>
                      <p><strong>Optional Fields:</strong></p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li>Phone Number</li>
                        <li>Additional demographic information</li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="search-patients">
                  <AccordionTrigger>Searching and Filtering</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-3 text-sm">
                      <p>The patient list supports multiple search and filter options:</p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li>Search by name, MRN, or phone number</li>
                        <li>Filter by patient status</li>
                        <li>Sort by creation date, name, or status</li>
                      </ul>
                      <p className="text-muted-foreground">
                        Use the search bar for quick lookups or apply filters for more targeted results.
                      </p>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Calendar className="w-6 h-6 text-accent" />
                <div>
                  <CardTitle>Visit Management</CardTitle>
                  <CardDescription>
                    Tracking appointments and patient visits
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="visit-status">
                  <AccordionTrigger>Visit Status Management</AccordionTrigger>
                  <AccordionContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      Each visit progresses through different statuses to track patient flow:
                    </p>
                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <Badge className="bg-warning text-warning-foreground">Waiting</Badge>
                        <span className="text-sm">Patient has arrived and is waiting to be seen</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge className="bg-primary text-primary-foreground">In Progress</Badge>
                        <span className="text-sm">Patient is currently being treated</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge className="bg-success text-success-foreground">Completed</Badge>
                        <span className="text-sm">Visit has been completed successfully</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <Badge className="bg-destructive text-destructive-foreground">Cancelled</Badge>
                        <span className="text-sm">Visit was cancelled or not completed</span>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="queue-management">
                  <AccordionTrigger>Managing the Visit Queue</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-3 text-sm">
                      <p>The Appointments page shows all visits with real-time status updates:</p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li>View today's scheduled visits and walk-ins</li>
                        <li>Update visit status as patients progress through treatment</li>
                        <li>Add notes for clinical documentation</li>
                        <li>Filter visits by status or time period</li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Activity className="w-6 h-6 text-warning" />
                <div>
                  <CardTitle>Dosage Management</CardTitle>
                  <CardDescription>
                    Recording and tracking medication administration
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="record-dosage">
                  <AccordionTrigger>Recording Dosages</AccordionTrigger>
                  <AccordionContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      All medication administration must be properly documented:
                    </p>
                    <div className="space-y-2 text-sm">
                      <p><strong>Required Information:</strong></p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li>Patient identification</li>
                        <li>Medication type and dosage amount (mg)</li>
                        <li>Administration time and date</li>
                        <li>Administering staff member</li>
                        <li>Observation status (observed/unobserved)</li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="dosage-tracking">
                  <AccordionTrigger>Dosage History and Tracking</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-3 text-sm">
                      <p>The system maintains complete dosage history for each patient:</p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li>View historical dosage records</li>
                        <li>Track dosage adjustments over time</li>
                        <li>Generate dosage reports for regulatory compliance</li>
                        <li>Monitor missed doses and adherence patterns</li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Wifi className="w-6 h-6 text-primary" />
                <div>
                  <CardTitle>AURA-BREE Integration</CardTitle>
                  <CardDescription>
                    Device connectivity and patient monitoring
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="device-setup">
                  <AccordionTrigger>Device Setup and Registration</AccordionTrigger>
                  <AccordionContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      AURA-BREE devices provide secure patient identification and compliance monitoring:
                    </p>
                    <div className="space-y-2 text-sm">
                      <p><strong>Device Registration:</strong></p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li>Each device has a unique UUID for identification</li>
                        <li>Devices are paired with specific patients</li>
                        <li>Public key cryptography ensures secure communication</li>
                        <li>Real-time status monitoring (active/inactive)</li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="check-ins">
                  <AccordionTrigger>Patient Check-ins</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-3 text-sm">
                      <p>Device check-ins provide automated patient verification:</p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li>Automatic check-in when patients arrive</li>
                        <li>WiFi-based location verification</li>
                        <li>Signal strength (RSSI) monitoring</li>
                        <li>Synchronization of device data with clinic records</li>
                      </ul>
                      <p className="text-muted-foreground">
                        Check-in data is encrypted and stored locally for patient privacy and security.
                      </p>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Settings className="w-6 h-6 text-secondary" />
                <div>
                  <CardTitle>System Administration</CardTitle>
                  <CardDescription>
                    Administrative functions and system management
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="user-management">
                  <AccordionTrigger>User and Staff Management</AccordionTrigger>
                  <AccordionContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      Administrative users can manage staff accounts and permissions:
                    </p>
                    <div className="space-y-2 text-sm">
                      <p><strong>Staff Roles:</strong></p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li><strong>Admin:</strong> Full system access and user management</li>
                        <li><strong>Clinical:</strong> Patient care and dosage administration</li>
                        <li><strong>Reception:</strong> Patient check-in and basic scheduling</li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="audit-logs">
                  <AccordionTrigger>Audit Logs and Compliance</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-3 text-sm">
                      <p>The system maintains comprehensive audit logs for regulatory compliance:</p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li>All user actions are logged with timestamps</li>
                        <li>Patient record access is tracked</li>
                        <li>Dosage administration is fully auditable</li>
                        <li>Hash-chain verification prevents tampering</li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-3">
                <Shield className="w-6 h-6 text-destructive" />
                <div>
                  <CardTitle>Security and Compliance</CardTitle>
                  <CardDescription>
                    Data protection and regulatory requirements
                  </CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="data-security">
                  <AccordionTrigger>Data Security Measures</AccordionTrigger>
                  <AccordionContent className="space-y-3">
                    <p className="text-sm text-muted-foreground">
                      The system implements multiple layers of security protection:
                    </p>
                    <ul className="list-disc list-inside text-muted-foreground text-sm space-y-1">
                      <li>End-to-end encryption for all data transmission</li>
                      <li>Role-based access controls (RBAC)</li>
                      <li>Multi-factor authentication support</li>
                      <li>Automatic session timeouts</li>
                      <li>Local data storage (no cloud dependencies)</li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>
                <AccordionItem value="hipaa-compliance">
                  <AccordionTrigger>HIPAA Compliance Features</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-3 text-sm">
                      <p>Built-in features support HIPAA compliance:</p>
                      <ul className="list-disc list-inside text-muted-foreground space-y-1">
                        <li>Minimum necessary access principle</li>
                        <li>Complete audit trails for all PHI access</li>
                        <li>Secure user authentication and authorization</li>
                        <li>Data backup and recovery procedures</li>
                        <li>Incident reporting and breach notification support</li>
                      </ul>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Support and Resources</CardTitle>
              <CardDescription>
                Getting help and additional resources
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium mb-2">Technical Support</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    For technical issues or system problems, contact your system administrator 
                    or IT support team.
                  </p>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download User Guide
                  </Button>
                </div>
                <div>
                  <h4 className="font-medium mb-2">Training Resources</h4>
                  <p className="text-sm text-muted-foreground mb-3">
                    Regular training sessions are available for new users and system updates.
                  </p>
                  <Button variant="outline" size="sm">
                    <Calendar className="w-4 h-4 mr-2" />
                    Schedule Training
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Documentation;