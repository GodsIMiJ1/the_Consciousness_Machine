import { ReactElement } from 'react';
import { Alert, AlertDescription } from './ui/alert';
import { ShieldX } from 'lucide-react';

interface RoleGateProps {
  allow: Array<'admin' | 'clinician' | 'reception'>;
  role?: string;
  children: ReactElement;
}

export function RoleGate({ allow, role, children }: RoleGateProps) {
  if (!role || !allow.includes(role as any)) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-6">
        <Alert className="max-w-md">
          <ShieldX className="h-4 w-4" />
          <AlertDescription className="text-sm opacity-70">
            Insufficient permissions. Contact your administrator for access.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return children;
}