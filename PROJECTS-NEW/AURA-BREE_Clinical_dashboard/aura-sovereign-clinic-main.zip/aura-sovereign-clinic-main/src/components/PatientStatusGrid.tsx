import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Clock, 
  CheckCircle, 
  AlertCircle, 
  User,
  Calendar,
  Pill
} from "lucide-react";

const patients = [
  {
    id: "P001",
    name: "John Smith",
    status: "checked-in",
    time: "09:15 AM",
    dosage: "40mg",
    lastSync: "2 min ago",
    priority: "normal"
  },
  {
    id: "P002", 
    name: "Maria Garcia",
    status: "waiting",
    time: "09:30 AM",
    dosage: "35mg",
    lastSync: "5 min ago",
    priority: "high"
  },
  {
    id: "P003",
    name: "David Johnson",
    status: "completed",
    time: "09:00 AM", 
    dosage: "45mg",
    lastSync: "1 min ago",
    priority: "normal"
  },
  {
    id: "P004",
    name: "Lisa Chen",
    status: "scheduled",
    time: "10:00 AM",
    dosage: "30mg",
    lastSync: "Never",
    priority: "normal"
  },
  {
    id: "P005",
    name: "Robert Brown",
    status: "checked-in",
    time: "09:45 AM",
    dosage: "50mg", 
    lastSync: "30 sec ago",
    priority: "high"
  },
  {
    id: "P006",
    name: "Sarah Wilson", 
    status: "waiting",
    time: "09:20 AM",
    dosage: "25mg",
    lastSync: "3 min ago",
    priority: "normal"
  }
];

const getStatusColor = (status: string) => {
  switch (status) {
    case 'completed': return 'bg-success text-success-foreground';
    case 'checked-in': return 'bg-primary text-primary-foreground';
    case 'waiting': return 'bg-warning text-warning-foreground';
    case 'scheduled': return 'bg-muted text-muted-foreground';
    default: return 'bg-muted text-muted-foreground';
  }
};

const getStatusIcon = (status: string) => {
  switch (status) {
    case 'completed': return CheckCircle;
    case 'checked-in': return User;
    case 'waiting': return Clock;
    case 'scheduled': return Calendar;
    default: return AlertCircle;
  }
};

export const PatientStatusGrid = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-foreground">Patient Status</h3>
        <Button variant="outline" size="sm">
          View All Patients
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {patients.map((patient) => {
          const StatusIcon = getStatusIcon(patient.status);
          return (
            <Card key={patient.id} className="bg-gradient-card border-0 shadow-soft hover:shadow-medium transition-all duration-300">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                      <User className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-sm font-medium">
                        {patient.name}
                      </CardTitle>
                      <p className="text-xs text-muted-foreground">
                        ID: {patient.id}
                      </p>
                    </div>
                  </div>
                  {patient.priority === 'high' && (
                    <AlertCircle className="h-4 w-4 text-warning" />
                  )}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <Badge className={getStatusColor(patient.status)}>
                    <StatusIcon className="h-3 w-3 mr-1" />
                    {patient.status.charAt(0).toUpperCase() + patient.status.slice(1)}
                  </Badge>
                  <span className="text-sm text-muted-foreground">
                    {patient.time}
                  </span>
                </div>
                
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <Pill className="h-4 w-4 text-accent" />
                    <span className="text-foreground">{patient.dosage}</span>
                  </div>
                  <span className="text-muted-foreground">
                    Sync: {patient.lastSync}
                  </span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};