import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Activity, 
  UserCheck, 
  Pill, 
  Smartphone,
  FileText,
  AlertTriangle
} from "lucide-react";

const activities = [
  {
    id: 1,
    type: "check-in",
    message: "John Smith checked in via AURA-BREE app",
    time: "2 minutes ago",
    icon: UserCheck,
    color: "text-success"
  },
  {
    id: 2,
    type: "dosage",
    message: "Maria Garcia - 35mg methadone administered",
    time: "5 minutes ago", 
    icon: Pill,
    color: "text-primary"
  },
  {
    id: 3,
    type: "sync",
    message: "AURA-BREE sync completed for 12 patients",
    time: "8 minutes ago",
    icon: Smartphone,
    color: "text-accent"
  },
  {
    id: 4,
    type: "alert",
    message: "Priority case: Robert Brown requires counselor review",
    time: "12 minutes ago",
    icon: AlertTriangle,
    color: "text-warning"
  },
  {
    id: 5,
    type: "report",
    message: "Daily compliance report generated",
    time: "15 minutes ago",
    icon: FileText,
    color: "text-muted-foreground"
  },
  {
    id: 6,
    type: "check-in",
    message: "Sarah Wilson completed wellness check-in",
    time: "18 minutes ago",
    icon: Activity,
    color: "text-success"
  }
];

const getActivityBadge = (type: string) => {
  switch (type) {
    case 'check-in': return 'bg-success/10 text-success';
    case 'dosage': return 'bg-primary/10 text-primary';
    case 'sync': return 'bg-accent/10 text-accent';
    case 'alert': return 'bg-warning/10 text-warning';
    case 'report': return 'bg-muted/50 text-muted-foreground';
    default: return 'bg-muted/50 text-muted-foreground';
  }
};

export const RecentActivity = () => {
  return (
    <Card className="bg-gradient-card border-0 shadow-soft">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5 text-primary" />
          Recent Activity
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => {
            const Icon = activity.icon;
            return (
              <div key={activity.id} className="flex items-start gap-4 p-3 rounded-lg hover:bg-muted/30 transition-colors">
                <div className="mt-0.5">
                  <Icon className={`h-4 w-4 ${activity.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm text-foreground">
                    {activity.message}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {activity.time}
                  </p>
                </div>
                <Badge className={`${getActivityBadge(activity.type)} text-xs`}>
                  {activity.type}
                </Badge>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};