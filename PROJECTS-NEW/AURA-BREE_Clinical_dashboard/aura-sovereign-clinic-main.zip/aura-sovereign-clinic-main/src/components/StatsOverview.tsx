import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Users, 
  UserCheck, 
  Clock, 
  AlertTriangle,
  TrendingUp,
  Activity
} from "lucide-react";

const stats = [
  {
    title: "Total Patients",
    value: "247",
    change: "+12 this week",
    icon: Users,
    trend: "up",
    color: "text-primary"
  },
  {
    title: "Checked In Today",
    value: "34",
    change: "6 pending",
    icon: UserCheck,
    trend: "up",
    color: "text-success"
  },
  {
    title: "Avg. Wait Time",
    value: "8 min",
    change: "-2 min from yesterday",
    icon: Clock,
    trend: "down",
    color: "text-accent"
  },
  {
    title: "Priority Cases",
    value: "3",
    change: "Requires attention",
    icon: AlertTriangle,
    trend: "neutral",
    color: "text-warning"
  },
  {
    title: "AURA-BREE Syncs",
    value: "156",
    change: "Last sync: 2 min ago",
    icon: Activity,
    trend: "up",
    color: "text-accent"
  },
  {
    title: "Treatment Progress",
    value: "94%",
    change: "+3% this month",
    icon: TrendingUp,
    trend: "up",
    color: "text-success"
  }
];

export const StatsOverview = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
      {stats.map((stat) => {
        const Icon = stat.icon;
        return (
          <Card key={stat.title} className="bg-gradient-card border-0 shadow-soft hover:shadow-medium transition-all duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <Icon className={`h-5 w-5 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-foreground mb-1">
                {stat.value}
              </div>
              <p className="text-xs text-muted-foreground">
                {stat.change}
              </p>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};