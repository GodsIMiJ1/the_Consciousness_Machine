import { 
  Activity, 
  Users, 
  Calendar, 
  BarChart3, 
  Settings, 
  FileText,
  Shield,
  Wifi,
  Pill,
  AlertTriangle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "react-router-dom";

const navigation = [
  { name: 'Dashboard', href: '/', icon: Activity },
  { name: 'Patients', href: '/patients', icon: Users },
  { name: 'Appointments', href: '/appointments', icon: Calendar },
  { name: 'Dosages', href: '/dosages', icon: Pill },
  { name: 'Analytics', href: '/analytics', icon: BarChart3 },
  { name: 'Audit Log', href: '/audit', icon: Shield },
  { name: 'Privacy Policy', href: '/privacy', icon: Shield },
  { name: 'Documentation', href: '/docs', icon: FileText },
  { name: 'Settings', href: '/settings', icon: Settings },
];

export const DashboardSidebar = () => {
  const location = useLocation();
  
  return (
    <div className="fixed inset-y-0 left-0 z-50 w-64 bg-card border-r shadow-soft lg:translate-x-0">
      <div className="flex h-16 items-center px-6 border-b bg-gradient-primary">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-white/20 rounded-lg flex items-center justify-center">
            <Activity className="h-5 w-5 text-primary-foreground" />
          </div>
          <div className="text-primary-foreground">
            <h1 className="font-bold text-lg">MethaClinic</h1>
            <p className="text-xs text-primary-foreground/80">AURA-BREE Integration</p>
          </div>
        </div>
      </div>
      
      <div className="p-4">
        <div className="mb-6">
          <div className="flex items-center gap-2 px-3 py-2 bg-success/10 rounded-lg">
            <Wifi className="h-4 w-4 text-success" />
            <span className="text-sm font-medium text-success">Local Network Active</span>
          </div>
        </div>

        <nav className="space-y-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.href;
            return (
              <Button
                key={item.name}
                variant={isActive ? "default" : "ghost"}
                className="w-full justify-start gap-3 h-11"
                asChild
              >
                <a href={item.href}>
                  <Icon className="h-5 w-5" />
                  {item.name}
                </a>
              </Button>
            );
          })}
        </nav>
      </div>
    </div>
  );
};