import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { ThemeProvider } from 'next-themes';
import { AuthProvider } from '@/components/AuthProvider';
import { ProtectedRoute } from '@/components/ProtectedRoute';
import { RoleGate } from '@/components/RoleGate';
import { OfflineBanner } from '@/components/OfflineBanner';
import { useStaffProfile } from '@/hooks/useStaffProfile';
import { useRealtimeCheckins } from '@/hooks/useRealtimeCheckins';
import { DashboardLayout } from '@/components/DashboardLayout';
import Index from '@/pages/Index';
import Patients from '@/pages/Patients';
import Appointments from '@/pages/Appointments';
import Analytics from '@/pages/Analytics';
import Settings from '@/pages/Settings';
import Dosages from '@/pages/Dosages';
import AuditLog from '@/pages/AuditLog';
import Privacy from '@/pages/Privacy';
import Documentation from '@/pages/Documentation';
import NotFound from '@/pages/NotFound';
import Auth from '@/pages/Auth';
import './App.css';

const queryClient = new QueryClient();

function AppContent() {
  const { data: staff } = useStaffProfile();
  
  // Initialize realtime subscriptions
  useRealtimeCheckins();

  return (
    <Routes>
      <Route path="/auth" element={<Auth />} />
      <Route path="/" element={
        <ProtectedRoute>
          <DashboardLayout>
            <Index />
          </DashboardLayout>
        </ProtectedRoute>
      } />
      <Route path="/patients" element={
        <ProtectedRoute>
          <DashboardLayout>
            <Patients />
          </DashboardLayout>
        </ProtectedRoute>
      } />
      <Route path="/appointments" element={
        <ProtectedRoute>
          <DashboardLayout>
            <Appointments />
          </DashboardLayout>
        </ProtectedRoute>
      } />
      <Route path="/analytics" element={
        <ProtectedRoute>
          <RoleGate allow={['admin', 'clinician']} role={staff?.role}>
            <DashboardLayout>
              <Analytics />
            </DashboardLayout>
          </RoleGate>
        </ProtectedRoute>
      } />
      <Route path="/settings" element={
        <ProtectedRoute>
          <RoleGate allow={['admin']} role={staff?.role}>
            <DashboardLayout>
              <Settings />
            </DashboardLayout>
          </RoleGate>
        </ProtectedRoute>
      } />
      <Route path="/dosages" element={
        <ProtectedRoute>
          <RoleGate allow={['admin', 'clinician']} role={staff?.role}>
            <DashboardLayout>
              <Dosages />
            </DashboardLayout>
          </RoleGate>
        </ProtectedRoute>
      } />
      <Route path="/audit" element={
        <ProtectedRoute>
          <RoleGate allow={['admin']} role={staff?.role}>
            <DashboardLayout>
              <AuditLog />
            </DashboardLayout>
          </RoleGate>
        </ProtectedRoute>
      } />
      <Route path="/privacy" element={<Privacy />} />
      <Route path="/docs" element={<Documentation />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <Router>
          <AuthProvider>
            <OfflineBanner />
            <AppContent />
            <Toaster />
          </AuthProvider>
        </Router>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
