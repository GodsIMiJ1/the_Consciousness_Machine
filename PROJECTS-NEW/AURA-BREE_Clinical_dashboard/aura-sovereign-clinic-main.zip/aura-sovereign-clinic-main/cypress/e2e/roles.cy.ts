describe('Role-based Access Control', () => {
  beforeEach(() => {
    // Setup test data
    cy.exec('npm run db:seed'); // Assume we have a seed script
  });

  describe('Reception Role', () => {
    beforeEach(() => {
      cy.login('reception@test.com', 'TestPass123!');
    });

    it('should access dashboard and patients', () => {
      cy.visit('/');
      cy.contains('MethaClinic').should('be.visible');
      
      cy.visit('/patients');
      cy.contains('Patients').should('be.visible');
      cy.get('[data-testid="patient-list"]').should('be.visible');
    });

    it('should access appointments', () => {
      cy.visit('/appointments');
      cy.contains('Appointments').should('be.visible');
    });

    it('should NOT access dosages page', () => {
      cy.visit('/dosages');
      cy.contains('Insufficient permissions').should('be.visible');
    });

    it('should NOT access analytics page', () => {
      cy.visit('/analytics');
      cy.contains('Insufficient permissions').should('be.visible');
    });

    it('should NOT access settings page', () => {
      cy.visit('/settings');
      cy.contains('Insufficient permissions').should('be.visible');
    });

    it('should NOT access audit log', () => {
      cy.visit('/audit');
      cy.contains('Insufficient permissions').should('be.visible');
    });
  });

  describe('Clinician Role', () => {
    beforeEach(() => {
      cy.login('clinician@test.com', 'TestPass123!');
    });

    it('should access all patient-related features', () => {
      cy.visit('/patients');
      cy.contains('Patients').should('be.visible');
      
      cy.visit('/dosages');
      cy.contains('Dosage Management').should('be.visible');
      cy.get('[data-testid="new-dosage-button"]').should('be.visible');
    });

    it('should access analytics', () => {
      cy.visit('/analytics');
      cy.contains('Analytics').should('be.visible');
      cy.get('[data-testid="attendance-chart"]').should('be.visible');
    });

    it('should create a dosage entry', () => {
      cy.visit('/dosages');
      cy.get('[data-testid="new-dosage-button"]').click();
      
      cy.get('[data-testid="patient-select"]').click();
      cy.get('[data-testid="patient-option"]').first().click();
      
      cy.get('[data-testid="dose-amount"]').type('25');
      cy.get('[data-testid="medication-select"]').select('Methadone');
      cy.get('[data-testid="observed-toggle"]').check();
      
      cy.get('[data-testid="save-dosage"]').click();
      cy.contains('Dosage recorded').should('be.visible');
    });

    it('should NOT access admin settings', () => {
      cy.visit('/settings');
      cy.contains('Insufficient permissions').should('be.visible');
    });

    it('should NOT access audit log', () => {
      cy.visit('/audit');
      cy.contains('Insufficient permissions').should('be.visible');
    });
  });

  describe('Admin Role', () => {
    beforeEach(() => {
      cy.login('admin@test.com', 'TestPass123!');
    });

    it('should access all features', () => {
      const pages = ['/', '/patients', '/appointments', '/dosages', '/analytics', '/settings', '/audit'];
      
      pages.forEach(page => {
        cy.visit(page);
        cy.contains('Insufficient permissions').should('not.exist');
      });
    });

    it('should manage settings', () => {
      cy.visit('/settings');
      cy.contains('Settings').should('be.visible');
      
      cy.get('[data-testid="weekly-reports-toggle"]').click();
      cy.get('[data-testid="save-settings"]').click();
      cy.contains('Settings saved').should('be.visible');
    });

    it('should view audit log', () => {
      cy.visit('/audit');
      cy.contains('Audit Log').should('be.visible');
      cy.get('[data-testid="audit-entries"]').should('be.visible');
    });

    it('should generate weekly report', () => {
      cy.visit('/analytics');
      cy.get('[data-testid="generate-report"]').click();
      cy.contains('Report generated').should('be.visible');
    });
  });
});