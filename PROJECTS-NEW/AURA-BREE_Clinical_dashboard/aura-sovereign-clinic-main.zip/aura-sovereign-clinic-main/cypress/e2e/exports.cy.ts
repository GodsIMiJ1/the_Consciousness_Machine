describe('Data Exports', () => {
  beforeEach(() => {
    cy.login('admin@test.com', 'TestPass123!');
  });

  it('should export patients as CSV', () => {
    cy.visit('/patients');
    
    // Ensure we have data to export
    cy.get('[data-testid="patient-row"]').should('have.length.greaterThan', 0);
    
    cy.get('[data-testid="export-csv"]').click();
    
    // Check that download was triggered
    cy.readFile('cypress/downloads/patients.csv').should('exist');
    cy.readFile('cypress/downloads/patients.csv').should('contain', 'MRN,First Name,Last Name');
  });

  it('should export dosages as PDF', () => {
    cy.visit('/dosages');
    
    cy.get('[data-testid="export-pdf"]').click();
    
    // PDF export opens in new window, so we check that it was triggered
    cy.window().then((win) => {
      cy.stub(win, 'open').as('windowOpen');
    });
    
    cy.get('@windowOpen').should('have.been.called');
  });

  it('should handle export with no data gracefully', () => {
    cy.visit('/patients');
    
    // Clear all data or filter to show no results
    cy.get('[data-testid="search-input"]').type('nonexistent');
    cy.get('[data-testid="patient-row"]').should('have.length', 0);
    
    cy.get('[data-testid="export-csv"]').click();
    
    // Should show appropriate message
    cy.contains('No data to export').should('be.visible');
  });

  it('should generate weekly compliance report', () => {
    cy.visit('/analytics');
    
    cy.get('[data-testid="generate-weekly-report"]').click();
    
    cy.get('[data-testid="loading-spinner"]').should('be.visible');
    cy.get('[data-testid="loading-spinner"]').should('not.exist');
    
    cy.contains('Weekly report generated').should('be.visible');
  });
});