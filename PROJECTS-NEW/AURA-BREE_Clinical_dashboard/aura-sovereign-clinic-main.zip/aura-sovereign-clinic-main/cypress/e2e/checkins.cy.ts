describe('Patient Check-ins', () => {
  beforeEach(() => {
    cy.login('admin@test.com', 'TestPass123!');
  });

  it('should auto-create visit when patient checks in', () => {
    // First, create a test patient
    cy.visit('/patients');
    cy.get('[data-testid="new-patient-button"]').click();
    cy.get('[data-testid="patient-mrn"]').type('TEST-001');
    cy.get('[data-testid="patient-first-name"]').type('Test');
    cy.get('[data-testid="patient-last-name"]').type('Patient');
    cy.get('[data-testid="patient-dob"]').type('1990-01-01');
    cy.get('[data-testid="save-patient"]').click();
    
    // Get the patient ID from the response
    cy.get('[data-testid="patient-row"]').first().invoke('data', 'patient-id').then((patientId) => {
      // Mock a check-in for this patient
      cy.mockCheckin(patientId as string);
      
      // Check that a visit was created
      cy.visit('/appointments');
      cy.contains('Test Patient').should('be.visible');
      cy.get('[data-testid="visit-status"]').should('contain', 'waiting');
      
      // Check that notification was shown
      cy.get('[data-testid="toast"]').should('contain', 'Patient Check-in Detected');
    });
  });

  it('should not create duplicate visits for same day', () => {
    // Assuming we have existing test data
    const patientId = 'existing-patient-id';
    
    // First check-in
    cy.mockCheckin(patientId);
    cy.visit('/appointments');
    cy.get('[data-testid="visit-row"]').should('have.length', 1);
    
    // Second check-in same day
    cy.mockCheckin(patientId);
    cy.reload();
    cy.get('[data-testid="visit-row"]').should('have.length', 1); // Still only one
  });

  it('should show real-time notifications', () => {
    cy.visit('/');
    
    // Mock a check-in and verify toast appears
    cy.mockCheckin('test-patient-id');
    
    cy.get('[data-testid="toast"]', { timeout: 5000 })
      .should('be.visible')
      .and('contain', 'Patient Check-in Detected');
  });
});