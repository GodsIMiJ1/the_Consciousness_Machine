/// <reference types="cypress" />

declare global {
  namespace Cypress {
    interface Chainable {
      login(email: string, password: string): Chainable<void>
      createStaffUser(email: string, password: string, name: string, role: 'admin' | 'clinician' | 'reception'): Chainable<void>
      mockCheckin(patientId: string): Chainable<void>
    }
  }
}

// Custom command to login a user
Cypress.Commands.add('login', (email: string, password: string) => {
  cy.session([email, password], () => {
    cy.visit('/auth');
    cy.get('[data-testid="signin-email"]').type(email);
    cy.get('[data-testid="signin-password"]').type(password);
    cy.get('[data-testid="signin-submit"]').click();
    cy.url().should('eq', Cypress.config().baseUrl + '/');
  });
});

// Custom command to create a staff user with specific role
Cypress.Commands.add('createStaffUser', (email: string, password: string, name: string, role: 'admin' | 'clinician' | 'reception') => {
  cy.visit('/auth');
  cy.get('[data-testid="signup-tab"]').click();
  cy.get('[data-testid="signup-name"]').type(name);
  cy.get('[data-testid="signup-email"]').type(email);
  cy.get('[data-testid="signup-password"]').type(password);
  cy.get('[data-testid="signup-submit"]').click();
  
  // After signup, update role via direct database call if needed
  // This would require a custom endpoint or direct database access
});

// Mock check-in for testing realtime features
Cypress.Commands.add('mockCheckin', (patientId: string) => {
  cy.window().then((win) => {
    // Access the Supabase client from window object if exposed
    // or make direct API call to trigger check-in
    cy.request({
      method: 'POST',
      url: `${Cypress.env('SUPABASE_URL')}/rest/v1/checkins`,
      headers: {
        'apikey': Cypress.env('SUPABASE_ANON_KEY'),
        'Authorization': `Bearer ${Cypress.env('SUPABASE_ANON_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: {
        patient_id: patientId,
        device_id: '00000000-0000-0000-0000-000000000000',
        method: 'wifi',
        arrived_at: new Date().toISOString()
      }
    });
  });
});