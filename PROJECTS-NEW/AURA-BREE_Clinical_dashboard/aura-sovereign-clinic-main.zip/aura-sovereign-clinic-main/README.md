# MethaClinic - Sovereign Clinic Management System

[![Lovable](https://img.shields.io/badge/Built%20with-Lovable-ff69b4.svg)](https://lovable.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-007ACC?style=flat&logo=typescript&logoColor=white)](https://typescriptlang.org/)
[![React](https://img.shields.io/badge/React-20232A?style=flat&logo=react&logoColor=61DAFB)](https://reactjs.org/)
[![Supabase](https://img.shields.io/badge/Supabase-3ECF8E?style=flat&logo=supabase&logoColor=white)](https://supabase.com)

> **AURA-BREE Integration** - A secure, role-based clinic management system for methadone treatment facilities with real-time operations, compliance reporting, and offline capabilities.

## 🏥 Overview

MethaClinic is a comprehensive clinic management system designed specifically for methadone treatment facilities. Built with modern web technologies and security-first principles, it provides role-based access control, real-time patient management, automated compliance reporting, and offline-first functionality.

### Key Features

- **🔐 Role-Based Authentication** - Admin, Clinician, and Reception roles with granular permissions
- **📊 Real-Time Dashboard** - Live patient queue, check-ins, and clinic statistics
- **💊 Dosage Management** - Secure medication tracking with audit trails
- **📋 Patient Management** - Comprehensive patient records and visit tracking
- **📈 Compliance Reporting** - Automated weekly reports and analytics
- **🔒 Security & Auditing** - Complete audit logs with tamper-evident hashing
- **📱 Offline Support** - Continue operations during network outages
- **📤 Data Export** - CSV/PDF exports for reporting and compliance
- **🔄 Auto Backups** - Nightly encrypted backups to secure storage

## 🚀 Quick Start

### Prerequisites

- Node.js 18+ and npm
- Supabase account and project
- Modern web browser

### Installation

1. **Clone the repository**
   ```bash
   git clone <YOUR_GIT_URL>
   cd methadone-clinic-dashboard
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up Supabase**
   - Create a new Supabase project
   - Run the migrations from `supabase/migrations/`
   - Configure RLS policies (see [SECURITY.md](./docs/SECURITY.md))
   - Set up Edge Functions (see [API.md](./docs/API.md))

4. **Configure environment**
   ```bash
   # Update src/integrations/supabase/client.ts with your project details
   # The Supabase URL and anon key are embedded in the client configuration
   ```

5. **Start development server**
   ```bash
   npm run dev
   ```

6. **Run tests**
   ```bash
   # Unit tests
   npm test

   # E2E tests
   npm run e2e
   ```

## 📁 Project Structure

```
src/
├── components/          # Reusable UI components
│   ├── ui/             # shadcn/ui components
│   ├── DashboardLayout.tsx
│   ├── PatientStatusGrid.tsx
│   └── ...
├── pages/              # Route components
│   ├── Index.tsx       # Dashboard
│   ├── Patients.tsx    # Patient management
│   ├── Dosages.tsx     # Medication tracking
│   └── ...
├── hooks/              # Custom React hooks
│   ├── useRealtimeCheckins.ts
│   ├── useOfflineCache.ts
│   └── ...
├── utils/              # Utility functions
│   ├── exports.ts      # CSV/PDF export utilities
│   └── ...
├── integrations/       # External service integrations
│   └── supabase/       # Supabase client and types
└── ...

supabase/
├── functions/          # Edge Functions
│   ├── reports-weekly/ # Automated compliance reports
│   └── backups-nightly/ # Encrypted backup system
└── migrations/         # Database schema and policies

cypress/
├── e2e/               # End-to-end tests
│   ├── roles.cy.ts    # Role-based access tests
│   ├── checkins.cy.ts # Check-in workflow tests
│   └── exports.cy.ts  # Export functionality tests
└── support/           # Test utilities and commands

docs/                  # Additional documentation
├── API.md            # Edge Functions documentation
├── SECURITY.md       # Security guidelines and RLS policies
├── DEPLOYMENT.md     # Production deployment guide
└── CONTRIBUTING.md   # Development guidelines
```

## 🏗️ Architecture

### Frontend Stack
- **React 18** - Component-based UI library
- **TypeScript** - Type-safe JavaScript
- **Vite** - Fast build tool and dev server
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - High-quality component library
- **React Query** - Server state management
- **React Router** - Client-side routing

### Backend Stack
- **Supabase** - Backend-as-a-Service
  - PostgreSQL database with Row Level Security (RLS)
  - Real-time subscriptions
  - Edge Functions (Deno runtime)
  - Authentication and authorization
  - File storage with encryption

### Database Schema

```mermaid
erDiagram
    PATIENTS ||--o{ VISITS : has
    PATIENTS ||--o{ DOSAGES : receives
    PATIENTS ||--o{ CHECKINS : performs
    STAFF ||--o{ VISITS : manages
    STAFF ||--o{ DOSAGES : administers
    VISITS ||--o{ DOSAGES : contains
    
    PATIENTS {
        uuid id PK
        string first_name
        string last_name
        date date_of_birth
        string mrn
        timestamp created_at
        timestamp updated_at
    }
    
    VISITS {
        uuid id PK
        uuid patient_id FK
        uuid created_by FK
        timestamp scheduled_at
        timestamp arrived_at
        string status
        text notes
    }
    
    DOSAGES {
        uuid id PK
        uuid patient_id FK
        uuid visit_id FK
        uuid administered_by FK
        decimal amount_mg
        timestamp administered_at
    }
    
    STAFF {
        uuid id PK
        uuid user_id FK
        string full_name
        enum role
        boolean active
    }
```

## 👥 User Roles & Permissions

### 🔴 Admin
- **Full system access** - All features and data
- **User management** - Create and manage staff accounts
- **System settings** - Configure clinic operations
- **Audit access** - View complete audit logs
- **Reports** - Generate and export all reports

### 🔵 Clinician  
- **Patient care** - Full patient and visit management
- **Dosage administration** - Record and manage medications
- **Clinical reports** - Access patient-specific reports
- **Limited audit** - View patient-related audit entries

### ⚪ Reception
- **Check-in patients** - Process patient arrivals
- **View queue** - Monitor waiting patients
- **Basic patient info** - View contact and demographic data
- **No clinical access** - Cannot view or modify clinical data

## 🔒 Security Features

- **Row Level Security (RLS)** - Database-level access control
- **Audit Logging** - Tamper-evident hash chain for all actions
- **Role-Based Access Control (RBAC)** - Granular permissions system
- **Data Encryption** - Encrypted backups and secure storage
- **Session Management** - Secure authentication with Supabase Auth
- **HIPAA Compliance** - Healthcare data protection standards

## 📊 Production Features

### Real-Time Operations
- Live patient check-ins with instant notifications
- Real-time queue updates across all connected clients
- Automatic visit creation on patient check-in

### Compliance & Reporting
- **Weekly Compliance Reports** - Automated attendance and dosage analytics
- **Audit Trail** - Complete action logging with hash verification
- **Data Export** - CSV/PDF exports for regulatory reporting
- **Backup System** - Nightly encrypted backups with retention management

### Offline Capability
- **IndexedDB Caching** - Local storage for critical data
- **Offline Queue** - Sync operations when connection restored
- **Network Status** - Visual indicators for connection state

## 🧪 Testing

### Unit Tests
```bash
npm test
```

### End-to-End Tests
```bash
# Run all E2E tests
npm run e2e

# Open Cypress UI
npm run e2e:open

# Run specific test suite
npx cypress run --spec "cypress/e2e/roles.cy.ts"
```

### Test Coverage
- ✅ Role-based access control
- ✅ Patient check-in workflows  
- ✅ Dosage administration
- ✅ Export functionality
- ✅ Real-time updates
- ✅ Offline operations

## 📈 Monitoring & Analytics

### Edge Function Logs
Monitor system operations and performance:
- Weekly report generation
- Backup process status
- Error tracking and alerts

### Database Analytics
Built-in Supabase analytics for:
- Query performance
- Connection pooling
- Storage usage
- API endpoint metrics

## 🚀 Deployment

See [DEPLOYMENT.md](./docs/DEPLOYMENT.md) for detailed production deployment instructions.

### Quick Deploy with Lovable
1. Visit your [Lovable Project](https://lovable.dev/projects/89838ed1-e8c0-4962-ac66-91eb73686d11)
2. Click **Share → Publish**
3. Configure custom domain (optional)

## 📚 Documentation

- **[API Documentation](./docs/API.md)** - Edge Functions and endpoints
- **[Security Guide](./docs/SECURITY.md)** - RLS policies and security best practices  
- **[Deployment Guide](./docs/DEPLOYMENT.md)** - Production setup and configuration
- **[Contributing Guide](./docs/CONTRIBUTING.md)** - Development workflow and standards

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](./docs/CONTRIBUTING.md) for guidelines.

## 📄 License

This project is proprietary software for methadone treatment facilities. All rights reserved.

## 🆘 Support

For technical support or questions:
- Create an issue in this repository
- Contact the development team
- Refer to the documentation in the `docs/` directory

---

**⚡ Built with [Lovable](https://lovable.dev) - The AI-powered web development platform**