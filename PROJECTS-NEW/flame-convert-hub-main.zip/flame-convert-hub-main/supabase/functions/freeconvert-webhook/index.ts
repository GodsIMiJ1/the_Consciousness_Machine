// FreeConvert Webhook handler
// - Verifies HMAC signature using FREECONVERT_WEBHOOK_SECRET
// - Updates jobs table on completion/failure

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, freeconvert-signature",
};

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

function getAdminClient() {
  const url = Deno.env.get("SUPABASE_URL")!;
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(url, service);
}

async function verifySignature(rawBody: string, signatureHeader: string | null, secret: string | undefined): Promise<boolean> {
  if (!secret) return false;
  if (!signatureHeader) return false;

  try {
    // Some providers send headers like: t=timestamp, v1=hex
    // We'll extract the last hex-like part as signature if multiple values exist
    const candidate = signatureHeader.split(/[, ]/).reverse().find((p) => /[a-f0-9]{32,}/i.test(p)) || signatureHeader.trim();

    const key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"]
    );
    const sigBuf = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(rawBody));
    const computed = Array.from(new Uint8Array(sigBuf)).map((b) => b.toString(16).padStart(2, "0")).join("");

    // Timing-safe-ish compare
    if (computed.length !== candidate.length) return false;
    let match = 0;
    for (let i = 0; i < computed.length; i++) {
      match |= computed.charCodeAt(i) ^ candidate.charCodeAt(i);
    }
    return match === 0;
  } catch (e) {
    console.error("Signature verification error:", e);
    return false;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: corsHeaders });
  }

  const admin = getAdminClient();
  const secret = Deno.env.get("FREECONVERT_WEBHOOK_SECRET");
  const sigHeader = req.headers.get("FreeConvert-Signature");

  const rawBody = await req.text();

  const ok = await verifySignature(rawBody, sigHeader, secret);
  if (!ok) {
    console.warn("Invalid FreeConvert webhook signature");
    return new Response(JSON.stringify({ error: "invalid signature" }), {
      status: 401,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let payload: any = {};
  try {
    payload = JSON.parse(rawBody);
  } catch (e) {
    console.error("Invalid JSON payload", e);
    return new Response(JSON.stringify({ error: "invalid json" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // FreeConvert events could be job.* or task.*
  // We try to extract identifiers and result url
  const taskId = payload?.id || payload?.task?.id;
  const jobId = payload?.job?.id || payload?.job_id;
  const status = payload?.status || payload?.event || payload?.type;
  const resultUrl = payload?.result?.url || payload?.result?.files?.[0]?.url || null;
  const errorMessage = payload?.message || payload?.error || null;

  try {
    // Try match by export task id first, then by provider_job_id
    let q = admin.from("jobs").select("id, options, provider_job_id").limit(1);
    if (taskId) {
      q = q.contains("options", { freeconvert: { export_task_id: taskId } });
    }
    let { data: rows, error: selErr } = await q;

    if ((!rows || rows.length === 0) && jobId) {
      const alt = await admin.from("jobs").select("id").eq("provider_job_id", jobId).limit(1);
      rows = alt.data || [];
      selErr = selErr || alt.error || null;
    }

    if (selErr) {
      console.error("Lookup error:", selErr);
    }

    if (!rows || rows.length === 0) {
      console.warn("No matching job found for webhook", { taskId, jobId });
      return new Response(JSON.stringify({ ok: true }), { status: 200, headers: corsHeaders });
    }

    const job = rows[0];

    if (String(status).toLowerCase().includes("complete")) {
      const { error: updErr } = await admin
        .from("jobs")
        .update({ status: "completed", progress: 100, output_url: resultUrl ?? null })
        .eq("id", job.id);
      if (updErr) console.error("Update job completed error:", updErr);
    } else if (String(status).toLowerCase().includes("fail")) {
      const { error: updErr } = await admin
        .from("jobs")
        .update({ status: "failed", error_message: errorMessage ?? "Conversion failed" })
        .eq("id", job.id);
      if (updErr) console.error("Update job failed error:", updErr);
    } else if (String(status).toLowerCase().includes("progress")) {
      const pct = payload?.progress ?? null;
      if (pct != null) {
        const { error: updErr } = await admin
          .from("jobs")
          .update({ status: "processing", progress: Math.max(0, Math.min(100, Number(pct))) })
          .eq("id", job.id);
        if (updErr) console.error("Update job progress error:", updErr);
      }
    }

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("Webhook processing error:", e);
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
