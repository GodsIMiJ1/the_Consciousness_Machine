// FreeConvert conversion orchestrator
// - Creates import/upload, convert, export tasks
// - Returns signed form data for the client to upload directly to FreeConvert
// - Persists a job row (if possible) and stores provider task IDs for webhook correlation

// IMPORTANT:
// - Requires secrets: FREECONVERT_API_KEY, SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, SUPABASE_ANON_KEY
// - Webhook handler lives at functions/freeconvert-webhook (configured as public)

// CORS headers per Lovable/Supabase guidelines
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

interface InitRequestBody {
  action: "init";
  file_name: string;
  file_size: number;
  mime_type: string;
  preset: string;
  target_format: string; // e.g. jpg, png, webp, pdf, docx, mp3, mp4
  options?: Record<string, unknown>; // quality, stripMetadata, bitrate, resolution, compressLevel, etc.
}

interface FreeConvertTaskResponse {
  id: string;
  status?: string;
  job?: { id?: string };
  result?: any;
  // other fields ignored for brevity
}

function getSupabaseClients(req: Request) {
  const url = Deno.env.get("SUPABASE_URL")!;
  const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  // Authed client (uses end-user JWT if present)
  const supabase = createClient(url, anon, {
    global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } },
  });
  // Admin client for privileged writes (bypasses RLS as needed)
  const admin = createClient(url, service);

  return { supabase, admin };
}

async function createImportTask(apiKey: string): Promise<FreeConvertTaskResponse> {
  const res = await fetch("https://api.freeconvert.com/v1/process/import/upload", {
    method: "POST",
    headers: {
      Accept: "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
  });
  if (!res.ok) throw new Error(`import/upload failed: ${res.status} ${await res.text()}`);
  return res.json();
}

async function createConvertTask(apiKey: string, inputTaskId: string, format: string, options?: Record<string, unknown>): Promise<FreeConvertTaskResponse> {
  const body = { input: inputTaskId, format, options: options ?? {} };
  const res = await fetch("https://api.freeconvert.com/v1/process/convert", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`convert failed: ${res.status} ${await res.text()}`);
  return res.json();
}

async function createExportTask(apiKey: string, inputTaskId: string): Promise<FreeConvertTaskResponse> {
  const body = { input: inputTaskId };
  const res = await fetch("https://api.freeconvert.com/v1/process/export/url", {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`export/url failed: ${res.status} ${await res.text()}`);
  return res.json();
}

Deno.serve(async (req) => {
  // Handle CORS preflight
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405, headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("FREECONVERT_API_KEY");
    if (!apiKey) {
      console.error("Missing FREECONVERT_API_KEY secret");
      return new Response(JSON.stringify({ error: "FREECONVERT_API_KEY not configured" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { supabase, admin } = getSupabaseClients(req);

    const body = (await req.json()) as InitRequestBody;
    if (!body || body.action !== "init") {
      return new Response(JSON.stringify({ error: "Invalid request body" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Try to resolve current user (if auth in place)
    const { data: userData } = await supabase.auth.getUser();
    const userId = userData?.user?.id ?? crypto.randomUUID(); // fallback guest id if unauthenticated

    // Create a job row (admin client to avoid RLS issues if unauthenticated)
    const jobInsert = {
      provider: "freeconvert",
      user_id: userId,
      original_name: body.file_name,
      mime_type: body.mime_type,
      file_size: body.file_size,
      target_format: body.target_format,
      preset: body.preset,
      status: "queued",
      progress: 0,
      options: {
        requested_options: body.options ?? {},
        freeconvert: {},
      },
    } as Record<string, unknown>;

    const { data: jobRow, error: jobErr } = await admin
      .from("jobs")
      .insert(jobInsert)
      .select("id")
      .single();

    if (jobErr) {
      console.error("Failed to insert job:", jobErr);
      return new Response(JSON.stringify({ error: "Failed to create job" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Build FreeConvert tasks
    const importTask = await createImportTask(apiKey);
    const importTaskId = importTask.id;

    const convertTask = await createConvertTask(apiKey, importTaskId, body.target_format, body.options);
    const convertTaskId = convertTask.id;

    const exportTask = await createExportTask(apiKey, convertTaskId);
    const exportTaskId = exportTask.id;

    const providerJobId = importTask.job?.id || convertTask.job?.id || exportTask.job?.id || null;

    // Update job with provider references
    const freeconvertMeta = {
      import_task_id: importTaskId,
      convert_task_id: convertTaskId,
      export_task_id: exportTaskId,
      provider_job_id: providerJobId,
    };

    const { error: updErr } = await admin
      .from("jobs")
      .update({
        provider_job_id: providerJobId,
        options: {
          requested_options: body.options ?? {},
          freeconvert: freeconvertMeta,
        },
      })
      .eq("id", jobRow!.id);

    if (updErr) {
      console.warn("Failed to update job with provider ids:", updErr);
    }

    // Prepare form upload details from importTask
    // According to docs, result.form contains url + fields/parameters
    const form = importTask?.result?.form || importTask?.result?.Form || importTask?.result; // fallback variants
    const uploadUrl = form?.url || form?.action || null;
    const fields = form?.fields || form?.parameters || {};

    const respPayload = {
      job_id: jobRow!.id,
      provider_job_id: providerJobId,
      upload: {
        url: uploadUrl,
        fields,
      },
      tasks: {
        import: importTaskId,
        convert: convertTaskId,
        export: exportTaskId,
      },
    };

    return new Response(JSON.stringify(respPayload), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("convert function error", e);
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
