-- Create jobs table
CREATE TYPE job_status AS ENUM ('queued', 'processing', 'completed', 'failed', 'cancelled');
CREATE TYPE provider_type AS ENUM ('freeconvert', 'sovereign');

CREATE TABLE public.jobs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users ON DELETE CASCADE,
  original_name TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  file_size BIGINT NOT NULL,
  preset TEXT NOT NULL,
  target_format TEXT NOT NULL,
  options JSONB NOT NULL DEFAULT '{}',
  provider provider_type NOT NULL,
  provider_job_id TEXT,
  status job_status NOT NULL DEFAULT 'queued',
  progress INTEGER NOT NULL DEFAULT 0,
  error_message TEXT,
  input_path TEXT,
  output_path TEXT,
  output_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;

-- Create policies for jobs
CREATE POLICY "Users can view own jobs and admins can view all"
ON public.jobs FOR SELECT
USING (user_id = auth.uid() OR get_current_user_role() = 'admin');

CREATE POLICY "Users can create own jobs"
ON public.jobs FOR INSERT
WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can update own jobs and admins can update all"
ON public.jobs FOR UPDATE
USING (user_id = auth.uid() OR get_current_user_role() = 'admin');

-- Create settings table for provider configuration
CREATE TABLE public.conversion_settings (
  key TEXT NOT NULL PRIMARY KEY,
  value JSONB NOT NULL,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE public.conversion_settings ENABLE ROW LEVEL SECURITY;

-- Create policies for settings (admin only)
CREATE POLICY "Only admins can manage conversion settings"
ON public.conversion_settings FOR ALL
USING (get_current_user_role() = 'admin')
WITH CHECK (get_current_user_role() = 'admin');

-- Insert default settings
INSERT INTO public.conversion_settings (key, value, description) VALUES
('provider_config', '{"mode": "sovereign", "privacyMode": true, "allowExternal": false, "sizeLimitMB": 100}', 'Provider routing configuration'),
('freeconvert_config', '{"enabled": true, "webhook_secret": null}', 'FreeConvert API configuration'),
('sovereign_config', '{"enabled": true, "docker_mode": true}', 'Sovereign provider configuration');

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES 
('uploads', 'uploads', false),
('outputs', 'outputs', false);

-- Create storage policies for uploads bucket
CREATE POLICY "Users can upload their own files"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'uploads' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can view their own uploads"
ON storage.objects FOR SELECT
USING (bucket_id = 'uploads' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own uploads"
ON storage.objects FOR DELETE
USING (bucket_id = 'uploads' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Create storage policies for outputs bucket
CREATE POLICY "Users can view their own outputs"
ON storage.objects FOR SELECT
USING (bucket_id = 'outputs' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "System can create outputs"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'outputs');

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_conversion_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;

-- Create triggers for updated_at
CREATE TRIGGER jobs_updated_at
  BEFORE UPDATE ON public.jobs
  FOR EACH ROW EXECUTE FUNCTION public.update_conversion_updated_at();

CREATE TRIGGER conversion_settings_updated_at
  BEFORE UPDATE ON public.conversion_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_conversion_updated_at();