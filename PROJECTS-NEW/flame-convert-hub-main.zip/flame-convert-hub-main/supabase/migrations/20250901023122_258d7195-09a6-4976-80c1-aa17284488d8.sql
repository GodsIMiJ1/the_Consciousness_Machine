-- Remove authentication requirements from jobs table
DROP POLICY IF EXISTS "Users can create own jobs" ON jobs;
DROP POLICY IF EXISTS "Users can view own jobs and admins can view all" ON jobs;
DROP POLICY IF EXISTS "Users can update own jobs and admins can update all" ON jobs;

-- Create new policies that allow public access
CREATE POLICY "Anyone can create jobs" ON jobs FOR INSERT WITH CHECK (true);
CREATE POLICY "Anyone can view jobs" ON jobs FOR SELECT USING (true);
CREATE POLICY "Anyone can update jobs" ON jobs FOR UPDATE USING (true);