import { useState, useCallback } from 'react';
import { Upload, X, File, Image, FileText, Music, Video } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface UploadedFile {
  id: string;
  file: File;
  type: 'image' | 'document' | 'pdf' | 'audio' | 'video';
}

interface FileUploadProps {
  onFilesSelected: (files: UploadedFile[]) => void;
}

const getFileType = (file: File): 'image' | 'document' | 'pdf' | 'audio' | 'video' => {
  const type = file.type;
  if (type.startsWith('image/')) return 'image';
  if (type === 'application/pdf') return 'pdf';
  if (type.startsWith('audio/')) return 'audio';
  if (type.startsWith('video/')) return 'video';
  return 'document';
};

const getFileIcon = (type: string) => {
  switch (type) {
    case 'image': return <Image className="w-5 h-5" />;
    case 'pdf': return <FileText className="w-5 h-5 text-red-400" />;
    case 'audio': return <Music className="w-5 h-5 text-green-400" />;
    case 'video': return <Video className="w-5 h-5 text-blue-400" />;
    default: return <File className="w-5 h-5" />;
  }
};

export const FileUpload = ({ onFilesSelected }: FileUploadProps) => {
  const [dragOver, setDragOver] = useState(false);
  const [files, setFiles] = useState<UploadedFile[]>([]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    addFiles(droppedFiles);
  }, []);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files);
      addFiles(selectedFiles);
    }
  }, []);

  const addFiles = (newFiles: File[]) => {
    const uploadedFiles: UploadedFile[] = newFiles.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      file,
      type: getFileType(file)
    }));
    
    const updatedFiles = [...files, ...uploadedFiles];
    setFiles(updatedFiles);
    onFilesSelected(updatedFiles);
  };

  const removeFile = (id: string) => {
    const updatedFiles = files.filter(f => f.id !== id);
    setFiles(updatedFiles);
    onFilesSelected(updatedFiles);
  };

  return (
    <Card className="p-6 bg-gradient-dark shadow-card border-border">
      <div
        className={`
          border-2 border-dashed rounded-lg p-8 text-center transition-colors
          ${dragOver 
            ? 'border-primary bg-primary/5' 
            : 'border-border hover:border-primary/50'
          }
        `}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <Upload className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
        <p className="text-lg font-medium mb-2">Drop files here or click to upload</p>
        <p className="text-sm text-muted-foreground mb-4">
          Supports images, documents, PDFs, audio, and video files
        </p>
        <input
          type="file"
          multiple
          className="hidden"
          id="file-upload"
          onChange={handleFileSelect}
          accept="image/*,.pdf,.doc,.docx,.mp3,.mp4,.wav,.avi,.mov"
        />
        <Button asChild variant="secondary">
          <label htmlFor="file-upload" className="cursor-pointer">
            Select Files
          </label>
        </Button>
      </div>

      {files.length > 0 && (
        <div className="mt-6 space-y-2">
          <h3 className="font-medium text-sm text-muted-foreground">Selected Files</h3>
          {files.map((uploadedFile) => (
            <div
              key={uploadedFile.id}
              className="flex items-center justify-between p-3 bg-secondary rounded-lg"
            >
              <div className="flex items-center space-x-3">
                {getFileIcon(uploadedFile.type)}
                <div>
                  <p className="font-medium text-sm">{uploadedFile.file.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(uploadedFile.file.size / 1024 / 1024).toFixed(2)} MB
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeFile(uploadedFile.id)}
                className="h-8 w-8 p-0"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
};