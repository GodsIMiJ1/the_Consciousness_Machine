import { useState } from 'react';
import { Image, FileText, File, Music, Video, Settings } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';

export interface ConversionOptions {
  preset: string;
  targetFormat: string;
  quality?: number;
  width?: number;
  height?: number;
  keepAspect?: boolean;
  stripMetadata?: boolean;
  bitrate?: string;
  resolution?: string;
  compressLevel?: number;
}

interface PresetSelectorProps {
  onOptionsChange: (options: ConversionOptions) => void;
}

export const PresetSelector = ({ onOptionsChange }: PresetSelectorProps) => {
  const [activePreset, setActivePreset] = useState('images');
  const [options, setOptions] = useState<ConversionOptions>({
    preset: 'images',
    targetFormat: 'jpg',
    quality: 85,
    keepAspect: true,
    stripMetadata: false
  });

  const updateOptions = (newOptions: Partial<ConversionOptions>) => {
    const updated = { ...options, ...newOptions };
    setOptions(updated);
    onOptionsChange(updated);
  };

  const handlePresetChange = (preset: string) => {
    setActivePreset(preset);
    const baseOptions = { preset };
    
    switch (preset) {
      case 'images':
        updateOptions({ ...baseOptions, targetFormat: 'jpg', quality: 85 });
        break;
      case 'documents':
        updateOptions({ ...baseOptions, targetFormat: 'pdf' });
        break;
      case 'pdf':
        updateOptions({ ...baseOptions, targetFormat: 'compressed', compressLevel: 3 });
        break;
      case 'audio':
        updateOptions({ ...baseOptions, targetFormat: 'mp3', bitrate: '128' });
        break;
      case 'video':
        updateOptions({ ...baseOptions, targetFormat: 'mp4', resolution: '720p' });
        break;
    }
  };

  return (
    <Card className="bg-gradient-dark shadow-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Settings className="w-5 h-5 text-primary" />
          <span>Conversion Presets</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs value={activePreset} onValueChange={handlePresetChange}>
          <TabsList className="grid w-full grid-cols-5 bg-secondary">
            <TabsTrigger value="images" className="flex items-center space-x-1">
              <Image className="w-4 h-4" />
              <span className="hidden sm:inline">Images</span>
            </TabsTrigger>
            <TabsTrigger value="documents" className="flex items-center space-x-1">
              <FileText className="w-4 h-4" />
              <span className="hidden sm:inline">Docs</span>
            </TabsTrigger>
            <TabsTrigger value="pdf" className="flex items-center space-x-1">
              <File className="w-4 h-4" />
              <span className="hidden sm:inline">PDF</span>
            </TabsTrigger>
            <TabsTrigger value="audio" className="flex items-center space-x-1">
              <Music className="w-4 h-4" />
              <span className="hidden sm:inline">Audio</span>
            </TabsTrigger>
            <TabsTrigger value="video" className="flex items-center space-x-1">
              <Video className="w-4 h-4" />
              <span className="hidden sm:inline">Video</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="images" className="space-y-4 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Target Format</Label>
                <Select value={options.targetFormat} onValueChange={(value) => updateOptions({ targetFormat: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="jpg">JPEG</SelectItem>
                    <SelectItem value="png">PNG</SelectItem>
                    <SelectItem value="webp">WebP</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Quality: {options.quality}%</Label>
                <Slider
                  value={[options.quality || 85]}
                  onValueChange={([value]) => updateOptions({ quality: value })}
                  max={100}
                  min={10}
                  step={5}
                  className="w-full"
                />
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Switch
                checked={options.stripMetadata}
                onCheckedChange={(checked) => updateOptions({ stripMetadata: checked })}
              />
              <Label>Strip Metadata</Label>
            </div>
          </TabsContent>

          <TabsContent value="documents" className="space-y-4 mt-6">
            <div className="space-y-2">
              <Label>Target Format</Label>
              <Select value={options.targetFormat} onValueChange={(value) => updateOptions({ targetFormat: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pdf">PDF</SelectItem>
                  <SelectItem value="docx">Word Document</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="pdf" className="space-y-4 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Operation</Label>
                <Select value={options.targetFormat} onValueChange={(value) => updateOptions({ targetFormat: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="compressed">Compress</SelectItem>
                    <SelectItem value="merge">Merge</SelectItem>
                    <SelectItem value="split">Split</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {options.targetFormat === 'compressed' && (
                <div className="space-y-2">
                  <Label>Compression Level: {options.compressLevel}</Label>
                  <Slider
                    value={[options.compressLevel || 3]}
                    onValueChange={([value]) => updateOptions({ compressLevel: value })}
                    max={5}
                    min={1}
                    step={1}
                    className="w-full"
                  />
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="audio" className="space-y-4 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Target Format</Label>
                <Select value={options.targetFormat} onValueChange={(value) => updateOptions({ targetFormat: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mp3">MP3</SelectItem>
                    <SelectItem value="wav">WAV</SelectItem>
                    <SelectItem value="flac">FLAC</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Bitrate</Label>
                <Select value={options.bitrate} onValueChange={(value) => updateOptions({ bitrate: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="128">128 kbps</SelectItem>
                    <SelectItem value="192">192 kbps</SelectItem>
                    <SelectItem value="256">256 kbps</SelectItem>
                    <SelectItem value="320">320 kbps</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="video" className="space-y-4 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Target Format</Label>
                <Select value={options.targetFormat} onValueChange={(value) => updateOptions({ targetFormat: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mp4">MP4</SelectItem>
                    <SelectItem value="webm">WebM</SelectItem>
                    <SelectItem value="avi">AVI</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Resolution</Label>
                <Select value={options.resolution} onValueChange={(value) => updateOptions({ resolution: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="480p">480p</SelectItem>
                    <SelectItem value="720p">720p</SelectItem>
                    <SelectItem value="1080p">1080p</SelectItem>
                    <SelectItem value="4k">4K</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};