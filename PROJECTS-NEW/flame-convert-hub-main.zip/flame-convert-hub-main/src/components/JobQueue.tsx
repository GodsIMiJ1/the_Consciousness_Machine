import { useState, useEffect } from 'react';
import { Play, Download, X, Clock, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';

export interface Job {
  id: string;
  fileName: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  progress: number;
  preset: string;
  targetFormat: string;
  createdAt: Date;
  downloadUrl?: string;
  error?: string;
}

interface JobQueueProps {
  jobs: Job[];
  onCancelJob: (jobId: string) => void;
  onDownload: (jobId: string) => void;
}

const getStatusIcon = (status: string, progress: number) => {
  switch (status) {
    case 'queued':
      return <Clock className="w-4 h-4 text-muted-foreground" />;
    case 'processing':
      return <Loader2 className="w-4 h-4 text-primary animate-spin" />;
    case 'completed':
      return <CheckCircle className="w-4 h-4 text-green-400" />;
    case 'failed':
      return <AlertCircle className="w-4 h-4 text-destructive" />;
    default:
      return <Clock className="w-4 h-4 text-muted-foreground" />;
  }
};

const getStatusColor = (status: string) => {
  switch (status) {
    case 'queued':
      return 'secondary';
    case 'processing':
      return 'default';
    case 'completed':
      return 'default';
    case 'failed':
      return 'destructive';
    default:
      return 'secondary';
  }
};

export const JobQueue = ({ jobs, onCancelJob, onDownload }: JobQueueProps) => {
  if (jobs.length === 0) {
    return (
      <Card className="bg-gradient-dark shadow-card border-border">
        <CardContent className="p-8 text-center">
          <Play className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
          <p className="text-muted-foreground">No conversion jobs yet</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-dark shadow-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Conversion Queue</span>
          <Badge variant="secondary">{jobs.length} jobs</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {jobs.map((job) => (
          <div
            key={job.id}
            className="p-4 bg-secondary rounded-lg border border-border"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center space-x-3">
                {getStatusIcon(job.status, job.progress)}
                <div>
                  <p className="font-medium text-sm">{job.fileName}</p>
                  <p className="text-xs text-muted-foreground">
                    {job.preset} → {job.targetFormat.toUpperCase()}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant={getStatusColor(job.status) as any}>
                  {job.status}
                </Badge>
                {job.status === 'completed' && (
                  <Button
                    size="sm"
                    onClick={() => onDownload(job.id)}
                    className="h-8"
                  >
                    <Download className="w-3 h-3 mr-1" />
                    Download
                  </Button>
                )}
                {(job.status === 'queued' || job.status === 'processing') && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onCancelJob(job.id)}
                    className="h-8 w-8 p-0"
                  >
                    <X className="w-3 h-3" />
                  </Button>
                )}
              </div>
            </div>
            
            {job.status === 'processing' && (
              <div className="space-y-1">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Progress</span>
                  <span>{job.progress}%</span>
                </div>
                <Progress value={job.progress} className="h-2" />
              </div>
            )}
            
            {job.status === 'failed' && job.error && (
              <div className="mt-2 p-2 bg-destructive/10 border border-destructive/20 rounded text-xs text-destructive">
                {job.error}
              </div>
            )}
            
            <div className="mt-2 text-xs text-muted-foreground">
              Created {job.createdAt.toLocaleTimeString()}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};