import { useState } from 'react';
import { Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Header } from '@/components/Header';
import { FileUpload } from '@/components/FileUpload';
import { PresetSelector, ConversionOptions } from '@/components/PresetSelector';
import { JobQueue, Job } from '@/components/JobQueue';
import { supabase } from '@/integrations/supabase/client';

interface UploadedFile {
  id: string;
  file: File;
  type: 'image' | 'document' | 'pdf' | 'audio' | 'video';
}

const Index = () => {
  const { toast } = useToast();
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [options, setOptions] = useState<ConversionOptions>({
    preset: 'images',
    targetFormat: 'jpg',
    quality: 85,
    keepAspect: true,
    stripMetadata: false
  });
  const [jobs, setJobs] = useState<Job[]>([]);

  const handleFilesSelected = (selectedFiles: UploadedFile[]) => {
    setFiles(selectedFiles);
  };

  const handleOptionsChange = (newOptions: ConversionOptions) => {
    setOptions(newOptions);
  };

  const handleConvert = async () => {
    if (files.length === 0) {
      toast({
        title: "No files selected",
        description: "Please select files to convert.",
        variant: "destructive"
      });
      return;
    }

    // Create jobs for each file
    for (const file of files) {
      try {
        // Call the edge function to initialize conversion
        const { data, error } = await supabase.functions.invoke('convert', {
          body: {
            original_name: file.file.name,
            mime_type: file.file.type,
            file_size: file.file.size,
            target_format: options.targetFormat,
            preset: options.preset,
            options: options
          }
        });

        if (error) throw error;

        // Add job to queue
        const newJob: Job = {
          id: data.jobId,
          fileName: file.file.name,
          status: 'queued',
          progress: 0,
          preset: options.preset,
          targetFormat: options.targetFormat,
          createdAt: new Date()
        };

        setJobs(prev => [...prev, newJob]);

        // Upload file using the provided URL and form fields
        const formData = new FormData();
        Object.entries(data.formFields).forEach(([key, value]) => {
          formData.append(key, value as string);
        });
        formData.append('file', file.file);

        const uploadResponse = await fetch(data.uploadUrl, {
          method: 'POST',
          body: formData,
        });

        if (!uploadResponse.ok) {
          throw new Error('Upload failed');
        }

        // Update job status to processing
        setJobs(prev => prev.map(job => 
          job.id === data.jobId 
            ? { ...job, status: 'processing' as const }
            : job
        ));

      } catch (error) {
        console.error('Conversion error:', error);
        toast({
          title: "Conversion Failed",
          description: error instanceof Error ? error.message : "An error occurred during conversion.",
          variant: "destructive",
        });
      }
    }

    setFiles([]);
  };

  const handleCancelJob = (jobId: string) => {
    setJobs(prev => prev.filter(job => job.id !== jobId));
    toast({
      title: "Job cancelled",
      description: "The conversion job has been cancelled.",
    });
  };

  const handleDownload = (jobId: string) => {
    toast({
      title: "Download started",
      description: "In a real implementation, this would download the converted file.",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">
            Universal File Conversion
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Convert files across images, documents, audio, video, and PDFs with 
            provider-agnostic routing to third-party APIs or sovereign infrastructure.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          <FileUpload onFilesSelected={handleFilesSelected} />
          <PresetSelector onOptionsChange={handleOptionsChange} />
        </div>

        <div className="text-center mb-8">
          <Button 
            onClick={handleConvert}
            disabled={files.length === 0}
            className="bg-gradient-flame hover:shadow-flame transition-all duration-300 text-lg px-8 py-6 h-auto"
          >
            <Zap className="w-5 h-5 mr-2" />
            Convert Files
          </Button>
        </div>

        <JobQueue 
          jobs={jobs}
          onCancelJob={handleCancelJob}
          onDownload={handleDownload}
        />
      </main>
    </div>
  );
};

export default Index;