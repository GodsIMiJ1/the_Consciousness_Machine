import { ChevronLeft, ChevronRight, Menu } from 'lucide-react';
import { Button } from './ui/button';

interface PresentationNavProps {
  currentSlide: number;
  totalSlides: number;
  onSlideChange: (slide: number) => void;
}

export function PresentationNav({ currentSlide, totalSlides, onSlideChange }: PresentationNavProps) {
  const slideNames = [
    'Title',
    'Problem',
    'Solution',
    'Investment',
    'Architecture',
    'Pembroke First',
    'Team',
    'Next Steps'
  ];

  return (
    <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50">
      <div className="flex items-center gap-4 bg-white/90 backdrop-blur-sm rounded-lg border border-border px-6 py-3 shadow-lg">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onSlideChange(Math.max(0, currentSlide - 1))}
          disabled={currentSlide === 0}
          className="border-[var(--deep-navy)] text-[var(--deep-navy)] hover:bg-[var(--deep-navy)] hover:text-white"
        >
          <ChevronLeft className="w-4 h-4" />
        </Button>
        
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-[var(--neutral-gray)]">
            {currentSlide + 1} / {totalSlides}
          </span>
          <span className="text-sm text-[var(--neutral-gray)] hidden md:block">
            • {slideNames[currentSlide]}
          </span>
        </div>

        <Button
          variant="outline"
          size="sm"
          onClick={() => onSlideChange(Math.min(totalSlides - 1, currentSlide + 1))}
          disabled={currentSlide === totalSlides - 1}
          className="border-[var(--deep-navy)] text-[var(--deep-navy)] hover:bg-[var(--deep-navy)] hover:text-white"
        >
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}