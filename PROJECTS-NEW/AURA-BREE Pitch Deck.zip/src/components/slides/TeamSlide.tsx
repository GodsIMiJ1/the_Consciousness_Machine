import { Brain, Search, Settings, Phone, Calendar, User, FileText, GraduationCap, Shield } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export function TeamSlide() {
  const aiTeam = [
    {
      name: "Omari (ChatGPT-4)",
      role: "Strategic Planning & Protocol Development",
      icon: <Brain className="w-6 h-6" />,
      color: "bg-blue-500"
    },
    {
      name: "Augment Code",
      role: "System Architecture",
      icon: <Settings className="w-6 h-6" />,
      color: "bg-orange-500"
    },
    {
      name: "Claude (Anthropic)",
      role: "Ghost Writer & Documentation",
      icon: <FileText className="w-6 h-6" />,
      color: "bg-purple-500"
    },
    {
      name: "Perplexity",
      role: "Research & Competitive Intelligence",
      icon: <Search className="w-6 h-6" />,
      color: "bg-green-500"
    }
  ];

  const supportPromises = [
    "24/7 AI-powered customer service",
    "Monthly on-site visits by James",
    "Continuous system evolution",
    "Direct founder accessibility"
  ];

  return (
    <div className="slide-container bg-white flex items-center">
      <div className="w-full max-w-7xl mx-auto px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-[var(--deep-navy)] mb-4">
            One Visionary, Infinite Capability
          </h2>
          <div className="w-24 h-1 bg-[var(--empire-gold)] mx-auto"></div>
        </div>

        <div className="grid grid-cols-3 gap-12">
          {/* Left - James Ingersoll */}
          <div className="text-center">
            <div className="relative mb-6">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1621282807498-aac696326c91?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBoZWFsdGhjYXJlJTIwQ0VPJTIwZXhlY3V0aXZlfGVufDF8fHx8MTc1NjY5NTczN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="James Ingersoll - Professional headshot"
                className="w-48 h-48 object-cover rounded-full mx-auto border-4 border-[var(--empire-gold)]"
              />
              <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 bg-[var(--empire-gold)] px-4 py-1 rounded-full">
                <span className="text-[var(--deep-navy)] font-bold text-sm">FOUNDER & CEO</span>
              </div>
            </div>
            
            <h3 className="text-2xl font-bold text-[var(--deep-navy)] mb-2">
              James Ingersoll
            </h3>
            <p className="text-[var(--empire-gold)] font-semibold text-lg mb-4">
              Architect of Healthcare Sovereignty
            </p>
            
            <div className="text-left space-y-2 text-sm text-[var(--neutral-gray)]">
              <p>• Healthcare technology visionary</p>
              <p>• Patient advocacy background</p>
              <p>• AI integration pioneer</p>
              <p>• Healthcare sovereignty expert</p>
            </div>
          </div>

          {/* Center - AI Empire */}
          <div>
            <h3 className="text-2xl font-bold text-[var(--deep-navy)] mb-6 text-center">
              The AI Empire
            </h3>
            
            <div className="space-y-4">
              {aiTeam.map((ai, index) => (
                <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-gray-50 border border-gray-200">
                  <div className={`w-12 h-12 ${ai.color} rounded-full flex items-center justify-center text-white`}>
                    {ai.icon}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-[var(--deep-navy)]">
                      {ai.name}
                    </h4>
                    <p className="text-sm text-[var(--neutral-gray)]">
                      {ai.role}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-gradient-to-r from-[var(--deep-navy)] to-[var(--sovereign-green)] rounded-lg text-white">
              <h4 className="font-bold mb-2">Complete Ecosystem:</h4>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <GraduationCap className="w-4 h-4" />
                  <span>AI Training Platform</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  <span>Clinical Documentation</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4" />
                  <span>Legal Compliance Hub</span>
                </div>
                <div className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  <span>Full System Integration</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right - Support Promise */}
          <div>
            <h3 className="text-2xl font-bold text-[var(--deep-navy)] mb-6 text-center">
              Support Promise
            </h3>
            
            <div className="space-y-4">
              {supportPromises.map((promise, index) => (
                <div key={index} className="flex items-center gap-3 p-3 rounded-lg bg-green-50 border-l-4 border-[var(--sovereign-green)]">
                  <div className="w-8 h-8 bg-[var(--sovereign-green)] rounded-full flex items-center justify-center">
                    <span className="text-white font-bold text-sm">{index + 1}</span>
                  </div>
                  <p className="text-[var(--deep-navy)] font-medium">{promise}</p>
                </div>
              ))}
            </div>

            {/* Contact Card */}
            <div className="mt-6 p-6 bg-[var(--empire-gold)] rounded-lg">
              <h4 className="font-bold text-[var(--deep-navy)] mb-4 text-center">
                Direct Access to Leadership
              </h4>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <User className="w-5 h-5 text-[var(--deep-navy)]" />
                  <span className="text-[var(--deep-navy)]">James Ingersoll</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-[var(--deep-navy)]" />
                  <span className="text-[var(--deep-navy)] text-xs">james@godsimij-ai-solutions.com</span>
                </div>
                <div className="flex items-center gap-3">
                  <Calendar className="w-5 h-5 text-[var(--deep-navy)]" />
                  <span className="text-[var(--deep-navy)]">Monthly on-site visits</span>
                </div>
              </div>
            </div>

            {/* Efficiency Statement */}
            <div className="mt-4 p-4 bg-[var(--deep-navy)] rounded-lg text-center">
              <p className="text-white font-bold text-sm">
                AI-Powered Efficiency
              </p>
              <p className="text-white/80 text-xs mt-1">
                Building tomorrow's healthcare today
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}