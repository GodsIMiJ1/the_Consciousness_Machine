import { ImageWithFallback } from '../figma/ImageWithFallback';

export function TitleSlide() {
  return (
    <div className="slide-container hero-gradient flex items-center justify-center relative overflow-hidden">
      {/* Subtle medical cross pattern overlay */}
      <div className="absolute inset-0 opacity-5">
        <div className="w-full h-full bg-white" 
             style={{
               backgroundImage: `url("data:image/svg+xml,%3csvg width='40' height='40' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M20 0v40M0 20h40' stroke='white' stroke-width='1' fill='none'/%3e%3c/svg%3e")`,
               backgroundSize: '80px 80px'
             }}>
        </div>
      </div>

      <div className="text-center z-10 max-w-4xl mx-auto px-8">
        {/* Main Logo/Title */}
        <div className="mb-8">
          <h1 className="text-8xl font-bold text-white mb-4 tracking-wide">
            AURA-BREE
          </h1>
          <div className="w-32 h-1 bg-[var(--empire-gold)] mx-auto mb-6"></div>
        </div>

        {/* Subtitle */}
        <h2 className="text-3xl font-semibold text-white/90 mb-6 leading-relaxed">
          World's First Sovereign AI Wellness System
        </h2>

        {/* Target */}
        <div className="bg-white/10 backdrop-blur-sm rounded-lg px-8 py-6 border border-white/20">
          <h3 className="text-2xl font-medium text-[var(--empire-gold)] mb-2">
            Pembroke Methadone Clinic Deployment
          </h3>
          <p className="text-lg text-white/80">
            Healthcare Technology That Serves Your Mission
          </p>
        </div>

        {/* Presenter Info */}
        <div className="absolute bottom-8 right-8 text-right">
          <p className="text-white/80 text-lg">
            Presented by
          </p>
          <p className="text-white font-semibold text-xl">
            James Ingersoll
          </p>
          <p className="text-[var(--empire-gold)] font-medium">
            Founder & CEO
          </p>
        </div>
      </div>
    </div>
  );
}