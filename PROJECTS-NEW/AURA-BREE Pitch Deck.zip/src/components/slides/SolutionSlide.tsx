import { Check, Server, Smartphone, Monitor, Shield, Zap, Users, GraduationCap, FileText } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export function SolutionSlide() {
  const benefits = [
    {
      icon: <Shield className="w-6 h-6" />,
      title: "100% Local Data",
      description: "Never leaves your building"
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Internet Independent",
      description: "Works perfectly offline"
    },
    {
      icon: <DollarSign className="w-6 h-6" />,
      title: "One-Time Investment",
      description: "No monthly cloud subscriptions"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Staff Empowered",
      description: "40% more time with patients"
    },
    {
      icon: <Check className="w-6 h-6" />,
      title: "Patient Sovereign",
      description: "Complete control over their data"
    },
    {
      icon: <Server className="w-6 h-6" />,
      title: "Complete Ecosystem",
      description: "Training platform, docs, legal compliance"
    }
  ];

  return (
    <div className="slide-container bg-white flex items-center">
      <div className="w-full max-w-7xl mx-auto px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-[var(--deep-navy)] mb-4">
            Sovereign AI That Serves Your Mission
          </h2>
          <div className="w-24 h-1 bg-[var(--empire-gold)] mx-auto"></div>
        </div>

        <div className="grid grid-cols-2 gap-16 items-center">
          {/* Left side - Benefits */}
          <div className="space-y-6">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-green-50 border-l-4 border-[var(--sovereign-green)]">
                <div className="flex-shrink-0 w-10 h-10 bg-[var(--sovereign-green)] rounded-full flex items-center justify-center text-white">
                  <Check className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-[var(--sovereign-green)]">
                    {benefit.icon}
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-[var(--deep-navy)]">
                      {benefit.title}
                    </h4>
                    <p className="text-[var(--neutral-gray)]">
                      {benefit.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Right side - System visualization */}
          <div className="relative">
            <div className="p-8 bg-gradient-to-br from-[var(--sovereign-green)] to-[var(--success-teal)] rounded-2xl shadow-2xl">
              <h3 className="text-2xl font-bold text-white mb-6 text-center">
                AURA-BREE System
              </h3>
              
              {/* System components */}
              <div className="space-y-4">
                <div className="flex items-center gap-3 bg-white/20 backdrop-blur-sm rounded-lg p-3">
                  <Server className="w-6 h-6 text-white" />
                  <div>
                    <h4 className="text-white font-semibold text-sm">Sovereign Server</h4>
                    <p className="text-white/80 text-xs">Local data processing</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 bg-white/20 backdrop-blur-sm rounded-lg p-3">
                  <Monitor className="w-6 h-6 text-white" />
                  <div>
                    <h4 className="text-white font-semibold text-sm">Staff Dashboard</h4>
                    <p className="text-white/80 text-xs">Real-time patient insights</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-3 bg-white/20 backdrop-blur-sm rounded-lg p-3">
                  <Smartphone className="w-6 h-6 text-white" />
                  <div>
                    <h4 className="text-white font-semibold text-sm">Patient Apps</h4>
                    <p className="text-white/80 text-xs">Sovereign data control</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-white/20 backdrop-blur-sm rounded-lg p-3">
                  <GraduationCap className="w-6 h-6 text-white" />
                  <div>
                    <h4 className="text-white font-semibold text-sm">AI Training Platform</h4>
                    <p className="text-white/80 text-xs">Staff onboarding & support</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-white/20 backdrop-blur-sm rounded-lg p-3">
                  <FileText className="w-6 h-6 text-white" />
                  <div>
                    <h4 className="text-white font-semibold text-sm">Documentation Suite</h4>
                    <p className="text-white/80 text-xs">Clinical & legal compliance</p>
                  </div>
                </div>
              </div>

              {/* Data boundary emphasis */}
              <div className="mt-6 p-4 bg-[var(--empire-gold)] rounded-lg">
                <p className="text-[var(--deep-navy)] font-semibold text-center">
                  🔒 All data stays within your clinic boundary
                </p>
              </div>
            </div>

            {/* Golden glow effect */}
            <div className="absolute -inset-4 bg-gradient-to-r from-[var(--empire-gold)] to-[var(--warning-amber)] rounded-2xl opacity-20 blur-xl"></div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DollarSign({ className }: { className: string }) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
    </svg>
  );
}