import { Target, RotateCcw, DollarSign, TrendingUp, Clock, Shield } from 'lucide-react';

export function InvestmentSlide() {
  return (
    <div className="slide-container bg-white flex items-center">
      <div className="w-full max-w-7xl mx-auto px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-[var(--deep-navy)] mb-4">
            Your Path to Sovereignty
          </h2>
          <div className="w-24 h-1 bg-[var(--empire-gold)] mx-auto"></div>
        </div>

        <div className="grid grid-cols-2 gap-16">
          {/* Left Column - Investment */}
          <div className="space-y-8">
            <h3 className="text-2xl font-semibold text-[var(--deep-navy)] mb-6">
              Investment Required
            </h3>

            {/* One-time setup */}
            <div className="bg-blue-50 rounded-lg p-6 border-l-4 border-[var(--deep-navy)]">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[var(--deep-navy)] rounded-full flex items-center justify-center">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="text-xl font-semibold text-[var(--deep-navy)] mb-2">
                    One-Time Setup: <span className="text-3xl text-[var(--empire-gold)]">$50,000 CAD</span>
                  </h4>
                  <ul className="space-y-2 text-[var(--neutral-gray)]">
                    <li>• Sovereign server + dashboard workstation</li>
                    <li>• Complete system configuration</li>
                    <li>• Staff training & patient onboarding</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Ongoing support */}
            <div className="bg-green-50 rounded-lg p-6 border-l-4 border-[var(--sovereign-green)]">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[var(--sovereign-green)] rounded-full flex items-center justify-center">
                  <RotateCcw className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="text-xl font-semibold text-[var(--deep-navy)] mb-2">
                    Ongoing Support: <span className="text-3xl text-[var(--empire-gold)]">$2,500/month</span>
                  </h4>
                  <ul className="space-y-2 text-[var(--neutral-gray)]">
                    <li>• 24/7 AI customer service</li>
                    <li>• Monthly on-site audits & upgrades</li>
                    <li>• Security patches & system evolution</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Returns */}
          <div className="space-y-8">
            <h3 className="text-2xl font-semibold text-[var(--deep-navy)] mb-6">
              Your Returns
            </h3>

            {/* Immediate savings */}
            <div className="bg-yellow-50 rounded-lg p-6 border-l-4 border-[var(--empire-gold)]">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[var(--empire-gold)] rounded-full flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-[var(--deep-navy)]" />
                </div>
                <div className="flex-1">
                  <h4 className="text-xl font-semibold text-[var(--deep-navy)] mb-4">
                    Immediate Savings
                  </h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span>No cloud subscriptions:</span>
                      <span className="text-lg font-semibold text-[var(--sovereign-green)]">$60,000/year saved</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Reduced IT support:</span>
                      <span className="text-lg font-semibold text-[var(--sovereign-green)]">$24,000/year saved</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Compliance automation:</span>
                      <span className="text-lg font-semibold text-[var(--sovereign-green)]">$12,000/year saved</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Operational gains */}
            <div className="bg-teal-50 rounded-lg p-6 border-l-4 border-[var(--success-teal)]">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-[var(--success-teal)] rounded-full flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h4 className="text-xl font-semibold text-[var(--deep-navy)] mb-4">
                    Operational Gains
                  </h4>
                  <div className="space-y-3">
                    <div className="flex items-center gap-3">
                      <Clock className="w-5 h-5 text-[var(--success-teal)]" />
                      <span>40% more patient face-time</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Shield className="w-5 h-5 text-[var(--success-teal)]" />
                      <span>Zero downtime from internet issues</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Target className="w-5 h-5 text-[var(--success-teal)]" />
                      <span>Complete regulatory compliance</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* ROI Summary */}
            <div className="bg-gradient-to-r from-[var(--empire-gold)] to-[var(--warning-amber)] rounded-lg p-6 text-center">
              <h4 className="text-xl font-bold text-[var(--deep-navy)] mb-2">
                Total Annual Savings
              </h4>
              <p className="text-4xl font-bold text-[var(--deep-navy)]">
                $96,000+
              </p>
              <p className="text-[var(--deep-navy)] mt-2">
                System pays for itself in 7 months
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DollarSign({ className }: { className: string }) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1" />
    </svg>
  );
}