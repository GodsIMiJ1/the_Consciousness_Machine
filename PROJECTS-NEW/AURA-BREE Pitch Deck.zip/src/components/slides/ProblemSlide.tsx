import { X, DollarSign, Wifi, Shield, Clock, AlertTriangle } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export function ProblemSlide() {
  const painPoints = [
    {
      icon: <Shield className="w-6 h-6" />,
      text: "Patient data flows to Amazon & Microsoft servers"
    },
    {
      icon: <Wifi className="w-6 h-6" />,
      text: "Internet outages shut down your entire operation"
    },
    {
      icon: <DollarSign className="w-6 h-6" />,
      text: "Monthly cloud fees: $2,500-5,000 bleeding your budget"
    },
    {
      icon: <Clock className="w-6 h-6" />,
      text: "Staff fight systems instead of helping patients"
    },
    {
      icon: <AlertTriangle className="w-6 h-6" />,
      text: "Compliance violations create legal nightmares"
    },
    {
      icon: <X className="w-6 h-6" />,
      text: "Zero patient control over their own medical data"
    }
  ];

  return (
    <div className="slide-container bg-white flex items-center">
      <div className="w-full max-w-7xl mx-auto px-8 py-12">
        <div className="grid grid-cols-5 gap-12 h-full">
          {/* Left side - Problem points */}
          <div className="col-span-3">
            <h2 className="text-4xl font-bold text-[var(--deep-navy)] mb-12">
              Healthcare Technology That Fails Your Mission
            </h2>
            
            <div className="space-y-6">
              {painPoints.map((point, index) => (
                <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-red-50 border-l-4 border-[var(--alert-red)]">
                  <div className="flex-shrink-0 w-10 h-10 bg-[var(--alert-red)] rounded-full flex items-center justify-center text-white">
                    <X className="w-5 h-5" />
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="text-[var(--alert-red)]">
                      {point.icon}
                    </div>
                    <p className="text-lg text-[var(--deep-navy)] font-medium">
                      {point.text}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right side - Impact visual */}
          <div className="col-span-2 flex flex-col justify-center">
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1585559604959-6388fe69c92a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcnVzdHJhdGVkJTIwaGVhbHRoY2FyZSUyMHdvcmtlciUyMGNvbXB1dGVyfGVufDF8fHx8MTc1NjY5NTU5OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Frustrated healthcare worker"
                className="w-full h-64 object-cover rounded-lg shadow-lg"
              />
              
              {/* Data flow visualization */}
              <div className="mt-8 p-6 bg-gray-100 rounded-lg">
                <h4 className="text-lg font-semibold text-[var(--deep-navy)] mb-4">Current Reality:</h4>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-[var(--neutral-gray)]">Your clinic data</span>
                    <div className="flex-1 mx-4 border-t-2 border-dashed border-[var(--alert-red)]"></div>
                    <span className="text-sm text-[var(--alert-red)]">Amazon AWS</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-[var(--neutral-gray)]">Patient records</span>
                    <div className="flex-1 mx-4 border-t-2 border-dashed border-[var(--alert-red)]"></div>
                    <span className="text-sm text-[var(--alert-red)]">Microsoft Azure</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-[var(--neutral-gray)]">Monthly costs</span>
                    <div className="flex-1 mx-4 border-t-2 border-dashed border-[var(--alert-red)]"></div>
                    <span className="text-sm text-[var(--alert-red)]">$2,500-5,000</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}