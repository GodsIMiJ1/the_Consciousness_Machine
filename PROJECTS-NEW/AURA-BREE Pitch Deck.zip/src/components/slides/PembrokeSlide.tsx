import { Globe, Award, Newspaper, Target, Users, Zap } from 'lucide-react';
import { ImageWithFallback } from '../figma/ImageWithFallback';

export function PembrokeSlide() {
  const advantages = [
    {
      icon: <Globe className="w-6 h-6" />,
      title: "Global Pioneer Status",
      description: "First clinic in the world with sovereign AI"
    },
    {
      icon: <Newspaper className="w-6 h-6" />,
      title: "Media Attention & Recognition",
      description: "Healthcare technology leadership coverage"
    },
    {
      icon: <Award className="w-6 h-6" />,
      title: "Industry Leadership Position",
      description: "Set the standard for others to follow"
    },
    {
      icon: <Target className="w-6 h-6" />,
      title: "System Tailored to Methadone Treatment",
      description: "Specialized for your patient population"
    },
    {
      icon: <Users className="w-6 h-6" />,
      title: "Direct Input on Feature Development",
      description: "Shape the future of healthcare AI"
    },
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Competitive Advantage in Your Market",
      description: "Technology others can't access"
    }
  ];

  return (
    <div className="slide-container bg-gradient-to-br from-white to-gray-50 flex items-center">
      <div className="w-full max-w-7xl mx-auto px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-[var(--deep-navy)] mb-4">
            Pembroke: The World's First
          </h2>
          <div className="w-24 h-1 bg-[var(--empire-gold)] mx-auto"></div>
        </div>

        <div className="grid grid-cols-3 gap-12 items-center">
          {/* Left - World Map */}
          <div className="relative">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1742415105376-43d3a5fd03fc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b3JsZCUyMG1hcCUyMGdsb2JhbCUyMHBpb25lZXJ8ZW58MXx8fHwxNzU2Njk1NzA2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="World map"
              className="w-full h-64 object-cover rounded-lg opacity-20"
            />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center">
                <div className="text-8xl font-bold text-[var(--empire-gold)] mb-4">
                  1st
                </div>
                <h3 className="text-xl font-semibold text-[var(--deep-navy)]">
                  Pembroke Methadone Clinic
                </h3>
                <p className="text-[var(--neutral-gray)]">
                  Global Healthcare Pioneer
                </p>
                <div className="mt-4 w-16 h-1 bg-[var(--empire-gold)] mx-auto"></div>
              </div>
            </div>
          </div>

          {/* Center - Benefits Grid */}
          <div className="space-y-4">
            {advantages.map((advantage, index) => (
              <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-white/80 border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
                <div className="w-10 h-10 bg-[var(--empire-gold)] rounded-full flex items-center justify-center text-[var(--deep-navy)] flex-shrink-0">
                  {advantage.icon}
                </div>
                <div>
                  <h4 className="font-semibold text-[var(--deep-navy)] text-sm">
                    {advantage.title}
                  </h4>
                  <p className="text-xs text-[var(--neutral-gray)] mt-1">
                    {advantage.description}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Right - Testimonial and Vision */}
          <div className="space-y-6">
            {/* Vision Statement */}
            <div className="bg-gradient-to-br from-[var(--sovereign-green)] to-[var(--success-teal)] rounded-lg p-6 text-white">
              <h3 className="text-xl font-bold mb-4">
                Sovereign AI Wellness System
              </h3>
              <p className="text-white/90 leading-relaxed">
                Pembroke will demonstrate that healthcare technology can serve patients and providers without sacrificing privacy or autonomy to big tech companies.
              </p>
            </div>

            {/* Patient Testimonial */}
            <div className="bg-white rounded-lg p-6 border-l-4 border-[var(--empire-gold)] shadow-lg">
              <div className="text-4xl text-[var(--empire-gold)] mb-3">"</div>
              <p className="text-[var(--deep-navy)] font-medium italic mb-4">
                This system addresses gaps I faced in my own treatment journey
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[var(--empire-gold)] rounded-full flex items-center justify-center">
                  <span className="text-[var(--deep-navy)] font-bold">B</span>
                </div>
                <div>
                  <p className="font-semibold text-[var(--deep-navy)]">Bree</p>
                  <p className="text-sm text-[var(--neutral-gray)]">Patient Advocate</p>
                </div>
              </div>
            </div>

            {/* Pioneer Badge */}
            <div className="text-center p-4 bg-[var(--empire-gold)] rounded-lg">
              <Award className="w-8 h-8 text-[var(--deep-navy)] mx-auto mb-2" />
              <p className="text-[var(--deep-navy)] font-bold">
                First in the World
              </p>
              <p className="text-[var(--deep-navy)] text-sm">
                Healthcare Sovereignty Leader
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}