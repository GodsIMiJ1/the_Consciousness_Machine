import { Server, Monitor, Smartphone, Shield, Lock, HardDrive, Cpu, MemoryStick } from 'lucide-react';

export function ArchitectureSlide() {
  return (
    <div className="slide-container bg-white flex items-center">
      <div className="w-full max-w-7xl mx-auto px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-[var(--deep-navy)] mb-4">
            Sovereign by Design
          </h2>
          <div className="w-24 h-1 bg-[var(--empire-gold)] mx-auto"></div>
        </div>

        <div className="grid grid-cols-3 gap-12">
          {/* Left - System Diagram */}
          <div className="col-span-2">
            <div className="relative bg-gradient-to-br from-gray-50 to-gray-100 rounded-2xl p-8 h-full">
              {/* Clinic Boundary */}
              <div className="border-4 border-[var(--sovereign-green)] border-dashed rounded-xl p-6 relative">
                <div className="absolute -top-4 left-4 bg-white px-4 py-1 rounded">
                  <span className="text-[var(--sovereign-green)] font-bold">Your Clinic Boundary</span>
                </div>

                {/* Server */}
                <div className="text-center mb-8">
                  <div className="w-20 h-20 bg-[var(--deep-navy)] rounded-lg mx-auto flex items-center justify-center mb-3">
                    <Server className="w-10 h-10 text-white" />
                  </div>
                  <h4 className="font-semibold text-[var(--deep-navy)]">Sovereign Server</h4>
                  <p className="text-sm text-[var(--neutral-gray)]">Local AI Processing</p>
                </div>

                {/* Connection lines */}
                <div className="relative">
                  {/* Horizontal line to dashboard */}
                  <div className="absolute top-1/2 left-1/2 w-32 h-0.5 bg-[var(--sovereign-green)] transform -translate-y-1/2"></div>
                  
                  {/* Dashboard */}
                  <div className="absolute top-1/2 right-0 transform -translate-y-1/2">
                    <div className="w-16 h-16 bg-[var(--empire-gold)] rounded-lg flex items-center justify-center mb-2">
                      <Monitor className="w-8 h-8 text-[var(--deep-navy)]" />
                    </div>
                    <div className="text-center">
                      <h4 className="font-semibold text-[var(--deep-navy)] text-sm">Staff Dashboard</h4>
                    </div>
                  </div>
                </div>

                {/* Patient phones */}
                <div className="mt-12 flex justify-around">
                  {[1, 2, 3].map((i) => (
                    <div key={i} className="text-center">
                      <div className="w-12 h-12 bg-[var(--success-teal)] rounded-lg flex items-center justify-center mb-2 mx-auto">
                        <Smartphone className="w-6 h-6 text-white" />
                      </div>
                      <p className="text-xs text-[var(--neutral-gray)]">Patient {i}</p>
                      {/* Connection line */}
                      <div className="w-0.5 h-8 bg-[var(--sovereign-green)] mx-auto mt-2"></div>
                    </div>
                  ))}
                </div>

                {/* Encryption indicators */}
                <div className="absolute top-4 right-4 flex space-x-2">
                  <div className="w-8 h-8 bg-[var(--empire-gold)] rounded-full flex items-center justify-center">
                    <Lock className="w-4 h-4 text-[var(--deep-navy)]" />
                  </div>
                  <div className="w-8 h-8 bg-[var(--empire-gold)] rounded-full flex items-center justify-center">
                    <Shield className="w-4 h-4 text-[var(--deep-navy)]" />
                  </div>
                </div>
              </div>

              {/* External blocking */}
              <div className="mt-6 flex justify-center space-x-8">
                {['Amazon AWS', 'Microsoft Azure', 'Google Cloud'].map((cloud) => (
                  <div key={cloud} className="text-center opacity-50">
                    <div className="w-16 h-16 bg-gray-300 rounded-lg flex items-center justify-center mb-2 relative">
                      <Server className="w-8 h-8 text-gray-500" />
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-12 h-12 border-4 border-red-500 rounded-full flex items-center justify-center bg-white">
                          <span className="text-red-500 font-bold text-xl">✕</span>
                        </div>
                      </div>
                    </div>
                    <p className="text-xs text-gray-500">{cloud}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right - Technical Specs */}
          <div className="space-y-6">
            {/* Hardware Specs */}
            <div className="bg-blue-50 rounded-lg p-6 border-l-4 border-[var(--deep-navy)]">
              <h3 className="text-lg font-semibold text-[var(--deep-navy)] mb-4 flex items-center gap-2">
                <HardDrive className="w-5 h-5" />
                Hardware Included
              </h3>
              <div className="space-y-3 text-sm">
                <div>
                  <h4 className="font-medium text-[var(--deep-navy)]">Sovereign Server:</h4>
                  <ul className="text-[var(--neutral-gray)] ml-4 space-y-1">
                    <li>• Intel i7 processor</li>
                    <li>• 32GB RAM</li>
                    <li>• 1TB encrypted SSD</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-[var(--deep-navy)]">Dashboard Workstation:</h4>
                  <ul className="text-[var(--neutral-gray)] ml-4 space-y-1">
                    <li>• Intel i5+ processor</li>
                    <li>• 16GB RAM</li>
                    <li>• 24" monitor</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-[var(--deep-navy)]">Additional:</h4>
                  <ul className="text-[var(--neutral-gray)] ml-4 space-y-1">
                    <li>• Encrypted backup drive</li>
                    <li>• Full setup & configuration</li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Security Features */}
            <div className="bg-green-50 rounded-lg p-6 border-l-4 border-[var(--sovereign-green)]">
              <h3 className="text-lg font-semibold text-[var(--deep-navy)] mb-4 flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Security Features
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[var(--sovereign-green)]" />
                  <span>AES-256 encryption at rest</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-[var(--sovereign-green)]" />
                  <span>TLS 1.3 encrypted transmission</span>
                </div>
                <div className="flex items-center gap-2">
                  <Lock className="w-4 h-4 text-[var(--sovereign-green)]" />
                  <span>Role-based access control</span>
                </div>
                <div className="flex items-center gap-2">
                  <Shield className="w-4 h-4 text-[var(--sovereign-green)]" />
                  <span>Immutable audit trails</span>
                </div>
              </div>
            </div>

            {/* Ecosystem Integration */}
            <div className="bg-yellow-50 rounded-lg p-6 border-l-4 border-[var(--empire-gold)]">
              <h3 className="text-lg font-semibold text-[var(--deep-navy)] mb-3 flex items-center gap-2">
                <Cpu className="w-5 h-5" />
                Complete Ecosystem
              </h3>
              <div className="space-y-2 text-sm text-[var(--neutral-gray)]">
                <div>• AI Training Platform for staff onboarding</div>
                <div>• Clinical documentation system</div>
                <div>• Legal compliance hub</div>
                <div>• Patient mobile application</div>
                <div>• Staff dashboard interface</div>
              </div>
              <div className="mt-3 p-3 bg-[var(--empire-gold)] rounded-lg">
                <p className="text-[var(--deep-navy)] font-semibold text-sm text-center">
                  100% Offline Operation
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}