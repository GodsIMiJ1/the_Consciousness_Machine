import { Calendar, Zap, Target, Lock, Mail, Phone, Globe, ArrowRight } from 'lucide-react';
import { Button } from '../ui/button';

export function NextStepsSlide() {
  const timeline = [
    {
      week: "Week 1",
      title: "Site Assessment & Final Planning",
      description: "Comprehensive clinic evaluation and system customization",
      icon: <Target className="w-6 h-6" />
    },
    {
      week: "Week 2",
      title: "Hardware Delivery & Installation",
      description: "Sovereign server setup and infrastructure deployment",
      icon: <Zap className="w-6 h-6" />
    },
    {
      week: "Week 3",
      title: "System Configuration & Staff Training",
      description: "Custom configuration and comprehensive team onboarding",
      icon: <Calendar className="w-6 h-6" />
    },
    {
      week: "Week 4",
      title: "Patient Onboarding & Go-Live",
      description: "Patient app deployment and full system activation",
      icon: <Lock className="w-6 h-6" />
    }
  ];

  const urgencyPoints = [
    {
      icon: <Zap className="w-5 h-5" />,
      text: "Only accepting 3 pilot sites globally"
    },
    {
      icon: <Target className="w-5 h-5" />,
      text: "Pembroke is our top choice"
    },
    {
      icon: <Calendar className="w-5 h-5" />,
      text: "Installation can begin within 2 weeks"
    },
    {
      icon: <Lock className="w-5 h-5" />,
      text: "Secure your position as the world's first"
    }
  ];

  return (
    <div className="slide-container bg-gradient-to-br from-white to-gray-50 flex items-center">
      <div className="w-full max-w-7xl mx-auto px-8 py-12">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-[var(--deep-navy)] mb-4">
            Become the World's First
          </h2>
          <div className="w-24 h-1 bg-[var(--empire-gold)] mx-auto"></div>
        </div>

        <div className="grid grid-cols-3 gap-12">
          {/* Left - Timeline */}
          <div className="col-span-2">
            <h3 className="text-2xl font-semibold text-[var(--deep-navy)] mb-8">
              Implementation Timeline
            </h3>
            
            <div className="space-y-6">
              {timeline.map((step, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="flex flex-col items-center">
                    <div className="w-12 h-12 bg-[var(--empire-gold)] rounded-full flex items-center justify-center text-[var(--deep-navy)]">
                      {step.icon}
                    </div>
                    {index < timeline.length - 1 && (
                      <div className="w-0.5 h-16 bg-[var(--empire-gold)] mt-4"></div>
                    )}
                  </div>
                  
                  <div className="flex-1 pb-8">
                    <div className="flex items-center gap-4 mb-2">
                      <span className="bg-[var(--deep-navy)] text-white px-3 py-1 rounded-full text-sm font-semibold">
                        {step.week}
                      </span>
                      <h4 className="text-lg font-semibold text-[var(--deep-navy)]">
                        {step.title}
                      </h4>
                    </div>
                    <p className="text-[var(--neutral-gray)]">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            {/* Urgency Section */}
            <div className="mt-12 p-6 bg-red-50 rounded-lg border-l-4 border-[var(--alert-red)]">
              <h4 className="text-lg font-semibold text-[var(--deep-navy)] mb-4">
                Limited Opportunity
              </h4>
              <div className="grid grid-cols-2 gap-4">
                {urgencyPoints.map((point, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="text-[var(--alert-red)]">
                      {point.icon}
                    </div>
                    <span className="text-[var(--deep-navy)] font-medium text-sm">
                      {point.text}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right - Contact & CTA */}
          <div className="space-y-8">
            {/* Contact Information */}
            <div className="bg-white rounded-lg p-6 shadow-lg border border-gray-200">
              <h3 className="text-xl font-semibold text-[var(--deep-navy)] mb-6 text-center">
                Contact Information
              </h3>
              
              <div className="space-y-4">
                <div className="text-center mb-4">
                  <h4 className="font-semibold text-[var(--deep-navy)]">James Ingersoll</h4>
                  <p className="text-[var(--neutral-gray)]">Founder & CEO, GodsIMiJ Empire</p>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <Mail className="w-5 h-5 text-[var(--empire-gold)]" />
                    <span className="text-[var(--deep-navy)] text-sm">james@godsimij-ai-solutions.com</span>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <Phone className="w-5 h-5 text-[var(--empire-gold)]" />
                    <span className="text-[var(--deep-navy)]">1(613)318-9711</span>
                  </div>
                  
                  <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                    <Globe className="w-5 h-5 text-[var(--empire-gold)]" />
                    <span className="text-[var(--deep-navy)] text-xs">aura-bree-landingpage.quantum-odyssey.com</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Main CTA */}
            <div className="bg-gradient-to-br from-[var(--empire-gold)] to-[var(--warning-amber)] rounded-lg p-8 text-center">
              <h3 className="text-2xl font-bold text-[var(--deep-navy)] mb-4">
                Ready to Make Healthcare History?
              </h3>
              
              <Button 
                className="w-full bg-[var(--deep-navy)] hover:bg-[var(--deep-navy)]/90 text-white font-bold text-lg py-6 mb-4"
              >
                Schedule Demo
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
              
              <p className="text-[var(--deep-navy)] text-sm">
                Secure your position as the world's first sovereign AI wellness clinic
              </p>
            </div>

            {/* Ecosystem Access */}
            <div className="bg-gradient-to-br from-[var(--sovereign-green)] to-[var(--success-teal)] rounded-lg p-6 text-white">
              <h4 className="font-bold mb-4 text-center">Complete Ecosystem Access</h4>
              <div className="space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <span>Client App:</span>
                  <a href="https://aura-bree.quantum-odyssey.com/" className="text-[var(--empire-gold)] hover:underline">
                    Live Demo →
                  </a>
                </div>
                <div className="flex items-center justify-between">
                  <span>Clinic Dashboard:</span>
                  <a href="https://methaclinic.quantum-odyssey.com/" className="text-[var(--empire-gold)] hover:underline">
                    Live Demo →
                  </a>
                </div>
                <div className="flex items-center justify-between">
                  <span>Clinical Docs:</span>
                  <a href="https://clinical-canon.quantum-odyssey.com/" className="text-[var(--empire-gold)] hover:underline">
                    Live Demo →
                  </a>
                </div>
                <div className="flex items-center justify-between">
                  <span>Legal Hub:</span>
                  <a href="https://aura-bree-legal-hub.quantum-odyssey.com/" className="text-[var(--empire-gold)] hover:underline">
                    Live Demo →
                  </a>
                </div>
              </div>
            </div>

            {/* Pioneer Badge */}
            <div className="bg-[var(--deep-navy)] rounded-lg p-6 text-center">
              <div className="w-16 h-16 bg-[var(--empire-gold)] rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-[var(--deep-navy)] text-2xl font-bold">1st</span>
              </div>
              <h4 className="text-white font-bold mb-2">Global Pioneer</h4>
              <p className="text-white/80 text-sm">
                Be the first clinic to achieve true healthcare sovereignty
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}