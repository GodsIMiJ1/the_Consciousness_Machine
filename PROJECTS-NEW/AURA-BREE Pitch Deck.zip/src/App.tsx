import { useState, useEffect } from 'react';
import { PresentationNav } from './components/PresentationNav';
import { TitleSlide } from './components/slides/TitleSlide';
import { ProblemSlide } from './components/slides/ProblemSlide';
import { SolutionSlide } from './components/slides/SolutionSlide';
import { InvestmentSlide } from './components/slides/InvestmentSlide';
import { ArchitectureSlide } from './components/slides/ArchitectureSlide';
import { PembrokeSlide } from './components/slides/PembrokeSlide';
import { TeamSlide } from './components/slides/TeamSlide';
import { NextStepsSlide } from './components/slides/NextStepsSlide';

export default function App() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const totalSlides = 8;

  const slides = [
    <TitleSlide />,
    <ProblemSlide />,
    <SolutionSlide />,
    <InvestmentSlide />,
    <ArchitectureSlide />,
    <PembrokeSlide />,
    <TeamSlide />,
    <NextStepsSlide />
  ];

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      if (event.key === 'ArrowRight' || event.key === ' ') {
        setCurrentSlide(prev => Math.min(totalSlides - 1, prev + 1));
      } else if (event.key === 'ArrowLeft') {
        setCurrentSlide(prev => Math.max(0, prev - 1));
      } else if (event.key >= '1' && event.key <= '8') {
        setCurrentSlide(parseInt(event.key) - 1);
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [totalSlides]);

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      {/* Presentation Container */}
      <div className="w-full max-w-[1920px] bg-white rounded-lg shadow-2xl overflow-hidden">
        {/* Current Slide */}
        <div className="relative">
          {slides[currentSlide]}
        </div>
      </div>

      {/* Navigation */}
      <PresentationNav
        currentSlide={currentSlide}
        totalSlides={totalSlides}
        onSlideChange={setCurrentSlide}
      />

      {/* Presentation Info */}
      <div className="fixed top-4 right-4 bg-white/90 backdrop-blur-sm rounded-lg px-4 py-2 shadow-lg">
        <p className="text-xs text-[var(--neutral-gray)]">
          Use arrow keys or space to navigate
        </p>
        <p className="text-xs text-[var(--neutral-gray)]">
          Press 1-8 for direct slide access
        </p>
      </div>
    </div>
  );
}