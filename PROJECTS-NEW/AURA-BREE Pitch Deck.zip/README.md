
  # AURA-BREE Pitch Deck

  This is a code bundle for AURA-BREE Pitch Deck. The original project is available at https://www.figma.com/design/qtvL4OaWvf3OoXfFmyKqEw/AURA-BREE-Pitch-Deck.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  