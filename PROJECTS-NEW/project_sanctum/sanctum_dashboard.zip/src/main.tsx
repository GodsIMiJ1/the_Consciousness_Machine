import React from 'react'
import ReactDOM from 'react-dom/client'
import ProjectSanctumDashboard from './sanctum'
ReactDOM.createRoot(document.getElementById('root')!).render(<React.StrictMode><ProjectSanctumDashboard /></React.StrictMode>)
