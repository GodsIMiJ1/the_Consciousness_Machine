# Project Sanctum Dashboard

`npm install && npm run dev`
Requires Sanctum API at :8787.
