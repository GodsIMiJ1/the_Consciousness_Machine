# Project Sanctum CLI

See quickstart in chat.
