import { PitchDeck } from './components/PitchDeck';

export default function App() {
  return <PitchDeck />;
}