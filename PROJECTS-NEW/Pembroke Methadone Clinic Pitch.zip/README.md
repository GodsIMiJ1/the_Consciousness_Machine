
  # Pembroke Methadone Clinic Pitch

  This is a code bundle for Pembroke Methadone Clinic Pitch. The original project is available at https://www.figma.com/design/DR2o3FMrBGInEgTQtjAdhr/Pembroke-Methadone-Clinic-Pitch.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  