import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowLeft, Clock, CheckCircle, XCircle, RotateCcw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Question {
  id: string;
  prompt: string;
  choices: string[];
  correct: number[];
  explanation?: string;
}

interface Quiz {
  id: string;
  title: string;
  pass_score: number;
  questions: Question[];
}

interface QuizAttempt {
  id: string;
  score: number;
  passed: boolean;
  details: any;
  created_at: string;
}

export default function QuizPage() {
  const { id } = useParams<{ id: string }>();
  const { profile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState<Quiz | null>(null);
  const [answers, setAnswers] = useState<Record<string, number[]>>({});
  const [result, setResult] = useState<{ score: number; passed: boolean; details: any } | null>(null);
  const [attempts, setAttempts] = useState<QuizAttempt[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (id) {
      loadQuiz();
      if (profile) {
        loadAttempts();
      }
    }
  }, [id, profile]);

  const loadQuiz = async () => {
    try {
      const { data: quizData } = await supabase
        .from('training_quizzes')
        .select('*')
        .eq('id', id)
        .single();

      if (quizData) {
        setQuiz({
          ...quizData,
          questions: (quizData.questions as unknown) as Question[]
        });
      }
    } catch (error) {
      console.error('Error loading quiz:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadAttempts = async () => {
    if (!profile) return;

    try {
      const { data: attemptsData } = await supabase
        .from('training_quiz_attempts')
        .select('*')
        .eq('user_id', profile.id)
        .eq('quiz_id', id)
        .order('created_at', { ascending: false });

      setAttempts(attemptsData || []);
    } catch (error) {
      console.error('Error loading attempts:', error);
    }
  };

  const toggleAnswer = (questionId: string, choiceIndex: number) => {
    setAnswers(prev => {
      const currentAnswers = prev[questionId] || [];
      const answerSet = new Set(currentAnswers);
      
      if (answerSet.has(choiceIndex)) {
        answerSet.delete(choiceIndex);
      } else {
        answerSet.add(choiceIndex);
      }
      
      return {
        ...prev,
        [questionId]: Array.from(answerSet).sort()
      };
    });
  };

  const submitQuiz = async () => {
    if (!quiz || !profile) return;

    setSubmitting(true);
    
    try {
      const questions: Question[] = quiz.questions;
      let correctCount = 0;
      
      const details = questions.map(question => {
        const userAnswers = (answers[question.id] || []).slice().sort();
        const correctAnswers = question.correct.slice().sort();
        const isCorrect = JSON.stringify(userAnswers) === JSON.stringify(correctAnswers);
        
        if (isCorrect) {
          correctCount++;
        }
        
        return {
          questionId: question.id,
          correct: isCorrect,
          userAnswers,
          correctAnswers,
          explanation: question.explanation
        };
      });

      const score = Math.round((correctCount / questions.length) * 100);
      const passed = score >= quiz.pass_score;

      // Save attempt to database
      const { error } = await supabase.from('training_quiz_attempts').insert({
        user_id: profile.id,
        quiz_id: quiz.id,
        score,
        passed,
        details,
        ip_hash: '' // Could implement IP tracking if needed
      });

      if (error) {
        throw error;
      }

      // If quiz is linked to a lesson and user passed, mark lesson as completed
      if (passed) {
        const { data: lessonData } = await supabase
          .from('training_lessons')
          .select('id')
          .eq('quiz_id', quiz.id)
          .maybeSingle();

        if (lessonData) {
          await supabase.from('training_lesson_progress').upsert({
            user_id: profile.id,
            lesson_id: lessonData.id,
            completed: true,
            completed_at: new Date().toISOString()
          });
        }
      }

      setResult({ score, passed, details });
      loadAttempts(); // Reload attempts to show the new one

      toast({
        title: passed ? "Quiz Passed!" : "Quiz Failed",
        description: `You scored ${score}%. ${passed ? 'Great work!' : `You need ${quiz.pass_score}% to pass.`}`,
        variant: passed ? "default" : "destructive",
      });

    } catch (error) {
      console.error('Error submitting quiz:', error);
      toast({
        title: "Error",
        description: "Failed to submit quiz. Please try again.",
        variant: "destructive",
      });
    } finally {
      setSubmitting(false);
    }
  };

  const resetQuiz = () => {
    setAnswers({});
    setResult(null);
  };

  const hasAttempted = attempts.length > 0;
  const hasPassed = attempts.some(attempt => attempt.passed);
  const canRetake = !hasPassed || result?.passed === false;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-semibold mb-2">Quiz Not Found</h1>
          <p className="text-muted-foreground mb-4">
            The quiz you're looking for doesn't exist.
          </p>
          <Button asChild>
            <Link to="/dashboard">Back to Dashboard</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <div className="flex items-center space-x-2">
                <Clock className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold">{quiz.title}</h1>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline">Pass: {quiz.pass_score}%</Badge>
              {hasPassed && (
                <Badge className="bg-green-500">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Passed
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Previous Attempts */}
        {hasAttempted && (
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="text-lg">Previous Attempts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {attempts.slice(0, 3).map((attempt, index) => (
                  <div key={attempt.id} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex items-center space-x-3">
                      {attempt.passed ? (
                        <CheckCircle className="h-5 w-5 text-green-500" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-500" />
                      )}
                      <div>
                        <p className="font-medium">Attempt {attempts.length - index}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(attempt.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-lg">{attempt.score}%</p>
                      <p className={`text-sm ${attempt.passed ? 'text-green-600' : 'text-red-600'}`}>
                        {attempt.passed ? 'Passed' : 'Failed'}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quiz Questions */}
        {!result ? (
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Quiz Instructions</CardTitle>
                <CardDescription>
                  Answer all questions below. You need {quiz.pass_score}% to pass.
                  {hasPassed && " You have already passed this quiz, but you can retake it if you'd like."}
                </CardDescription>
              </CardHeader>
            </Card>

            {quiz.questions.map((question, questionIndex) => (
              <Card key={question.id}>
                <CardHeader>
                  <CardTitle className="text-lg">
                    Question {questionIndex + 1}
                  </CardTitle>
                  <CardDescription className="text-base text-foreground">
                    {question.prompt}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {question.choices.map((choice, choiceIndex) => (
                      <div key={choiceIndex} className="flex items-center space-x-3">
                        <Checkbox
                          id={`${question.id}-${choiceIndex}`}
                          checked={(answers[question.id] || []).includes(choiceIndex)}
                          onCheckedChange={() => toggleAnswer(question.id, choiceIndex)}
                        />
                        <label 
                          htmlFor={`${question.id}-${choiceIndex}`}
                          className="text-sm cursor-pointer flex-1"
                        >
                          {choice}
                        </label>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}

            <div className="flex items-center justify-between pt-4">
              <Button 
                variant="outline"
                onClick={resetQuiz}
                disabled={submitting}
                className="flex items-center space-x-2"
              >
                <RotateCcw className="h-4 w-4" />
                <span>Reset Answers</span>
              </Button>
              
              <Button
                onClick={submitQuiz}
                disabled={submitting || Object.keys(answers).length === 0}
                className="flex items-center space-x-2"
              >
                <Clock className="h-4 w-4" />
                <span>{submitting ? 'Submitting...' : 'Submit Quiz'}</span>
              </Button>
            </div>
          </div>
        ) : (
          /* Quiz Results */
          <Card>
            <CardHeader>
              <CardTitle className={`text-2xl flex items-center space-x-2 ${result.passed ? 'text-green-600' : 'text-red-600'}`}>
                {result.passed ? (
                  <CheckCircle className="h-6 w-6" />
                ) : (
                  <XCircle className="h-6 w-6" />
                )}
                <span>Quiz {result.passed ? 'Passed' : 'Failed'}</span>
              </CardTitle>
              <CardDescription className="text-lg">
                You scored <span className="font-bold">{result.score}%</span>
                {result.passed 
                  ? ' - Congratulations!' 
                  : ` - You need ${quiz.pass_score}% to pass.`
                }
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Question Results */}
                <div className="space-y-3">
                  <h3 className="font-semibold">Question Review:</h3>
                  {result.details.map((detail: any, index: number) => (
                    <div key={index} className={`p-3 rounded-lg border ${detail.correct ? 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20' : 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20'}`}>
                      <div className="flex items-center space-x-2 mb-2">
                        {detail.correct ? (
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        ) : (
                          <XCircle className="h-4 w-4 text-red-600" />
                        )}
                        <span className="font-medium">Question {index + 1}</span>
                      </div>
                      {detail.explanation && (
                        <p className="text-sm text-muted-foreground mt-2">
                          {detail.explanation}
                        </p>
                      )}
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-4">
                  <Button 
                    variant="outline"
                    onClick={() => navigate(-1)}
                  >
                    Back to Lesson
                  </Button>
                  
                  {!result.passed && (
                    <Button onClick={resetQuiz}>
                      Try Again
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}