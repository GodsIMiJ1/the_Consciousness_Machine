import { useEffect, useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Link } from 'react-router-dom';
import { BookOpen, Users, GraduationCap, Settings, LogOut, Award, Clock } from 'lucide-react';
import { AITutor } from '@/components/AITutor';

interface Course {
  id: string;
  title: string;
  slug: string;
  summary: string | null;
  required_for_roles: string[];
}

interface Progress {
  courseId: string;
  completed: number;
  total: number;
}

export default function Dashboard() {
  const { profile, signOut } = useAuth();
  const [courses, setCourses] = useState<Course[]>([]);
  const [progress, setProgress] = useState<Progress[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, [profile]);

  const loadDashboardData = async () => {
    try {
      // Load published courses
      const { data: coursesData } = await supabase
        .from('training_courses')
        .select('id, title, slug, summary, required_for_roles')
        .eq('published', true)
        .order('created_at');

      setCourses(coursesData || []);

      // Load user progress for each course
      if (coursesData && profile) {
        const progressData = await Promise.all(
          coursesData.map(async (course) => {
            // Get all lessons in this course
            const { data: modules } = await supabase
              .from('training_modules')
              .select(`
                id,
                training_lessons (id)
              `)
              .eq('course_id', course.id);

            const totalLessons = modules?.reduce((acc, module) => 
              acc + (module.training_lessons?.length || 0), 0) || 0;

            // Get completed lessons
            const lessonIds = modules?.flatMap(module => 
              module.training_lessons?.map((lesson: any) => lesson.id) || []
            ) || [];

            if (lessonIds.length === 0) {
              return { courseId: course.id, completed: 0, total: 0 };
            }

            const { data: completed } = await supabase
              .from('training_lesson_progress')
              .select('lesson_id')
              .eq('user_id', profile.id)
              .eq('completed', true)
              .in('lesson_id', lessonIds);

            return {
              courseId: course.id,
              completed: completed?.length || 0,
              total: totalLessons,
            };
          })
        );

        setProgress(progressData);
      }
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const requiredCourses = courses.filter(course => 
    course.required_for_roles.includes(profile?.role || '')
  );
  const optionalCourses = courses.filter(course => 
    !course.required_for_roles.includes(profile?.role || '')
  );

  const getProgress = (courseId: string) => {
    const prog = progress.find(p => p.courseId === courseId);
    return prog || { completed: 0, total: 0 };
  };

  const getProgressPercentage = (courseId: string) => {
    const prog = getProgress(courseId);
    return prog.total > 0 ? (prog.completed / prog.total) * 100 : 0;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <BookOpen className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">MethaClinic Training</h1>
                <p className="text-sm text-muted-foreground">Sovereign AURA-BREE System</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="font-medium">{profile?.full_name}</p>
                <Badge variant="secondary" className="text-xs">
                  {profile?.role}
                </Badge>
              </div>
              {profile?.role === 'admin' && (
                <Button asChild variant="outline" size="sm">
                  <Link to="/admin/ai-settings">
                    <Settings className="h-4 w-4 mr-2" />
                    AI Settings
                  </Link>
                </Button>
              )}
              <Button variant="ghost" size="sm" onClick={signOut}>
                <LogOut className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Courses</CardTitle>
              <BookOpen className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{courses.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Required Training</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{requiredCourses.length}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completed</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {progress.filter(p => p.total > 0 && p.completed === p.total).length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Required Courses */}
        {requiredCourses.length > 0 && (
          <section className="mb-12">
            <div className="flex items-center mb-6">
              <GraduationCap className="h-6 w-6 text-primary mr-2" />
              <h2 className="text-2xl font-bold">Required for Your Role</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {requiredCourses.map((course) => {
                const courseProgress = getProgress(course.id);
                const percentage = getProgressPercentage(course.id);
                const isCompleted = courseProgress.total > 0 && courseProgress.completed === courseProgress.total;
                
                return (
                  <Card key={course.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-lg">{course.title}</CardTitle>
                        {isCompleted && <Award className="h-5 w-5 text-primary" />}
                      </div>
                      <CardDescription>{course.summary}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {courseProgress.total > 0 && (
                          <div>
                            <div className="flex justify-between text-sm mb-2">
                              <span>Progress</span>
                              <span>{courseProgress.completed}/{courseProgress.total} lessons</span>
                            </div>
                            <Progress value={percentage} className="h-2" />
                          </div>
                        )}
                        <Button asChild className="w-full">
                          <Link to={`/course/${course.slug}`}>
                            {isCompleted ? 'Review Course' : 'Start Training'}
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </section>
        )}

        {/* Optional Courses */}
        {optionalCourses.length > 0 && (
          <section>
            <div className="flex items-center mb-6">
              <Users className="h-6 w-6 text-muted-foreground mr-2" />
              <h2 className="text-2xl font-bold">Additional Training</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {optionalCourses.map((course) => {
                const courseProgress = getProgress(course.id);
                const percentage = getProgressPercentage(course.id);
                const isCompleted = courseProgress.total > 0 && courseProgress.completed === courseProgress.total;
                
                return (
                  <Card key={course.id} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <CardTitle className="text-lg">{course.title}</CardTitle>
                        {isCompleted && <Award className="h-5 w-5 text-primary" />}
                      </div>
                      <CardDescription>{course.summary}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {courseProgress.total > 0 && (
                          <div>
                            <div className="flex justify-between text-sm mb-2">
                              <span>Progress</span>
                              <span>{courseProgress.completed}/{courseProgress.total} lessons</span>
                            </div>
                            <Progress value={percentage} className="h-2" />
                          </div>
                        )}
                        <Button asChild variant="outline" className="w-full">
                          <Link to={`/course/${course.slug}`}>
                            {isCompleted ? 'Review Course' : 'Explore Course'}
                          </Link>
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </section>
        )}

        {courses.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Courses Available</h3>
            <p className="text-muted-foreground">
              Contact your administrator to get courses published.
            </p>
          </div>
        )}
      </main>

      {/* AI Tutor */}
      <AITutor context="Dashboard - User viewing course overview and progress" />
    </div>
  );
}