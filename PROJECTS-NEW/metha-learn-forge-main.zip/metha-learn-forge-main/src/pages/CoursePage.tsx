import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, BookOpen, CheckCircle, Circle, Play, FileText, ListChecks } from 'lucide-react';

interface Course {
  id: string;
  title: string;
  summary: string | null;
  required_for_roles: string[];
}

interface Module {
  id: string;
  title: string;
  order_index: number;
  lessons: Lesson[];
}

interface Lesson {
  id: string;
  title: string;
  type: 'video' | 'article' | 'checklist';
  order_index: number;
  completed?: boolean;
}

export default function CoursePage() {
  const { slug } = useParams<{ slug: string }>();
  const { profile } = useAuth();
  const [course, setCourse] = useState<Course | null>(null);
  const [modules, setModules] = useState<Module[]>([]);
  const [loading, setLoading] = useState(true);
  const [completedLessons, setCompletedLessons] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (slug) {
      loadCourse();
    }
  }, [slug, profile]);

  const loadCourse = async () => {
    try {
      // Load course
      const { data: courseData } = await supabase
        .from('training_courses')
        .select('*')
        .eq('slug', slug)
        .eq('published', true)
        .single();

      if (!courseData) {
        return;
      }

      setCourse(courseData);

      // Load modules and lessons
      const { data: modulesData } = await supabase
        .from('training_modules')
        .select(`
          id,
          title,
          order_index,
          training_lessons (
            id,
            title,
            type,
            order_index
          )
        `)
        .eq('course_id', courseData.id)
        .order('order_index');

      const sortedModules = (modulesData || []).map(module => ({
        ...module,
        lessons: (module.training_lessons || []).sort((a: any, b: any) => a.order_index - b.order_index)
      })).sort((a, b) => a.order_index - b.order_index) as Module[];

      setModules(sortedModules);

      // Load progress if user is authenticated
      if (profile) {
        const allLessonIds = sortedModules.flatMap(module => 
          module.lessons.map((lesson: any) => lesson.id)
        );

        if (allLessonIds.length > 0) {
          const { data: progressData } = await supabase
            .from('training_lesson_progress')
            .select('lesson_id')
            .eq('user_id', profile.id)
            .eq('completed', true)
            .in('lesson_id', allLessonIds);

          setCompletedLessons(new Set(progressData?.map(p => p.lesson_id) || []));
        }
      }
    } catch (error) {
      console.error('Error loading course:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Play className="h-4 w-4" />;
      case 'article':
        return <FileText className="h-4 w-4" />;
      case 'checklist':
        return <ListChecks className="h-4 w-4" />;
      default:
        return <Circle className="h-4 w-4" />;
    }
  };

  const getTotalLessons = () => {
    return modules.reduce((total, module) => total + module.lessons.length, 0);
  };

  const getCompletedCount = () => {
    return completedLessons.size;
  };

  const getProgressPercentage = () => {
    const total = getTotalLessons();
    return total > 0 ? (getCompletedCount() / total) * 100 : 0;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!course) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-semibold mb-2">Course Not Found</h1>
          <p className="text-muted-foreground mb-4">
            The course you're looking for doesn't exist or isn't published yet.
          </p>
          <Button asChild>
            <Link to="/dashboard">Back to Dashboard</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" asChild>
                <Link to="/dashboard">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Dashboard
                </Link>
              </Button>
              <div className="flex items-center space-x-2">
                <BookOpen className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-bold">{course.title}</h1>
              </div>
            </div>
            {course.required_for_roles.includes(profile?.role || '') && (
              <Badge>Required</Badge>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Course Info */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-2xl">{course.title}</CardTitle>
            <CardDescription className="text-base">{course.summary}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-sm text-muted-foreground">
                {modules.length} modules • {getTotalLessons()} lessons
              </div>
              {profile && getTotalLessons() > 0 && (
                <div className="flex items-center space-x-4">
                  <div className="text-sm text-muted-foreground">
                    {getCompletedCount()}/{getTotalLessons()} completed
                  </div>
                  <Progress value={getProgressPercentage()} className="w-32" />
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Modules */}
        <div className="space-y-8">
          {modules.map((module, moduleIndex) => (
            <Card key={module.id}>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <span className="bg-primary text-primary-foreground rounded-full w-8 h-8 flex items-center justify-center text-sm font-bold">
                    {moduleIndex + 1}
                  </span>
                  <span>{module.title}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {module.lessons.map((lesson, lessonIndex) => {
                    const isCompleted = completedLessons.has(lesson.id);
                    
                    return (
                      <div
                        key={lesson.id}
                        className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                      >
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-2">
                            {isCompleted ? (
                              <CheckCircle className="h-5 w-5 text-green-500" />
                            ) : (
                              <Circle className="h-5 w-5 text-muted-foreground" />
                            )}
                            <span className="text-sm font-medium text-muted-foreground">
                              {moduleIndex + 1}.{lessonIndex + 1}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2">
                            {getTypeIcon(lesson.type)}
                            <span className="font-medium">{lesson.title}</span>
                          </div>
                          <Badge variant="outline" className="text-xs">
                            {lesson.type}
                          </Badge>
                        </div>
                        <Button asChild size="sm">
                          <Link to={`/lesson/${lesson.id}`}>
                            {isCompleted ? 'Review' : 'Start'}
                          </Link>
                        </Button>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {modules.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Content Available</h3>
            <p className="text-muted-foreground">
              This course doesn't have any modules or lessons yet.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}