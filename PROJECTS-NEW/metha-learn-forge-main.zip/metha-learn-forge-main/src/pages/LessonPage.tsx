import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Play, FileText, ListChecks, CheckCircle, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { AITutor } from '@/components/AITutor';

interface Lesson {
  id: string;
  title: string;
  type: 'video' | 'article' | 'checklist';
  content: any;
  quiz_id?: string;
  module_id: string;
}

interface Module {
  id: string;
  title: string;
  course_id: string;
}

interface Course {
  id: string;
  title: string;
  slug: string;
}

export default function LessonPage() {
  const { id } = useParams<{ id: string }>();
  const { profile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [lesson, setLesson] = useState<Lesson | null>(null);
  const [module, setModule] = useState<Module | null>(null);
  const [course, setCourse] = useState<Course | null>(null);
  const [completed, setCompleted] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      loadLesson();
    }
  }, [id, profile]);

  const loadLesson = async () => {
    try {
      // Load lesson with module and course info
      const { data: lessonData } = await supabase
        .from('training_lessons')
        .select(`
          *,
          training_modules (
            id,
            title,
            course_id,
            training_courses (
              id,
              title,
              slug
            )
          )
        `)
        .eq('id', id)
        .single();

      if (!lessonData) {
        return;
      }

      setLesson(lessonData as Lesson);
      setModule(lessonData.training_modules);
      setCourse(lessonData.training_modules?.training_courses);

      // Check if lesson is completed
      if (profile) {
        const { data: progressData } = await supabase
          .from('training_lesson_progress')
          .select('completed')
          .eq('user_id', profile.id)
          .eq('lesson_id', id)
          .maybeSingle();

        setCompleted(!!progressData?.completed);
      }
    } catch (error) {
      console.error('Error loading lesson:', error);
    } finally {
      setLoading(false);
    }
  };

  const markComplete = async () => {
    if (!profile || !lesson) return;

    try {
      await supabase.from('training_lesson_progress').upsert({
        user_id: profile.id,
        lesson_id: lesson.id,
        completed: true,
        completed_at: new Date().toISOString()
      });

      setCompleted(true);
      toast({
        title: "Lesson completed!",
        description: "Your progress has been saved.",
      });
    } catch (error) {
      console.error('Error marking lesson complete:', error);
      toast({
        title: "Error",
        description: "Failed to save progress. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'video':
        return <Play className="h-5 w-5" />;
      case 'article':
        return <FileText className="h-5 w-5" />;
      case 'checklist':
        return <ListChecks className="h-5 w-5" />;
      default:
        return <FileText className="h-5 w-5" />;
    }
  };

  const renderLessonContent = () => {
    if (!lesson?.content) return null;

    switch (lesson.type) {
      case 'video':
        return (
          <div className="space-y-4">
            {lesson.content.videoUrl && (
              <video 
                className="w-full rounded-lg border" 
                controls 
                src={lesson.content.videoUrl}
                onEnded={() => !completed && markComplete()}
              >
                Your browser does not support the video tag.
              </video>
            )}
            {lesson.content.description && (
              <p className="text-muted-foreground">{lesson.content.description}</p>
            )}
          </div>
        );

      case 'article':
        return (
          <div className="prose prose-neutral dark:prose-invert max-w-none">
            {lesson.content.articleMarkdown ? (
              <div dangerouslySetInnerHTML={{ __html: lesson.content.articleMarkdown.replace(/\n/g, '<br>') }} />
            ) : (
              <div>
                {lesson.content.content && (
                  <p className="whitespace-pre-wrap">{lesson.content.content}</p>
                )}
              </div>
            )}
          </div>
        );

      case 'checklist':
        return (
          <div className="space-y-3">
            {lesson.content.checklist && Array.isArray(lesson.content.checklist) ? (
              <ul className="space-y-3">
                {lesson.content.checklist.map((item: string, index: number) => (
                  <li key={index} className="flex items-start space-x-3">
                    <div className="flex-shrink-0 w-6 h-6 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-sm font-bold mt-0.5">
                      {index + 1}
                    </div>
                    <span className="text-sm">{item}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-muted-foreground">No checklist items available.</p>
            )}
          </div>
        );

      default:
        return (
          <div className="text-center py-8">
            <p className="text-muted-foreground">Content type not supported yet.</p>
          </div>
        );
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-semibold mb-2">Lesson Not Found</h1>
          <p className="text-muted-foreground mb-4">
            The lesson you're looking for doesn't exist.
          </p>
          <Button asChild>
            <Link to="/dashboard">Back to Dashboard</Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm" asChild>
                <Link to={course ? `/course/${course.slug}` : '/dashboard'}>
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back to Course
                </Link>
              </Button>
              <div className="flex items-center space-x-2">
                {getTypeIcon(lesson.type)}
                <h1 className="text-xl font-bold">{lesson.title}</h1>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline">{lesson.type}</Badge>
              {completed && (
                <Badge className="bg-green-500">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Completed
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        {course && module && (
          <div className="text-sm text-muted-foreground mb-6">
            <Link to="/dashboard" className="hover:text-foreground">Dashboard</Link>
            <span className="mx-2">/</span>
            <Link to={`/course/${course.slug}`} className="hover:text-foreground">{course.title}</Link>
            <span className="mx-2">/</span>
            <span>{module.title}</span>
            <span className="mx-2">/</span>
            <span className="text-foreground">{lesson.title}</span>
          </div>
        )}

        {/* Lesson Content */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center space-x-2">
                  {getTypeIcon(lesson.type)}
                  <span>{lesson.title}</span>
                </CardTitle>
                {module && (
                  <CardDescription className="text-base mt-2">
                    Module: {module.title}
                  </CardDescription>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {renderLessonContent()}
          </CardContent>
        </Card>

        {/* Actions */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            {lesson.quiz_id ? (
              <Button 
                onClick={() => navigate(`/quiz/${lesson.quiz_id}`)}
                className="flex items-center space-x-2"
              >
                <Clock className="h-4 w-4" />
                <span>Take Quiz</span>
              </Button>
            ) : (
              <Button
                onClick={markComplete}
                disabled={completed}
                className="flex items-center space-x-2"
              >
                {completed ? (
                  <>
                    <CheckCircle className="h-4 w-4" />
                    <span>Completed</span>
                  </>
                ) : (
                  <span>Mark as Complete</span>
                )}
              </Button>
            )}
          </div>
          
          {course && (
            <Button variant="outline" asChild>
              <Link to={`/course/${course.slug}`}>
                Back to Course
              </Link>
            </Button>
          )}
        </div>
      </main>

      {/* AI Tutor */}
      <AITutor context={`Lesson: ${lesson.title} - Type: ${lesson.type} - Module: ${module?.title || 'Unknown'}`} />
    </div>
  );
}