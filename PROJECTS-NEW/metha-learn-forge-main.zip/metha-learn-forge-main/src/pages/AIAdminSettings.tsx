import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/components/ui/use-toast';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Bot, Server, Cloud, Cpu, Settings2, Save, AlertCircle } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface AISettings {
  id?: string;
  provider: string;
  openai_api_key?: string;
  openai_model?: string;
  ollama_url?: string;
  ollama_model?: string;
  huggingface_token?: string;
  huggingface_model?: string;
  lmstudio_url?: string;
  lmstudio_model?: string;
  system_prompt?: string;
  max_tokens?: number;
  temperature?: number;
  is_active?: boolean;
}

const defaultSettings: AISettings = {
  provider: 'openai',
  openai_model: 'gpt-4.1-2025-04-14',
  ollama_url: 'http://localhost:11434',
  ollama_model: 'llama2',
  huggingface_model: 'microsoft/DialoGPT-medium',
  lmstudio_url: 'http://localhost:1234',
  lmstudio_model: 'local-model',
  system_prompt: 'You are an AI tutor for the MethaClinic training platform.',
  max_tokens: 1000,
  temperature: 0.7,
  is_active: true
};

export default function AIAdminSettings() {
  const { profile } = useAuth();
  const { toast } = useToast();
  const [settings, setSettings] = useState<AISettings>(defaultSettings);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (profile?.role === 'admin') {
      loadSettings();
    }
  }, [profile]);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('ai_settings')
        .select('*')
        .eq('is_active', true)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setSettings(data);
      }
    } catch (error) {
      console.error('Error loading AI settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to load AI settings',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    setSaving(true);
    try {
      const { error } = await supabase
        .from('ai_settings')
        .upsert({
          ...settings,
          is_active: true
        });

      if (error) throw error;

      toast({
        title: 'Settings Saved',
        description: 'AI provider settings have been updated successfully.'
      });
    } catch (error) {
      console.error('Error saving AI settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to save AI settings',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  const updateSetting = (key: keyof AISettings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  if (profile?.role !== 'admin') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="pt-6 text-center">
            <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Access Denied</h2>
            <p className="text-muted-foreground">Only administrators can access AI settings.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <Bot className="h-8 w-8 text-primary" />
            AI Provider Settings
          </h1>
          <p className="text-muted-foreground mt-2">
            Configure sovereign AI services for the training platform. Choose between cloud and local providers.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <Card className={`cursor-pointer transition-colors ${settings.provider === 'openai' ? 'ring-2 ring-primary' : ''}`}
                onClick={() => updateSetting('provider', 'openai')}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <Cloud className="h-6 w-6 text-blue-500" />
                <Badge variant={settings.provider === 'openai' ? 'default' : 'secondary'}>
                  Cloud
                </Badge>
              </div>
              <CardTitle className="text-lg">OpenAI</CardTitle>
              <CardDescription>GPT-4.1 and other OpenAI models</CardDescription>
            </CardHeader>
          </Card>

          <Card className={`cursor-pointer transition-colors ${settings.provider === 'ollama' ? 'ring-2 ring-primary' : ''}`}
                onClick={() => updateSetting('provider', 'ollama')}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <Server className="h-6 w-6 text-green-500" />
                <Badge variant={settings.provider === 'ollama' ? 'default' : 'secondary'}>
                  Local
                </Badge>
              </div>
              <CardTitle className="text-lg">Ollama</CardTitle>
              <CardDescription>Local LLMs with privacy</CardDescription>
            </CardHeader>
          </Card>

          <Card className={`cursor-pointer transition-colors ${settings.provider === 'lmstudio' ? 'ring-2 ring-primary' : ''}`}
                onClick={() => updateSetting('provider', 'lmstudio')}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <Cpu className="h-6 w-6 text-purple-500" />
                <Badge variant={settings.provider === 'lmstudio' ? 'default' : 'secondary'}>
                  Local
                </Badge>
              </div>
              <CardTitle className="text-lg">LM Studio</CardTitle>
              <CardDescription>Local model server</CardDescription>
            </CardHeader>
          </Card>

          <Card className={`cursor-pointer transition-colors ${settings.provider === 'huggingface' ? 'ring-2 ring-primary' : ''}`}
                onClick={() => updateSetting('provider', 'huggingface')}>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <Cloud className="h-6 w-6 text-orange-500" />
                <Badge variant={settings.provider === 'huggingface' ? 'default' : 'secondary'}>
                  Cloud
                </Badge>
              </div>
              <CardTitle className="text-lg">Hugging Face</CardTitle>
              <CardDescription>Open source models</CardDescription>
            </CardHeader>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings2 className="h-5 w-5" />
              Provider Configuration
            </CardTitle>
            <CardDescription>
              Configure settings for the selected AI provider: <Badge>{settings.provider}</Badge>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={settings.provider} className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="openai">OpenAI</TabsTrigger>
                <TabsTrigger value="ollama">Ollama</TabsTrigger>
                <TabsTrigger value="lmstudio">LM Studio</TabsTrigger>
                <TabsTrigger value="huggingface">Hugging Face</TabsTrigger>
              </TabsList>

              <TabsContent value="openai" className="space-y-4 mt-6">
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    OpenAI API key can also be set via Supabase Edge Function secrets for enhanced security.
                  </AlertDescription>
                </Alert>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="openai-key">API Key (Optional)</Label>
                    <Input
                      id="openai-key"
                      type="password"
                      value={settings.openai_api_key || ''}
                      onChange={(e) => updateSetting('openai_api_key', e.target.value)}
                      placeholder="sk-..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="openai-model">Model</Label>
                    <Select value={settings.openai_model} onValueChange={(value) => updateSetting('openai_model', value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gpt-5-2025-08-07">GPT-5 (Latest)</SelectItem>
                        <SelectItem value="gpt-4.1-2025-04-14">GPT-4.1</SelectItem>
                        <SelectItem value="gpt-4.1-mini-2025-04-14">GPT-4.1 Mini</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="ollama" className="space-y-4 mt-6">
                <Alert>
                  <Server className="h-4 w-4" />
                  <AlertDescription>
                    Ollama must be running locally. Install from ollama.ai and pull your desired model.
                  </AlertDescription>
                </Alert>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="ollama-url">Ollama URL</Label>
                    <Input
                      id="ollama-url"
                      value={settings.ollama_url || ''}
                      onChange={(e) => updateSetting('ollama_url', e.target.value)}
                      placeholder="http://localhost:11434"
                    />
                  </div>
                  <div>
                    <Label htmlFor="ollama-model">Model</Label>
                    <Input
                      id="ollama-model"
                      value={settings.ollama_model || ''}
                      onChange={(e) => updateSetting('ollama_model', e.target.value)}
                      placeholder="llama2, mistral, codellama, etc."
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="lmstudio" className="space-y-4 mt-6">
                <Alert>
                  <Cpu className="h-4 w-4" />
                  <AlertDescription>
                    LM Studio must be running with a loaded model. Configure the local server in LM Studio settings.
                  </AlertDescription>
                </Alert>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="lmstudio-url">LM Studio URL</Label>
                    <Input
                      id="lmstudio-url"
                      value={settings.lmstudio_url || ''}
                      onChange={(e) => updateSetting('lmstudio_url', e.target.value)}
                      placeholder="http://localhost:1234"
                    />
                  </div>
                  <div>
                    <Label htmlFor="lmstudio-model">Model Name</Label>
                    <Input
                      id="lmstudio-model"
                      value={settings.lmstudio_model || ''}
                      onChange={(e) => updateSetting('lmstudio_model', e.target.value)}
                      placeholder="local-model"
                    />
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="huggingface" className="space-y-4 mt-6">
                <Alert>
                  <Cloud className="h-4 w-4" />
                  <AlertDescription>
                    Get your Hugging Face token from huggingface.co/settings/tokens
                  </AlertDescription>
                </Alert>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="hf-token">Access Token</Label>
                    <Input
                      id="hf-token"
                      type="password"
                      value={settings.huggingface_token || ''}
                      onChange={(e) => updateSetting('huggingface_token', e.target.value)}
                      placeholder="hf_..."
                    />
                  </div>
                  <div>
                    <Label htmlFor="hf-model">Model</Label>
                    <Input
                      id="hf-model"
                      value={settings.huggingface_model || ''}
                      onChange={(e) => updateSetting('huggingface_model', e.target.value)}
                      placeholder="microsoft/DialoGPT-medium"
                    />
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="mt-8 space-y-4">
              <h3 className="text-lg font-semibold">General Settings</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="max-tokens">Max Tokens</Label>
                  <Input
                    id="max-tokens"
                    type="number"
                    value={settings.max_tokens || ''}
                    onChange={(e) => updateSetting('max_tokens', parseInt(e.target.value))}
                    placeholder="1000"
                  />
                </div>
                <div>
                  <Label htmlFor="temperature">Temperature</Label>
                  <Input
                    id="temperature"
                    type="number"
                    step="0.1"
                    min="0"
                    max="2"
                    value={settings.temperature || ''}
                    onChange={(e) => updateSetting('temperature', parseFloat(e.target.value))}
                    placeholder="0.7"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="system-prompt">System Prompt</Label>
                <Textarea
                  id="system-prompt"
                  rows={6}
                  value={settings.system_prompt || ''}
                  onChange={(e) => updateSetting('system_prompt', e.target.value)}
                  placeholder="You are an AI tutor for the MethaClinic training platform..."
                />
              </div>
            </div>

            <div className="flex justify-end mt-6">
              <Button onClick={saveSettings} disabled={saving}>
                <Save className="h-4 w-4 mr-2" />
                {saving ? 'Saving...' : 'Save Settings'}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}