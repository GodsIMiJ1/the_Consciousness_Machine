import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { BookOpen, Users, Shield, Zap } from "lucide-react";
import { useEffect } from "react";

const Index = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      navigate("/dashboard");
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
      {/* Hero Section */}
      <div className="container mx-auto px-4 py-20">
        <div className="text-center max-w-4xl mx-auto">
          <div className="flex items-center justify-center mb-8">
            <BookOpen className="h-16 w-16 text-primary mr-4" />
            <div className="text-left">
              <h1 className="text-5xl font-bold mb-2">MethaClinic</h1>
              <p className="text-2xl text-primary font-semibold">Training Platform</p>
            </div>
          </div>
          
          <h2 className="text-3xl font-bold mb-6 text-foreground">
            Master the Sovereign AURA-BREE System
          </h2>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Comprehensive training for healthcare professionals to confidently operate 
            the sovereign clinic management system with full data ownership and privacy.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
            <Button asChild size="lg" className="text-lg px-8">
              <Link to="/auth">Get Started</Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="text-lg px-8">
              <Link to="/auth">Sign In</Link>
            </Button>
          </div>
        </div>

        {/* Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <div className="text-center p-6 rounded-lg border bg-card">
            <Users className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-3">Role-Based Learning</h3>
            <p className="text-muted-foreground">
              Customized training paths for administrators, clinicians, and reception staff.
            </p>
          </div>
          
          <div className="text-center p-6 rounded-lg border bg-card">
            <Shield className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-3">Privacy & Sovereignty</h3>
            <p className="text-muted-foreground">
              Learn to maintain complete control over patient data and clinic operations.
            </p>
          </div>
          
          <div className="text-center p-6 rounded-lg border bg-card">
            <Zap className="h-12 w-12 text-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-3">Interactive Training</h3>
            <p className="text-muted-foreground">
              Hands-on lessons with videos, articles, checklists, and practical quizzes.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
