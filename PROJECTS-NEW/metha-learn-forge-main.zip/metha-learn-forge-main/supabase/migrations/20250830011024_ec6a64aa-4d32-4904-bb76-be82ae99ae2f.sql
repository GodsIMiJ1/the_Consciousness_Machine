-- Insert seed courses with proper array syntax and UUID casting
INSERT INTO training_courses (id, title, slug, summary, required_for_roles, published, created_at) VALUES 
(
  'f47ac10b-58cc-4372-a567-0e02b2c3d479'::uuid,
  'Front Desk Onboarding',
  'front-desk-onboarding',
  'Essential check-in workflow, visit creation, and privacy fundamentals for reception staff.',
  ARRAY['reception'],
  true,
  now()
),
(
  'f47ac10b-58cc-4372-a567-0e02b2c3d480'::uuid,
  'Clinician Operations',
  'clinician-operations',
  'Advanced clinical workflows, documentation standards, and compliance requirements for medical staff.',
  ARRAY['clinician'],
  true,
  now()
),
(
  'f47ac10b-58cc-4372-a567-0e02b2c3d481'::uuid,
  'AURA-BREE System Overview',
  'aura-bree-overview',
  'Introduction to the sovereign AURA-BREE system architecture and core principles.',
  ARRAY[]::text[],
  true,
  now()
);

-- Insert modules for Front Desk Onboarding
INSERT INTO training_modules (id, course_id, title, order_index, created_at) VALUES
(
  'a47ac10b-58cc-4372-a567-0e02b2c3d479'::uuid,
  'f47ac10b-58cc-4372-a567-0e02b2c3d479'::uuid,
  'Welcome & Introduction',
  1,
  now()
),
(
  'a47ac10b-58cc-4372-a567-0e02b2c3d480'::uuid,
  'f47ac10b-58cc-4372-a567-0e02b2c3d479'::uuid,
  'Check-in Procedures',
  2,
  now()
),
(
  'a47ac10b-58cc-4372-a567-0e02b2c3d481'::uuid,
  'f47ac10b-58cc-4372-a567-0e02b2c3d479'::uuid,
  'Privacy & Compliance',
  3,
  now()
);

-- Insert modules for Clinician Operations  
INSERT INTO training_modules (id, course_id, title, order_index, created_at) VALUES
(
  'a47ac10b-58cc-4372-a567-0e02b2c3d482'::uuid,
  'f47ac10b-58cc-4372-a567-0e02b2c3d480'::uuid,
  'Clinical Documentation',
  1,
  now()
),
(
  'a47ac10b-58cc-4372-a567-0e02b2c3d483'::uuid,
  'f47ac10b-58cc-4372-a567-0e02b2c3d480'::uuid,
  'Patient Care Protocols',
  2,
  now()
);

-- Insert modules for AURA-BREE Overview
INSERT INTO training_modules (id, course_id, title, order_index, created_at) VALUES
(
  'a47ac10b-58cc-4372-a567-0e02b2c3d484'::uuid,
  'f47ac10b-58cc-4372-a567-0e02b2c3d481'::uuid,
  'System Architecture',
  1,
  now()
);

-- Create quiz for Privacy & Compliance
INSERT INTO training_quizzes (id, title, pass_score, questions, created_at) VALUES
(
  'q47ac10b-58cc-4372-a567-0e02b2c3d479'::uuid,
  'Privacy & Sovereignty Quiz',
  80,
  '[
    {
      "id": "q1",
      "prompt": "What does \"sovereign\" mean in the context of the AURA-BREE system?",
      "choices": [
        "Clinic data is stored on third-party cloud servers",
        "The clinic owns and controls their system and data locally",
        "Patients cannot access their own medical data", 
        "Only administrators can view any information"
      ],
      "correct": [1],
      "explanation": "Sovereign means the clinic has complete ownership and control over their system and data, with no dependence on external cloud providers."
    },
    {
      "id": "q2", 
      "prompt": "Which steps are required during patient check-in? (Select all that apply)",
      "choices": [
        "Verify patient identity",
        "Create or update visit record in dashboard",
        "Export patient data to CSV file",
        "Confirm consent for treatment"
      ],
      "correct": [0, 1, 3],
      "explanation": "Patient check-in requires identity verification, visit record management, and consent confirmation. Data export is not part of check-in."
    },
    {
      "id": "q3",
      "prompt": "What is the primary benefit of a sovereign healthcare system?",
      "choices": [
        "Lower costs through cloud savings",
        "Complete data ownership and privacy control",
        "Faster internet connectivity", 
        "Automated patient scheduling"
      ],
      "correct": [1],
      "explanation": "The key benefit is complete control over sensitive healthcare data without relying on external providers."
    }
  ]',
  now()
);

-- Insert lessons for Front Desk modules
INSERT INTO training_lessons (id, module_id, title, type, content, order_index, quiz_id, created_at) VALUES
-- Welcome module lessons
(
  'l47ac10b-58cc-4372-a567-0e02b2c3d479'::uuid,
  'a47ac10b-58cc-4372-a567-0e02b2c3d479'::uuid,
  'Welcome to MethaClinic',
  'article',
  '{"content": "# Welcome to MethaClinic Training\n\nWelcome to the MethaClinic Training Platform! This comprehensive training program will prepare you to effectively use the sovereign AURA-BREE system.\n\n## What You will Learn\n\n- Patient check-in procedures\n- Visit management workflows\n- Privacy and compliance requirements\n- System navigation and best practices\n\n## Training Approach\n\nOur training combines:\n- **Interactive lessons** with real-world scenarios\n- **Video demonstrations** of key procedures\n- **Practical checklists** for daily workflows\n- **Knowledge assessments** to verify understanding\n\n## Getting Started\n\nThis course is designed to be completed in sequence. Each lesson builds on previous knowledge, so please complete them in order.\n\nLets begin your journey to becoming proficient with the AURA-BREE system!"}',
  1,
  null,
  now()
),
-- Check-in procedures lessons
(
  'l47ac10b-58cc-4372-a567-0e02b2c3d480'::uuid,
  'a47ac10b-58cc-4372-a567-0e02b2c3d480'::uuid,
  'Patient Check-in Workflow',
  'checklist',
  '{"checklist": ["Open the clinic dashboard", "Search for existing patient by name or MRN", "Verify patient identity with photo ID", "Update contact information if needed", "Create new visit record for today", "Confirm patient consent for treatment", "Direct patient to waiting area", "Notify clinical staff of arrival"]}',
  1,
  null,
  now()
),
(
  'l47ac10b-58cc-4372-a567-0e02b2c3d481'::uuid,
  'a47ac10b-58cc-4372-a567-0e02b2c3d480'::uuid,
  'Visit Management Demo',
  'video',
  '{"videoUrl": "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4", "description": "This video demonstrates the step-by-step process of creating and managing patient visits in the dashboard system."}',
  2,
  null,
  now()
),
-- Privacy & Compliance lessons
(
  'l47ac10b-58cc-4372-a567-0e02b2c3d482'::uuid,
  'a47ac10b-58cc-4372-a567-0e02b2c3d481'::uuid,
  'Privacy & Sovereignty Fundamentals',
  'article',
  '{"content": "# Privacy & Sovereignty in Healthcare\n\n## The Sovereign Advantage\n\nThe AURA-BREE system operates on the principle of **data sovereignty**, meaning:\n\n- **Complete Control**: Your clinic owns and controls all patient data\n- **Local Storage**: Data never leaves your facility without explicit permission\n- **No Third Parties**: No cloud providers can access your information\n- **Patient Rights**: Patients maintain full ownership of their health records\n\n## Compliance Requirements\n\n### Daily Practices\n- Verify patient identity before accessing records\n- Log all data access and modifications\n- Secure workstations when unattended\n- Report any suspected security incidents immediately\n\n### Patient Privacy\n- Obtain explicit consent before sharing information\n- Limit access to authorized personnel only\n- Discuss patient information only in private areas\n- Dispose of printed materials securely\n\n## Benefits of Local Control\n\n1. **Enhanced Security**: No external attack vectors\n2. **Regulatory Compliance**: Easier HIPAA adherence\n3. **Performance**: Faster access to local data\n4. **Reliability**: No internet outages affect operations\n\nRemember: You are the guardian of sensitive patient information. Handle it with the utmost care and respect."}',
  1,
  'q47ac10b-58cc-4372-a567-0e02b2c3d479'::uuid,
  now()
);

-- Insert lessons for Clinician Operations
INSERT INTO training_lessons (id, module_id, title, type, content, order_index, quiz_id, created_at) VALUES
(
  'l47ac10b-58cc-4372-a567-0e02b2c3d483'::uuid,
  'a47ac10b-58cc-4372-a567-0e02b2c3d482'::uuid,
  'Clinical Documentation Standards',
  'article',
  '{"content": "# Clinical Documentation Standards\n\n## Documentation Principles\n\n### Accuracy & Completeness\n- Record all relevant patient interactions\n- Use precise, professional language\n- Include date, time, and your signature\n- Document in real-time when possible\n\n### Legal Requirements\n- Follow institutional policies for medical records\n- Maintain patient confidentiality at all times\n- Ensure documentation supports billing and coding\n- Retain records according to legal requirements\n\n## Best Practices\n\n1. **Objective Language**: Use factual, observable terms\n2. **Clear Communication**: Write for other healthcare providers\n3. **Comprehensive Coverage**: Include assessments, plans, and outcomes\n4. **Timely Entry**: Document as soon as possible after patient contact\n\nProper documentation protects both patients and providers while ensuring continuity of care."}',
  1,
  null,
  now()
),
(
  'l47ac10b-58cc-4372-a567-0e02b2c3d484'::uuid,
  'a47ac10b-58cc-4372-a567-0e02b2c3d483'::uuid,
  'Patient Safety Protocols',
  'checklist',
  '{"checklist": ["Verify patient identity using two identifiers", "Review current medications and allergies", "Assess vital signs and document baseline", "Evaluate patient for immediate safety risks", "Document all findings in patient record", "Coordinate care with multidisciplinary team", "Provide patient education as needed", "Schedule appropriate follow-up care"]}',
  1,
  null,
  now()
);

-- Insert lesson for AURA-BREE Overview
INSERT INTO training_lessons (id, module_id, title, type, content, order_index, quiz_id, created_at) VALUES
(
  'l47ac10b-58cc-4372-a567-0e02b2c3d485'::uuid,
  'a47ac10b-58cc-4372-a567-0e02b2c3d484'::uuid,
  'Understanding System Architecture',
  'article',
  '{"content": "# AURA-BREE System Architecture\n\n## Core Components\n\n### AURA (Autonomous Unified Resource Architecture)\n- **Local Server Infrastructure**: On-premise hardware you control\n- **Distributed Storage**: Patient data stored locally with encrypted backups\n- **API Gateway**: Secure interfaces for approved integrations\n\n### BREE (Blockchain-Enabled Electronic Environment)\n- **Immutable Audit Trails**: Complete history of all data access\n- **Smart Contracts**: Automated compliance and consent management\n- **Decentralized Identity**: Patient-controlled digital identity\n\n## Key Benefits\n\n1. **Data Sovereignty**: Complete ownership and control\n2. **Enhanced Security**: No external cloud dependencies\n3. **Regulatory Compliance**: Built-in HIPAA and privacy protections\n4. **Scalability**: Grows with your organizations needs\n5. **Interoperability**: Secure data sharing when authorized\n\n## System Reliability\n\n- **99.9% Uptime**: Local infrastructure reduces external dependencies\n- **Automated Backups**: Multiple recovery options available\n- **Disaster Recovery**: Comprehensive business continuity planning\n\nThe AURA-BREE system represents the future of healthcare technology: powerful, secure, and completely under your control."}',
  1,
  null,
  now()
);