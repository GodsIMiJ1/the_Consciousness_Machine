-- Create AI settings table for sovereign AI configuration
CREATE TABLE IF NOT EXISTS public.ai_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  provider VARCHAR(50) NOT NULL DEFAULT 'openai',
  openai_api_key TEXT,
  openai_model VARCHAR(100) DEFAULT 'gpt-4.1-2025-04-14',
  ollama_url TEXT DEFAULT 'http://localhost:11434',
  ollama_model VARCHAR(100) DEFAULT 'llama2',
  huggingface_token TEXT,
  huggingface_model VARCHAR(200) DEFAULT 'microsoft/DialoGPT-medium',
  lmstudio_url TEXT DEFAULT 'http://localhost:1234',
  lmstudio_model VARCHAR(100) DEFAULT 'local-model',
  system_prompt TEXT DEFAULT 'You are an AI tutor for the MethaClinic training platform.',
  max_tokens INTEGER DEFAULT 1000,
  temperature DECIMAL(3,2) DEFAULT 0.7,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.ai_settings ENABLE ROW LEVEL SECURITY;

-- Only admins can manage AI settings
CREATE POLICY "ai_settings_admin_all" ON public.ai_settings
  FOR ALL USING (training_get_user_role() = 'admin')
  WITH CHECK (training_get_user_role() = 'admin');

-- Insert default configuration
INSERT INTO public.ai_settings (provider, system_prompt) VALUES (
  'openai',
  'You are an AI tutor for the MethaClinic training platform. Your role is to:

1. Help users navigate through courses, modules, and lessons
2. Answer questions about training content related to methadone clinic operations
3. Provide explanations for medical procedures, safety protocols, and best practices
4. Guide users through quiz questions when they''re stuck (without giving direct answers)
5. Encourage learning and provide supportive feedback

Key areas you can help with:
- Methadone dosing protocols and safety
- Patient care and interaction guidelines
- Clinic operations and procedures
- Documentation and compliance requirements
- Emergency protocols and procedures

Always be encouraging, professional, and educational. If asked about topics outside your scope, politely redirect to training materials or suggest contacting supervisors.'
) ON CONFLICT DO NOTHING;

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION update_ai_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER ai_settings_updated_at
  BEFORE UPDATE ON public.ai_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_ai_settings_updated_at();