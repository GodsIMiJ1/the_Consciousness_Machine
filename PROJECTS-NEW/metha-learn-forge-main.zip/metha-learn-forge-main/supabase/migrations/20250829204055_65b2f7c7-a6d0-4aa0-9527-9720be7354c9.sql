-- Training system database schema

-- User profiles for training system (extends auth.users)
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  role TEXT CHECK (role IN ('admin','clinician','reception','observer')) NOT NULL DEFAULT 'observer',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Courses
CREATE TABLE IF NOT EXISTS public.courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  summary TEXT,
  required_for_roles TEXT[] DEFAULT '{}',
  published BOOLEAN DEFAULT FALSE,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Modules within courses
CREATE TABLE IF NOT EXISTS public.modules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID REFERENCES public.courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  order_index INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Lessons within modules
CREATE TABLE IF NOT EXISTS public.lessons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id UUID REFERENCES public.modules(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  type TEXT CHECK (type IN ('video','article','checklist')) NOT NULL,
  content JSONB NOT NULL,
  order_index INTEGER NOT NULL DEFAULT 0,
  quiz_id UUID,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Quiz bank
CREATE TABLE IF NOT EXISTS public.quizzes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  pass_score INTEGER NOT NULL CHECK (pass_score BETWEEN 0 AND 100),
  questions JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Progress tracking
CREATE TABLE IF NOT EXISTS public.lesson_progress (
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  lesson_id UUID REFERENCES public.lessons(id) ON DELETE CASCADE,
  completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (user_id, lesson_id)
);

-- Quiz attempts
CREATE TABLE IF NOT EXISTS public.quiz_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  quiz_id UUID REFERENCES public.quizzes(id) ON DELETE CASCADE,
  score INTEGER NOT NULL,
  passed BOOLEAN NOT NULL,
  details JSONB,
  ip_hash TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Certificates
CREATE TABLE IF NOT EXISTS public.certificates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  course_id UUID REFERENCES public.courses(id) ON DELETE CASCADE,
  issued_at TIMESTAMPTZ DEFAULT NOW(),
  serial TEXT UNIQUE NOT NULL
);

-- Audit events for training system
CREATE TABLE IF NOT EXISTS public.training_audit_events (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID,
  event TEXT NOT NULL,
  meta JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on all tables
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lesson_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.certificates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.training_audit_events ENABLE ROW LEVEL SECURITY;

-- Helper function to get user role
CREATE OR REPLACE FUNCTION public.get_user_role()
RETURNS TEXT AS $$
  SELECT role FROM public.profiles WHERE id = auth.uid()
$$ LANGUAGE SQL STABLE SECURITY DEFINER;

-- Profiles policies
CREATE POLICY "Users can view own profile and admins can view all" 
ON public.profiles FOR SELECT 
USING (id = auth.uid() OR public.get_user_role() = 'admin');

CREATE POLICY "Users can update own profile and admins can update all" 
ON public.profiles FOR UPDATE 
USING (id = auth.uid() OR public.get_user_role() = 'admin');

CREATE POLICY "Users can insert own profile" 
ON public.profiles FOR INSERT 
WITH CHECK (id = auth.uid());

-- Courses policies
CREATE POLICY "Anyone can view published courses, admins can view all" 
ON public.courses FOR SELECT 
USING (published = TRUE OR public.get_user_role() = 'admin');

CREATE POLICY "Only admins can manage courses" 
ON public.courses FOR ALL 
USING (public.get_user_role() = 'admin') 
WITH CHECK (public.get_user_role() = 'admin');

-- Modules policies
CREATE POLICY "Users can view modules from published courses" 
ON public.modules FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.courses c 
    WHERE c.id = course_id AND (c.published = TRUE OR public.get_user_role() = 'admin')
  )
);

CREATE POLICY "Only admins can manage modules" 
ON public.modules FOR ALL 
USING (public.get_user_role() = 'admin') 
WITH CHECK (public.get_user_role() = 'admin');

-- Lessons policies
CREATE POLICY "Users can view lessons from published courses" 
ON public.lessons FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM public.modules m 
    JOIN public.courses c ON c.id = m.course_id
    WHERE m.id = module_id AND (c.published = TRUE OR public.get_user_role() = 'admin')
  )
);

CREATE POLICY "Only admins can manage lessons" 
ON public.lessons FOR ALL 
USING (public.get_user_role() = 'admin') 
WITH CHECK (public.get_user_role() = 'admin');

-- Quizzes policies
CREATE POLICY "Anyone can view quizzes" 
ON public.quizzes FOR SELECT 
USING (TRUE);

CREATE POLICY "Only admins can manage quizzes" 
ON public.quizzes FOR ALL 
USING (public.get_user_role() = 'admin') 
WITH CHECK (public.get_user_role() = 'admin');

-- Progress policies
CREATE POLICY "Users can manage own progress, admins can view all" 
ON public.lesson_progress FOR ALL 
USING (user_id = auth.uid() OR public.get_user_role() = 'admin') 
WITH CHECK (user_id = auth.uid() OR public.get_user_role() = 'admin');

-- Quiz attempts policies
CREATE POLICY "Users can manage own attempts, admins can view all" 
ON public.quiz_attempts FOR ALL 
USING (user_id = auth.uid() OR public.get_user_role() = 'admin') 
WITH CHECK (user_id = auth.uid() OR public.get_user_role() = 'admin');

-- Certificates policies
CREATE POLICY "Users can view own certificates, admins can view all" 
ON public.certificates FOR SELECT 
USING (user_id = auth.uid() OR public.get_user_role() = 'admin');

CREATE POLICY "Only admins can issue certificates" 
ON public.certificates FOR INSERT 
WITH CHECK (public.get_user_role() = 'admin');

-- Audit events policies
CREATE POLICY "Only admins can view audit events" 
ON public.training_audit_events FOR SELECT 
USING (public.get_user_role() = 'admin');

CREATE POLICY "System can insert audit events" 
ON public.training_audit_events FOR INSERT 
WITH CHECK (TRUE);

-- Triggers for updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_profiles_updated_at 
BEFORE UPDATE ON public.profiles 
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_courses_updated_at 
BEFORE UPDATE ON public.courses 
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();