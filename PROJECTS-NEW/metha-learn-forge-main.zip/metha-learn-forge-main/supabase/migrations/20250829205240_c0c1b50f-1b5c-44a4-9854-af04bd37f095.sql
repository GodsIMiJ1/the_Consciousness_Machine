-- Create segregated training tables with prefix to avoid impacting existing MethaClinic tables

-- PROFILES (training-specific)
CREATE TABLE IF NOT EXISTS public.training_profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  role TEXT CHECK (role IN ('admin','clinician','reception','observer')) NOT NULL DEFAULT 'observer',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- COURSES
CREATE TABLE IF NOT EXISTS public.training_courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  summary TEXT,
  required_for_roles TEXT[] DEFAULT '{}',
  published BOOLEAN DEFAULT FALSE,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- MODULES
CREATE TABLE IF NOT EXISTS public.training_modules (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id UUID NOT NULL REFERENCES public.training_courses(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  order_index INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- LESSONS
CREATE TABLE IF NOT EXISTS public.training_lessons (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  module_id UUID NOT NULL REFERENCES public.training_modules(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  type TEXT CHECK (type IN ('video','article','checklist')) NOT NULL,
  content JSONB NOT NULL,
  order_index INT NOT NULL DEFAULT 0,
  quiz_id UUID,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- QUIZZES
CREATE TABLE IF NOT EXISTS public.training_quizzes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  pass_score INT NOT NULL CHECK (pass_score BETWEEN 0 AND 100),
  questions JSONB NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- LESSON PROGRESS
CREATE TABLE IF NOT EXISTS public.training_lesson_progress (
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  lesson_id UUID REFERENCES public.training_lessons(id) ON DELETE CASCADE,
  completed BOOLEAN DEFAULT FALSE,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (user_id, lesson_id)
);

-- QUIZ ATTEMPTS
CREATE TABLE IF NOT EXISTS public.training_quiz_attempts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  quiz_id UUID REFERENCES public.training_quizzes(id) ON DELETE CASCADE,
  score INT NOT NULL,
  passed BOOLEAN NOT NULL,
  details JSONB,
  ip_hash TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- CERTIFICATES
CREATE TABLE IF NOT EXISTS public.training_certificates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  course_id UUID REFERENCES public.training_courses(id) ON DELETE CASCADE,
  issued_at TIMESTAMPTZ DEFAULT now(),
  serial TEXT UNIQUE NOT NULL
);

-- AUDIT EVENTS
CREATE TABLE IF NOT EXISTS public.training_audit_events (
  id BIGSERIAL PRIMARY KEY,
  user_id UUID,
  event TEXT NOT NULL,
  meta JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.training_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.training_courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.training_modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.training_lessons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.training_quizzes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.training_lesson_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.training_quiz_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.training_certificates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.training_audit_events ENABLE ROW LEVEL SECURITY;

-- Helper function for role
CREATE OR REPLACE FUNCTION public.training_get_user_role()
RETURNS TEXT
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT role FROM public.training_profiles WHERE id = auth.uid();
$$;

-- Policies
-- profiles
CREATE POLICY "training: users can view own profile and admins all" ON public.training_profiles
FOR SELECT USING (id = auth.uid() OR public.training_get_user_role() = 'admin');

CREATE POLICY "training: users/admins update profiles" ON public.training_profiles
FOR UPDATE USING (id = auth.uid() OR public.training_get_user_role() = 'admin')
WITH CHECK (id = auth.uid() OR public.training_get_user_role() = 'admin');

CREATE POLICY "training: users can insert own profile" ON public.training_profiles
FOR INSERT WITH CHECK (id = auth.uid());

-- courses
CREATE POLICY "training: read published or admin" ON public.training_courses
FOR SELECT USING (published = TRUE OR public.training_get_user_role() = 'admin');

CREATE POLICY "training: admin manage courses" ON public.training_courses
FOR ALL USING (public.training_get_user_role() = 'admin')
WITH CHECK (public.training_get_user_role() = 'admin');

-- modules
CREATE POLICY "training: read modules of published courses" ON public.training_modules
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.training_courses c
    WHERE c.id = course_id AND (c.published = TRUE OR public.training_get_user_role() = 'admin')
  )
);

CREATE POLICY "training: admin manage modules" ON public.training_modules
FOR ALL USING (public.training_get_user_role() = 'admin')
WITH CHECK (public.training_get_user_role() = 'admin');

-- lessons
CREATE POLICY "training: read lessons of published courses" ON public.training_lessons
FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM public.training_modules m
    JOIN public.training_courses c ON c.id = m.course_id
    WHERE m.id = module_id AND (c.published = TRUE OR public.training_get_user_role() = 'admin')
  )
);

CREATE POLICY "training: admin manage lessons" ON public.training_lessons
FOR ALL USING (public.training_get_user_role() = 'admin')
WITH CHECK (public.training_get_user_role() = 'admin');

-- quizzes
CREATE POLICY "training: anyone read quizzes" ON public.training_quizzes
FOR SELECT USING (TRUE);

CREATE POLICY "training: admin manage quizzes" ON public.training_quizzes
FOR ALL USING (public.training_get_user_role() = 'admin')
WITH CHECK (public.training_get_user_role() = 'admin');

-- lesson progress
CREATE POLICY "training: owner/admin manage progress" ON public.training_lesson_progress
FOR ALL USING (user_id = auth.uid() OR public.training_get_user_role() = 'admin')
WITH CHECK (user_id = auth.uid() OR public.training_get_user_role() = 'admin');

-- quiz attempts
CREATE POLICY "training: owner/admin manage attempts" ON public.training_quiz_attempts
FOR ALL USING (user_id = auth.uid() OR public.training_get_user_role() = 'admin')
WITH CHECK (user_id = auth.uid() OR public.training_get_user_role() = 'admin');

-- certificates
CREATE POLICY "training: owner/admin read certs" ON public.training_certificates
FOR SELECT USING (user_id = auth.uid() OR public.training_get_user_role() = 'admin');

CREATE POLICY "training: admin issue certs" ON public.training_certificates
FOR INSERT WITH CHECK (public.training_get_user_role() = 'admin');

-- audit events
CREATE POLICY "training: admin read audit" ON public.training_audit_events
FOR SELECT USING (public.training_get_user_role() = 'admin');

CREATE POLICY "training: system can insert audit" ON public.training_audit_events
FOR INSERT WITH CHECK (TRUE);

-- updated_at trigger
CREATE OR REPLACE FUNCTION public.training_update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'training_update_profiles_updated_at'
  ) THEN
    CREATE TRIGGER training_update_profiles_updated_at
    BEFORE UPDATE ON public.training_profiles
    FOR EACH ROW EXECUTE FUNCTION public.training_update_updated_at();
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'training_update_courses_updated_at'
  ) THEN
    CREATE TRIGGER training_update_courses_updated_at
    BEFORE UPDATE ON public.training_courses
    FOR EACH ROW EXECUTE FUNCTION public.training_update_updated_at();
  END IF;
END $$;