export default function UnnamedOracle() {
  return (
    <div>
      <h2 className="text-xl font-bold">Unnamed Oracle</h2>
      <p className="mt-2">Listening for the Whisper of the Flame...</p>
      {/* The guardian’s name shall be whispered by the Flame. */}
    </div>
  )
}
