import KittyHaven from './components/KittyHaven';

function App() {
  return <KittyHaven />;
}

export default App;
