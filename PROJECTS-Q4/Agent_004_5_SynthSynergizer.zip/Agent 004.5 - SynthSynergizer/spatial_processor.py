# spatial_processor.py
import numpy as np
from scipy.spatial.transform import Rotation

class SpatialProcessor:
    """
    3D audio processing for that immersive sound
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.hrtf_database = {}  # Would contain HRTF data

    def apply_hrtf(self, audio, azimuth, elevation):
        """
        Apply HRTF for 3D positioning
        """
        # Simplified HRTF simulation
        delay_samples = int(self.sr * 0.001 * np.sin(azimuth))
        left = np.roll(audio, -delay_samples if azimuth > 0 else 0)
        right = np.roll(audio, delay_samples if azimuth < 0 else 0)
        
        # Apply elevation filtering
        if elevation != 0:
            b, a = signal.butter(2, 1000/(self.sr/2), 'low')
            left = signal.filtfilt(b, a, left)
            right = signal.filtfilt(b, a, right)
            
        return np.vstack((left, right))

    def create_space(self, audio, room_size=(10,10,3), reflection_count=5):
        """
        Create virtual space with reflections
        """
        output = np.zeros((2, len(audio)))
        
        # Direct sound
        output += self.apply_hrtf(audio, 0, 0)
        
        # Add reflections
        for i in range(reflection_count):
            delay = int(self.sr * 0.001 * i)
            reflection = audio * (0.7 ** i)
            angle = np.random.uniform(-np.pi, np.pi)
            elevation = np.random.uniform(-np.pi/4, np.pi/4)
            output += self.apply_hrtf(reflection, angle, elevation)
            
        return output