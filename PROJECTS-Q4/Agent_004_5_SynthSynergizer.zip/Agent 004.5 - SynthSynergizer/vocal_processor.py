# vocal_processor.py
import numpy as np
from scipy import signal
import librosa
from typing import Dict, List

class VocalProcessor:
    """
    Complete vocal processing chain
    Like having a whole rack of vocal gear
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.fx_chain = []
        self.presets = self._initialize_presets()
        
    def _initialize_presets(self) -> Dict:
        return {
            'trap_main': {
                'autotune': {'amount': 0.8, 'speed': 0.2},
                'compression': {'threshold': -18, 'ratio': 4},
                'eq': {'low_cut': 100, 'presence': 3, 'air': 2},
                'delay': {'time': 0.125, 'feedback': 0.3},
                'reverb': {'size': 0.3, 'mix': 0.2}
            },
            'rap_doubles': {
                'autotune': {'amount': 0.4, 'speed': 0.5},
                'width': {'amount': 0.8},
                'eq': {'low_cut': 150, 'presence': 2},
                'delay': {'time': 0.08, 'feedback': 0.2}
            }
        }
        
    def process_vocal(self, audio: np.ndarray, preset: str = None,
                     custom_params: Dict = None) -> np.ndarray:
        """
        Process vocals through the chain
        """
        processed = audio.copy()
        
        # Get parameters
        params = self.presets.get(preset, {})
        if custom_params:
            params.update(custom_params)
            
        # Apply processing chain
        if 'autotune' in params:
            processed = self._apply_autotune(processed, **params['autotune'])
        if 'compression' in params:
            processed = self._apply_compression(processed, **params['compression'])
        if 'eq' in params:
            processed = self._apply_eq(processed, **params['eq'])
        if 'delay' in params:
            processed = self._apply_delay(processed, **params['delay'])
        if 'reverb' in params:
            processed = self._apply_reverb(processed, **params['reverb'])
            
        return processed
        
    def _apply_autotune(self, audio: np.ndarray, amount: float = 0.5,
                       speed: float = 0.3) -> np.ndarray:
        """
        Apply autotune effect
        """
        # Extract pitch
        f0, voiced_flag, _ = librosa.pyin(audio, 
                                        fmin=librosa.note_to_hz('C2'),
                                        fmax=librosa.note_to_hz('C7'))
        
        # Apply pitch correction
        corrected = f0.copy()
        for i in range(len(f0)):
            if voiced_flag[i]:
                target = librosa.hz_to_note(f0[i])
                correction = librosa.note_to_hz(target) - f0[i]
                corrected[i] = f0[i] + correction * amount
                
        return librosa.effects.pitch_shift(audio, sr=self.sr,
                                         n_steps=corrected-f0)