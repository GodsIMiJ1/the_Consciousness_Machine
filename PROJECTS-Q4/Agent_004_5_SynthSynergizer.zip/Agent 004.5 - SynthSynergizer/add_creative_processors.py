# add_creative_processors.py

import os

def create_creative_processors():
    # Sample mangler for crazy chops and slices
    sample_mangler = """
# sample_mangler.py
import numpy as np
import librosa
from scipy import signal
import random

class SampleMangler:
    \"\"\"
    Sample chopping and mangling like an MPC on steroids
    \"\"\"
    def __init__(self, sr=44100):
        self.sr = sr
        
    def chop_sample(self, audio, n_slices=8):
        \"\"\"
        Chop sample into pieces like classic MPC style
        \"\"\"
        slice_length = len(audio) // n_slices
        slices = [audio[i:i+slice_length] for i in range(0, len(audio), slice_length)]
        return slices[:n_slices]  # Ensure we only return n_slices
        
    def rearrange_slices(self, slices, pattern=None):
        \"\"\"
        Rearrange slices like finger drumming
        \"\"\"
        if pattern is None:
            pattern = list(range(len(slices)))
            random.shuffle(pattern)
            
        return np.concatenate([slices[i] for i in pattern])
        
    def time_stretch_slices(self, slices, stretch_factors=None):
        \"\"\"
        Apply different time stretches to each slice
        \"\"\"
        if stretch_factors is None:
            stretch_factors = [random.uniform(0.5, 2.0) for _ in slices]
            
        stretched = [librosa.effects.time_stretch(s, rate=r) 
                    for s, r in zip(slices, stretch_factors)]
        return stretched
        
    def glitch_slice(self, audio, severity=0.5):
        \"\"\"
        Add glitch effects like digital artifacts
        \"\"\"
        # Randomly replace samples with noise
        glitch_points = np.random.random(len(audio)) < severity/10
        audio[glitch_points] = np.random.random(sum(glitch_points))
        
        # Add some bit-crushing
        bits = int(16 - severity * 14)  # Between 2 and 16 bits
        audio = np.round(audio * (2**bits)) / (2**bits)
        
        return audio
"""

    # Generative melody maker
    melody_generator = """
# melody_generator.py
import numpy as np
from scipy import signal
import random

class MelodyGenerator:
    \"\"\"
    Generate melodies using algorithms and probability
    \"\"\"
    def __init__(self, sr=44100):
        self.sr = sr
        self.scales = {
            'major': [0, 2, 4, 5, 7, 9, 11],
            'minor': [0, 2, 3, 5, 7, 8, 10],
            'pentatonic': [0, 2, 4, 7, 9],
            'blues': [0, 3, 5, 6, 7, 10]
        }
        
    def generate_sequence(self, scale='pentatonic', length=8, root=60):
        \"\"\"
        Generate a melodic sequence based on scale
        \"\"\"
        scale_notes = self.scales[scale]
        sequence = []
        
        # Generate sequence with some musical logic
        prev_note = root
        for _ in range(length):
            # Tendency to move in steps rather than jumps
            if random.random() < 0.7:  # 70% chance of step
                next_note = prev_note + random.choice([-2, -1, 1, 2])
            else:
                next_note = root + random.choice(scale_notes) + \
                           random.choice([-12, 0, 12])
                           
            sequence.append(next_note)
            prev_note = next_note
            
        return sequence
        
    def sequence_to_audio(self, sequence, duration=0.25):
        \"\"\"
        Convert MIDI-style sequence to audio
        \"\"\"
        audio = np.array([])
        for note in sequence:
            freq = 440 * (2 ** ((note - 69) / 12))  # MIDI to Hz
            t = np.linspace(0, duration, int(self.sr * duration))
            tone = np.sin(2 * np.pi * freq * t)
            
            # Add envelope
            envelope = np.exp(-3 * t / duration)
            tone = tone * envelope
            
            audio = np.concatenate([audio, tone])
            
        return audio
"""

    # Advanced sound designer
    sound_designer = """
# sound_designer.py
import numpy as np
from scipy import signal
import random

class SoundDesigner:
    \"\"\"
    Create custom synthesized sounds and textures
    \"\"\"
    def __init__(self, sr=44100):
        self.sr = sr
        
    def create_pad(self, duration=1.0, base_freq=440):
        \"\"\"
        Create atmospheric pad sound
        \"\"\"
        t = np.linspace(0, duration, int(self.sr * duration))
        
        # Multiple detuned oscillators
        oscillators = []
        for i in range(6):
            detune = random.uniform(0.99, 1.01)
            phase = random.uniform(0, 2*np.pi)
            osc = np.sin(2 * np.pi * base_freq * detune * t + phase)
            oscillators.append(osc)
            
        # Mix oscillators
        pad = sum(oscillators) / len(oscillators)
        
        # Apply filtering
        b, a = signal.butter(4, 2000/(self.sr/2), 'low')
        pad = signal.filtfilt(b, a, pad)
        
        # Add slow modulation
        mod = np.sin(2 * np.pi * 0.5 * t)
        pad = pad * (1 + 0.1 * mod)
        
        return pad
        
    def create_impact(self, duration=0.5):
        \"\"\"
        Create impact/hit sound effect
        \"\"\"
        t = np.linspace(0, duration, int(self.sr * duration))
        
        # Noise burst with pitch envelope
        noise = np.random.normal(0, 1, len(t))
        freq_env = np.exp(-10 * t)
        filtered_noise = []
        
        for i in range(len(t)):
            cutoff = 2000 * freq_env[i]
            b, a = signal.butter(4, cutoff/(self.sr/2), 'low')
            filtered_noise.append(signal.filtfilt(b, a, noise[i]))
            
        impact = np.array(filtered_noise)
        
        # Apply amplitude envelope
        amp_env = np.exp(-5 * t)
        impact = impact * amp_env
        
        return impact
"""

    # Create the files
    files = {
        'sample_mangler.py': sample_mangler,
        'melody_generator.py': melody_generator,
        'sound_designer.py': sound_designer
    }

    for filename, content in files.items():
        with open(filename, 'w') as f:
            f.write(content.strip())
        print(f"Created {filename} 🎛️")

if __name__ == "__main__":
    print("Adding creative processors to Agent 004.5... 🎨")
    create_creative_processors()
    print("\nDone! Creative processors ready to cook! 🔥")
