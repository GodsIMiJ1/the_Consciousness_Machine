# signal_analyzer.py
import numpy as np
import librosa
import matplotlib.pyplot as plt

class SignalAnalyzer:
    """
    Visual tools to see what's happening to your audio
    """
    @staticmethod
    def plot_waveform(audio, sr, title="Waveform"):
        plt.figure(figsize=(12, 4))
        librosa.display.waveshow(audio, sr=sr)
        plt.title(title)
        plt.tight_layout()
        plt.show()

    @staticmethod
    def plot_spectrogram(audio, sr, title="Spectrogram"):
        D = librosa.amplitude_to_db(np.abs(librosa.stft(audio)), ref=np.max)
        plt.figure(figsize=(12, 4))
        librosa.display.specshow(D, sr=sr, x_axis='time', y_axis='log')
        plt.colorbar(format='%+2.0f dB')
        plt.title(title)
        plt.tight_layout()
        plt.show()

    @staticmethod
    def compare_before_after(before, after, sr, title="Before/After Comparison"):
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
        librosa.display.waveshow(before, sr=sr, ax=ax1)
        ax1.set_title('Before Processing')
        librosa.display.waveshow(after, sr=sr, ax=ax2)
        ax2.set_title('After Processing')
        plt.tight_layout()
        plt.show()