# spectrum_analyzer.py
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import librosa

class SpectrumAnalyzer:
    """
    Real-time spectrum analyzer with sick visualizations
    """
    def __init__(self, sr=44100, n_fft=2048):
        self.sr = sr
        self.n_fft = n_fft
        self.fig, self.ax = plt.subplots(figsize=(12, 6))
        
    def setup_plot(self):
        """
        Set up the real-time plot
        """
        self.line, = self.ax.plot([], [])
        self.ax.set_xlim(0, self.sr/2)
        self.ax.set_ylim(-120, 0)
        self.ax.set_xlabel('Frequency (Hz)')
        self.ax.set_ylabel('Magnitude (dB)')
        
    def analyze_frame(self, frame):
        """
        Analyze a single frame of audio
        """
        S = librosa.stft(frame, n_fft=self.n_fft)
        S_db = librosa.amplitude_to_db(np.abs(S), ref=np.max)
        return np.mean(S_db, axis=1)
        
    def start_real_time(self, audio_stream):
        """
        Start real-time analysis
        """
        self.setup_plot()
        
        def update(frame):
            spectrum = self.analyze_frame(frame)
            self.line.set_data(librosa.fft_frequencies(sr=self.sr), spectrum)
            return self.line,
            
        ani = FuncAnimation(self.fig, update, frames=audio_stream,
                          interval=50, blit=True)
        plt.show()