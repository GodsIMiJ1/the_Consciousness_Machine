# Agent 004.5 - SynthSynergizer/enhanced_batch_processor.py

import os
import time
import logging
import librosa
import numpy as np
from tqdm import tqdm
from typing import List, Callable, Dict

class EnhancedBatchProcessor:
    """
    The ultimate mixing console for batch processing audio
    Now with progress bars, logging, and metadata handling
    """
    def __init__(self, input_dir: str, output_dir: str):
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.supported_formats = ['.wav', '.mp3', '.flac']
        self.setup_logging()
        
    def setup_logging(self):
        """
        Sets up logging like a recording session tracker
        """
        logging.basicConfig(
            filename='batch_processing.log',
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
    def process_batch_with_progress(self, processor_func: Callable):
        """
        Runs processing with a dope progress bar and metadata tracking
        """
        files = self.get_audio_files()
        results = {
            'processed': 0,
            'failed': 0,
            'start_time': time.time(),
            'metadata': {}
        }
        
        # Progress bar like a track completion meter
        for audio_file in tqdm(files, desc="Processing tracks"):
            try:
                # Load and process
                audio, sr = librosa.load(audio_file)
                processed = processor_func(audio, sr)
                
                # Save metadata
                results['metadata'][audio_file] = {
                    'duration': librosa.get_duration(y=audio, sr=sr),
                    'sample_rate': sr,
                    'channels': 1 if len(audio.shape) == 1 else 2
                }
                
                # Save the processed heat
                output_path = os.path.join(
                    self.output_dir, 
                    f"processed_{os.path.basename(audio_file)}"
                )
                self.save_audio(processed, sr, output_path)
                
                results['processed'] += 1
                logging.info(f"Successfully processed: {audio_file}")
                
            except Exception as e:
                results['failed'] += 1
                logging.error(f"Failed processing {audio_file}: {str(e)}")
                
        self.print_summary(results)
        
    def print_summary(self, results: Dict):
        """
        Prints a summary like a session report
        """
        total_time = time.time() - results['start_time']
        print("\n🎵 Batch Processing Summary 🎵")
        print(f"Tracks Processed: {results['processed']} 🎚️")
        print(f"Failed Tracks: {results['failed']} ⚠️")
        print(f"Total Time: {total_time:.2f}s ⏱️")
        print("\nMetadata Overview:")
        for file, meta in results['metadata'].items():
            print(f"\n{os.path.basename(file)}:")
            print(f"  Duration: {meta['duration']:.2f}s")
            print(f"  Sample Rate: {meta['sample_rate']} Hz")
            print(f"  Channels: {meta['channels']}")

    # ... (previous methods remain the same)
