# granular_processor.py
import numpy as np
import random
from scipy import signal

class GranularEngine:
    """
    Granular synthesis engine for those glitchy textures
    """
    def __init__(self, sr=44100):
        self.sr = sr
        
    def create_grain(self, audio, position, duration=0.1, envelope='gaussian'):
        """
        Create a single grain from the audio
        """
        grain_length = int(duration * self.sr)
        start = int(position * len(audio))
        
        # Extract grain
        grain = audio[start:start + grain_length]
        if len(grain) < grain_length:
            grain = np.pad(grain, (0, grain_length - len(grain)))
            
        # Apply envelope
        if envelope == 'gaussian':
            window = signal.gaussian(len(grain), std=len(grain)/6)
        else:
            window = signal.hann(len(grain))
            
        return grain * window
        
    def process(self, audio, density=50, grain_size=0.1, spread=0.5):
        """
        Create a cloud of grains like a granular synth
        """
        output = np.zeros(len(audio))
        num_grains = int(density * len(audio) / self.sr)
        
        for _ in range(num_grains):
            # Random position with spread
            pos = random.random() * (1.0 - grain_size)
            grain = self.create_grain(audio, pos, duration=grain_size)
            
            # Random position in output
            out_pos = int(random.random() * len(audio))
            end_pos = min(out_pos + len(grain), len(output))
            output[out_pos:end_pos] += grain[:end_pos-out_pos] * spread
            
        return output / np.max(np.abs(output))