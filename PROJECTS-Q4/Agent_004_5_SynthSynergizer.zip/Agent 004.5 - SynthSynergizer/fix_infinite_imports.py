# fix_infinite_imports.py
import os
from pathlib import Path

def fix_skynet_files():
    """
    Fix all those Infinite imports across SKYNET
    """
    base_path = Path("SKYNET_LAUNCH_SYSTEMS")
    
    print("\n🔧 FIXING SKYNET FILES...")
    print("========================")
    
    # Files to check and fix
    python_files = list(base_path.rglob("*.py"))
    
    for file_path in python_files:
        print(f"\nChecking: {file_path}")
        
        try:
            # Read file content with UTF-8 encoding
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Fix the imports
            if 'from typing import Dict, List, Infinite' in content:
                print(f"🔨 Fixing imports in {file_path.name}")
                content = content.replace(
                    'from typing import Dict, List, Infinite',
                    'from typing import Dict, List'
                )
                
                # Replace any Infinite() calls with float('inf')
                content = content.replace('Infinite()', "float('inf')")
                content = content.replace(': Infinite', ': float')
                
                # Write fixed content back with UTF-8 encoding
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                print("✅ Fixed!")
            else:
                print("✅ No fixes needed")
                
        except Exception as e:
            print(f"⚠️  Error with {file_path}: {str(e)}")
            continue

if __name__ == "__main__":
    print("🚀 STARTING SKYNET FILE FIXES...")
    fix_skynet_files()
    print("\n✨ ALL FILES FIXED! Ready to launch!")
