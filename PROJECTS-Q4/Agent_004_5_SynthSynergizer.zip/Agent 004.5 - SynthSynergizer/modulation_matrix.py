# modulation_matrix.py
import numpy as np
from typing import Dict, List, Callable

class ModMatrix:
    """
    Advanced modulation matrix like a modular synth
    Route anything to anything!
    """
    def __init__(self):
        self.sources = {}
        self.destinations = {}
        self.connections = {}
        
    def add_source(self, name: str, generator: Callable):
        """
        Add modulation source (LFO, envelope, etc.)
        """
        self.sources[name] = generator
        
    def add_destination(self, name: str, parameter: str, 
                       processor: Callable):
        """
        Add destination parameter
        """
        self.destinations[name] = {
            'parameter': parameter,
            'processor': processor
        }
        
    def connect(self, source: str, destination: str, 
                amount: float = 1.0):
        """
        Connect source to destination
        """
        if source in self.sources and destination in self.destinations:
            self.connections[(source, destination)] = amount
            
    def process_frame(self, frame_number: int) -> Dict:
        """
        Process all modulations for one frame
        """
        modulations = {}
        
        # Generate source values
        source_values = {
            name: gen(frame_number) 
            for name, gen in self.sources.items()
        }
        
        # Apply connections
        for (source, dest), amount in self.connections.items():
            value = source_values[source] * amount
            if dest not in modulations:
                modulations[dest] = 0
            modulations[dest] += value
            
        # Process destinations
        results = {}
        for dest_name, dest_info in self.destinations.items():
            if dest_name in modulations:
                results[dest_info['parameter']] =                     dest_info['processor'](modulations[dest_name])
                    
        return results