# flow_analyzer.py
import numpy as np
import librosa
from typing import Dict, List

class FlowAnalyzer:
    """
    Analyze rap flows and vocal patterns
    Like having a flow coach in the booth
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.flow_patterns = {}
        
    def analyze_flow(self, vocal_audio: np.ndarray) -> Dict:
        """
        Analyze the flow of a vocal performance
        """
        # Extract vocal features
        onset_env = librosa.onset.onset_strength(y=vocal_audio, sr=self.sr)
        tempo, beat_frames = librosa.beat.beat_track(
            onset_envelope=onset_env, sr=self.sr
        )
        
        # Analyze rhythm against beat grid
        rhythm_features = self._analyze_rhythm(onset_env, beat_frames)
        
        # Analyze pitch patterns
        pitch_features = self._analyze_pitch(vocal_audio)
        
        return {
            'tempo': tempo,
            'rhythm': rhythm_features,
            'pitch': pitch_features,
            'flow_complexity': self._calculate_complexity(
                rhythm_features, pitch_features
            )
        }
        
    def generate_flow_suggestions(self, bpm: float) -> List[Dict]:
        """
        Generate flow pattern suggestions
        """
        suggestions = []
        beat_duration = 60 / bpm
        
        # Generate different flow patterns
        patterns = [
            self._generate_triplet_flow(beat_duration),
            self._generate_double_time_flow(beat_duration),
            self._generate_syncopated_flow(beat_duration)
        ]
        
        return patterns