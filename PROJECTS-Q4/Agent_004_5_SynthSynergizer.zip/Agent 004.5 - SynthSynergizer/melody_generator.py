# melody_generator.py
import numpy as np
from scipy import signal
import random

class MelodyGenerator:
    """
    Generate melodies using algorithms and probability
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.scales = {
            'major': [0, 2, 4, 5, 7, 9, 11],
            'minor': [0, 2, 3, 5, 7, 8, 10],
            'pentatonic': [0, 2, 4, 7, 9],
            'blues': [0, 3, 5, 6, 7, 10]
        }
        
    def generate_sequence(self, scale='pentatonic', length=8, root=60):
        """
        Generate a melodic sequence based on scale
        """
        scale_notes = self.scales[scale]
        sequence = []
        
        # Generate sequence with some musical logic
        prev_note = root
        for _ in range(length):
            # Tendency to move in steps rather than jumps
            if random.random() < 0.7:  # 70% chance of step
                next_note = prev_note + random.choice([-2, -1, 1, 2])
            else:
                next_note = root + random.choice(scale_notes) +                            random.choice([-12, 0, 12])
                           
            sequence.append(next_note)
            prev_note = next_note
            
        return sequence
        
    def sequence_to_audio(self, sequence, duration=0.25):
        """
        Convert MIDI-style sequence to audio
        """
        audio = np.array([])
        for note in sequence:
            freq = 440 * (2 ** ((note - 69) / 12))  # MIDI to Hz
            t = np.linspace(0, duration, int(self.sr * duration))
            tone = np.sin(2 * np.pi * freq * t)
            
            # Add envelope
            envelope = np.exp(-3 * t / duration)
            tone = tone * envelope
            
            audio = np.concatenate([audio, tone])
            
        return audio