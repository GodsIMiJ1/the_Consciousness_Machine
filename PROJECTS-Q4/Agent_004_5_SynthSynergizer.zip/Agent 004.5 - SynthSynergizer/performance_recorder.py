# performance_recorder.py
import numpy as np
import threading
import queue
import time
from typing import Dict, List

class PerformanceRecorder:
    """
    Record and analyze live performances
    Like having a super-smart tape machine
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.recording = False
        self.tracks = {}
        self.midi_events = []
        self.audio_buffer = queue.Queue()
        
    def start_recording(self):
        """
        Start recording performance
        """
        self.recording = True
        self.record_thread = threading.Thread(target=self._record_loop)
        self.record_thread.start()
        
    def _record_loop(self):
        """
        Main recording loop
        """
        while self.recording:
            if not self.audio_buffer.empty():
                audio = self.audio_buffer.get()
                self._process_audio(audio)
                
    def _process_audio(self, audio):
        """
        Process incoming audio
        """
        # Analyze audio features
        features = {
            'rms': np.sqrt(np.mean(audio**2)),
            'peak': np.max(np.abs(audio)),
            'zero_crossings': np.sum(np.diff(np.signbit(audio)))
        }
        
        # Store in tracks
        timestamp = time.time()
        self.tracks[timestamp] = {
            'audio': audio,
            'features': features
        }
        
    def analyze_performance(self):
        """
        Analyze the recorded performance
        """
        analysis = {
            'duration': self._get_duration(),
            'dynamics': self._analyze_dynamics(),
            'timing': self._analyze_timing(),
            'features': self._extract_features()
        }
        return analysis