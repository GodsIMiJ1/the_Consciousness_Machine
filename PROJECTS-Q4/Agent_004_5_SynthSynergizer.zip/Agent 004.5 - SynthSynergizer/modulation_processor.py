# modulation_processor.py
import numpy as np
from scipy import signal

class ModulationFX:
    """
    Modulation effects like those classic studio hardware units
    """
    @staticmethod
    def tremolo(audio, sr, rate=5.0, depth=0.5):
        """
        Amplitude modulation like a tremolo pedal
        """
        # Create LFO
        t = np.arange(len(audio)) / sr
        mod = (1 + depth * np.sin(2 * np.pi * rate * t)) / 2
        return audio * mod

    @staticmethod
    def vibrato(audio, sr, rate=5.0, depth=0.002):
        """
        Pitch modulation like a vintage tape wobble
        """
        t = np.arange(len(audio)) / sr
        mod = depth * np.sin(2 * np.pi * rate * t)
        return signal.resample(audio, len(audio) + int(np.max(mod) * sr))

    @staticmethod
    def phaser(audio, sr, rate=1.0, depth=2.0):
        """
        Phase modulation like those classic 70s effects
        """
        t = np.arange(len(audio)) / sr
        mod = (1 + depth * np.sin(2 * np.pi * rate * t))
        allpass = signal.allpass(audio, mod)
        return 0.5 * (audio + allpass)