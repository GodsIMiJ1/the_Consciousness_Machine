# effects_processor.py
import numpy as np
import librosa
from scipy import signal

class EffectsProcessor:
    """
    Advanced audio effects rack for that extra sauce
    """
    @staticmethod
    def apply_compression(audio, threshold=-20.0, ratio=4.0):
        """
        Compress that audio like squeezing the dynamics
        """
        # Calculate the amplitude envelope
        envelope = np.abs(audio)
        # Apply compression
        compressed = np.where(
            envelope > 10**(threshold/20),
            audio * (10**(threshold/20) + (envelope - 10**(threshold/20)) / ratio),
            audio
        )
        return compressed

    @staticmethod
    def apply_eq(audio, sr, center_freq, gain=1.0, q=1.0):
        """
        EQ processing like sculpting frequencies
        """
        b, a = signal.iirpeak(center_freq, q, sr)
        return signal.lfilter(b, a, audio) * gain

    @staticmethod
    def add_saturation(audio, drive=1.5):
        """
        Add some warmth like analog tape
        """
        return np.tanh(audio * drive)

    @staticmethod
    def create_delay(audio, sr, delay_time=0.3, feedback=0.3):
        """
        Add delay like echo in the studio
        """
        delay_samples = int(sr * delay_time)
        delayed = np.zeros_like(audio)
        delayed[delay_samples:] = audio[:-delay_samples] * feedback
        return audio + delayed