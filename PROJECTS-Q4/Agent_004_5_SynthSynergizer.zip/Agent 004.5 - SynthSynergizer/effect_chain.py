# effect_chain.py
import numpy as np
from typing import List, Dict
import random

class EffectChain:
    """
    Dynamic effect chain processor
    Like having a whole rack of studio gear
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.effects = {}
        self.chains = {}
        
    def add_effect(self, name: str, processor: callable, default_params: Dict = None):
        """
        Add effect to the available effects
        """
        self.effects[name] = {
            'processor': processor,
            'params': default_params or {}
        }
        
    def create_chain(self, name: str, effect_sequence: List[Tuple[str, Dict]]):
        """
        Create an effect chain like patching a mixing desk
        """
        self.chains[name] = effect_sequence
        
    def randomize_chain(self, name: str, amount: float = 0.2):
        """
        Randomize effect parameters for happy accidents
        """
        if name in self.chains:
            new_chain = []
            for effect_name, params in self.chains[name]:
                new_params = params.copy()
                for param, value in new_params.items():
                    variation = value * amount
                    new_params[param] = value + random.uniform(-variation, variation)
                new_chain.append((effect_name, new_params))
            self.chains[name] = new_chain
            
    def process_chain(self, audio: np.ndarray, chain_name: str) -> np.ndarray:
        """
        Process audio through the effect chain
        """
        if chain_name not in self.chains:
            return audio
            
        processed = audio.copy()
        for effect_name, params in self.chains[chain_name]:
            if effect_name in self.effects:
                effect = self.effects[effect_name]
                processed = effect['processor'](processed, **params)
                
        return processed