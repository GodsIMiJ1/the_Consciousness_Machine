# lyric_generator.py
import numpy as np
import random
from typing import List, Dict

class LyricGenerator:
    """
    AI-powered lyric generator
    Like having a ghostwriter with infinite flows
    """
    def __init__(self):
        self.rhyme_dict = self._load_rhyme_dictionary()
        self.flow_patterns = self._initialize_flow_patterns()
        self.themes = self._initialize_themes()
        
    def generate_verse(self, theme='success', flow='trap', bars=16):
        """
        Generate a complete verse
        """
        verse = []
        rhyme_scheme = self._get_rhyme_scheme(flow, bars)
        current_rhyme = None
        
        for bar in range(bars):
            if bar % 4 == 0:  # New rhyme every 4 bars
                current_rhyme = self._get_new_rhyme()
            
            line = self._generate_bar(
                theme=theme,
                flow=flow,
                rhyme=current_rhyme
            )
            verse.append(line)
            
        return verse
        
    def _generate_bar(self, theme, flow, rhyme):
        """
        Generate a single bar with flow and rhyme
        """
        pattern = random.choice(self.flow_patterns[flow])
        words = self._select_words(theme, pattern['syllables'])
        
        # Ensure last word rhymes
        words[-1] = self._find_rhyming_word(rhyme, theme)
        
        return ' '.join(words)
        
    def freestyle_generator(self, beat_pattern):
        """
        Generate lyrics that match the beat pattern
        """
        while True:
            for hit in beat_pattern:
                if hit == 1:
                    yield self._generate_bar(
                        theme='freestyle',
                        flow='dynamic',
                        rhyme=None
                    )
                else:
                    yield None