# filter_processor.py
import numpy as np
from scipy import signal
import librosa

class FilterBank:
    """
    Multi-band filter processing like a master EQ rack
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.bands = {
            'sub': (20, 60),
            'bass': (60, 250),
            'low_mids': (250, 2000),
            'high_mids': (2000, 6000),
            'highs': (6000, 20000)
        }

    def split_bands(self, audio):
        """
        Split audio into frequency bands like a multiband processor
        """
        bands_output = {}
        for name, (low, high) in self.bands.items():
            # Create bandpass filter
            b, a = signal.butter(4, [low/(self.sr/2), high/(self.sr/2)], btype='band')
            # Apply filter
            bands_output[name] = signal.filtfilt(b, a, audio)
        return bands_output

    def process_bands(self, audio, processors=None):
        """
        Process each band separately with custom effects
        """
        if processors is None:
            processors = {band: lambda x: x for band in self.bands.keys()}
        
        bands = self.split_bands(audio)
        processed = np.zeros_like(audio)
        
        for band_name, processor in processors.items():
            processed += processor(bands[band_name])
        
        return processed