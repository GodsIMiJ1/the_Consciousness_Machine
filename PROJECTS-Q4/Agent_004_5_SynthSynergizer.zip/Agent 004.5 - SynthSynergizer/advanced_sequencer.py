# advanced_sequencer.py
import numpy as np
import random
from typing import Dict, List, Tuple

class AdvancedSequencer:
    """
    Next-level sequencer with probability and modulation
    Like having an MPC and modular synth in one
    """
    def __init__(self, bpm=120):
        self.bpm = bpm
        self.tracks = {}
        self.modulation_sources = {}
        self.step_length = 60 / bpm / 4  # 16th notes
        
    def add_track(self, name: str, steps: int = 16):
        """
        Add a track with probability and modulation
        """
        self.tracks[name] = {
            'pattern': [(0, 1.0, {}) for _ in range(steps)],  # (trigger, probability, params)
            'modulation': {},
            'effects': []
        }
        
    def set_step(self, track: str, step: int, probability: float = 1.0, **params):
        """
        Set step properties with parameter locks like Elektron gear
        """
        if track in self.tracks and step < len(self.tracks[track]['pattern']):
            self.tracks[track]['pattern'][step] = (1, probability, params)
            
    def add_modulation(self, track: str, param: str, source: str, amount: float):
        """
        Add modulation like a modular synth patch
        """
        if track in self.tracks:
            self.tracks[track]['modulation'][param] = (source, amount)
            
    def generate_sequence(self, length_bars: int = 1) -> Dict[str, List[Tuple]]:
        """
        Generate sequence with all probability and modulation
        """
        sequence = {}
        steps_per_bar = 16
        total_steps = length_bars * steps_per_bar
        
        for track_name, track in self.tracks.items():
            sequence[track_name] = []
            pattern_length = len(track['pattern'])
            
            for step in range(total_steps):
                current_step = step % pattern_length
                trigger, prob, params = track['pattern'][current_step]
                
                # Apply probability
                if trigger and random.random() < prob:
                    # Apply modulation
                    modulated_params = params.copy()
                    for param, (source, amount) in track['modulation'].items():
                        mod_value = self.get_modulation_value(source, step) * amount
                        modulated_params[param] = params.get(param, 0) + mod_value
                        
                    sequence[track_name].append((step, modulated_params))
                    
        return sequence