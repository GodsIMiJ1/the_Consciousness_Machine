# synthesis_engine.py
import numpy as np
from scipy import signal

class WavetableSynth:
    """
    Advanced wavetable synthesis engine
    """
    def __init__(self, sr=44100, table_size=2048):
        self.sr = sr
        self.table_size = table_size
        self.wavetables = self._create_wavetables()
        
    def _create_wavetables(self):
        """
        Create basic wavetables
        """
        t = np.linspace(0, 1, self.table_size)
        tables = {
            'sine': np.sin(2 * np.pi * t),
            'saw': 2 * (t - np.round(t)),
            'square': np.sign(np.sin(2 * np.pi * t)),
            'triangle': 4 * abs(t - np.round(t)) - 1
        }
        
        # Add harmonics to make it more interesting
        for name in list(tables.keys()):
            rich_wave = tables[name].copy()
            for i in range(2, 8):
                rich_wave += tables[name][::i] / i
            tables[f'rich_{name}'] = rich_wave / np.max(abs(rich_wave))
            
        return tables
        
    def morph_wavetables(self, table1, table2, amount):
        """
        Morph between two wavetables
        """
        return (1 - amount) * table1 + amount * table2
        
    def generate_note(self, freq, duration, wave_type='rich_saw'):
        """
        Generate a note using wavetable synthesis
        """
        # Calculate phase increment
        phase_inc = freq * self.table_size / self.sr
        
        # Generate indexes into wavetable
        n_samples = int(duration * self.sr)
        indexes = np.arange(n_samples) * phase_inc
        indexes = indexes.astype(int) % self.table_size
        
        # Look up values in wavetable
        wave = self.wavetables[wave_type][indexes]
        
        # Apply envelope
        envelope = np.exp(-3 * np.linspace(0, 1, n_samples))
        return wave * envelope