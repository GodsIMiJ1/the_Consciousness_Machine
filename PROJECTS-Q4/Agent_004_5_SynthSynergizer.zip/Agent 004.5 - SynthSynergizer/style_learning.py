# style_learning.py
import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List

class StyleLearningSystem:
    """
    Advanced style learning and generation
    Like having an AI that understands your production style
    """
    def __init__(self):
        self.style_models = {}
        self.feature_extractors = {}
        self.pattern_memory = PatternMemory()
        
    def learn_style(self, audio: np.ndarray, style_name: str):
        """
        Learn new production style
        """
        # Extract features
        features = self._extract_style_features(audio)
        
        # Update or create style model
        if style_name in self.style_models:
            self.style_models[style_name].update(features)
        else:
            self.style_models[style_name] = StyleModel(features)
            
        # Store patterns
        patterns = self._extract_patterns(audio)
        self.pattern_memory.store(style_name, patterns)
        
    def generate_in_style(self, style_name: str, 
                         length_seconds: float) -> np.ndarray:
        """
        Generate audio in learned style
        """
        if style_name not in self.style_models:
            raise ValueError(f"Style {style_name} not found")
            
        # Get style parameters
        params = self.style_models[style_name].get_params()
        
        # Generate base audio
        audio = self._generate_base_audio(length_seconds, params)
        
        # Apply style patterns
        patterns = self.pattern_memory.get_patterns(style_name)
        audio = self._apply_patterns(audio, patterns)
        
        return audio