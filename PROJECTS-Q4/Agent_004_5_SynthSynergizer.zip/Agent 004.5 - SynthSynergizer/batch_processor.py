# Agent 004.5 - SynthSynergizer/batch_processor.py

import os
import librosa
import numpy as np
from typing import List, Callable

class BatchProcessor:
    """
    The master mixing board for handling multiple audio files
    """
    def __init__(self, input_dir: str, output_dir: str):
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.supported_formats = ['.wav', '.mp3', '.flac']
        
    def get_audio_files(self) -> List[str]:
        """
        Scans the input directory like searching through your sample library
        """
        audio_files = []
        for file in os.listdir(self.input_dir):
            if any(file.endswith(fmt) for fmt in self.supported_formats):
                audio_files.append(os.path.join(self.input_dir, file))
        return audio_files

    def process_batch(self, processor_func: Callable):
        """
        Runs your custom processing function on each track
        Like applying the same effect to multiple channels
        """
        for audio_file in self.get_audio_files():
            try:
                # Load the audio like dropping a sample into your DAW
                audio, sr = librosa.load(audio_file)
                
                # Process it with your custom function
                processed = processor_func(audio, sr)
                
                # Save the processed heat
                output_path = os.path.join(
                    self.output_dir, 
                    f"processed_{os.path.basename(audio_file)}"
                )
                self.save_audio(processed, sr, output_path)
                
            except Exception as e:
                print(f"Yo, we hit a snag with {audio_file}: {str(e)}")

    @staticmethod
    def save_audio(audio: np.ndarray, sr: int, output_path: str):
        """
        Saves the processed audio like bouncing a track
        """
        # Add saving logic here (we'll implement this next)
        pass
