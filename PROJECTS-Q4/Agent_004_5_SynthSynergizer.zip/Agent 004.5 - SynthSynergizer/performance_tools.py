# performance_tools.py
import numpy as np
import threading
import queue
import time

class LoopStation:
    """
    Live looping and performance tools like a one-man band
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.loops = {}
        self.active_loops = set()
        self.master_clock = 0
        self.is_playing = False
        self.output_queue = queue.Queue()
        
    def add_loop(self, audio, name, bars=4):
        """
        Add a loop to the station
        """
        self.loops[name] = {
            'audio': audio,
            'bars': bars,
            'active': False
        }
        
    def toggle_loop(self, name):
        """
        Toggle loop on/off in real-time
        """
        if name in self.loops:
            if name in self.active_loops:
                self.active_loops.remove(name)
            else:
                self.active_loops.add(name)
                
    def start_playback(self):
        """
        Start the loop station
        """
        self.is_playing = True
        threading.Thread(target=self._playback_loop).start()
        
    def _playback_loop(self):
        """
        Main playback loop
        """
        while self.is_playing:
            mix = np.zeros(self.sr // 2)  # 0.5s buffer
            
            for name in self.active_loops:
                loop = self.loops[name]
                position = self.master_clock % len(loop['audio'])
                chunk = loop['audio'][position:position + len(mix)]
                
                # Loop around if needed
                if len(chunk) < len(mix):
                    chunk = np.concatenate([chunk, 
                             loop['audio'][:len(mix)-len(chunk)]])
                    
                mix += chunk
                
            self.output_queue.put(mix)
            self.master_clock += len(mix)
            time.sleep(0.1)  # Prevent CPU overload