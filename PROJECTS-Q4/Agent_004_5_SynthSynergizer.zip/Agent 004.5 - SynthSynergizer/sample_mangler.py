# sample_mangler.py
import numpy as np
import librosa
from scipy import signal
import random

class SampleMangler:
    """
    Sample chopping and mangling like an MPC on steroids
    """
    def __init__(self, sr=44100):
        self.sr = sr
        
    def chop_sample(self, audio, n_slices=8):
        """
        Chop sample into pieces like classic MPC style
        """
        slice_length = len(audio) // n_slices
        slices = [audio[i:i+slice_length] for i in range(0, len(audio), slice_length)]
        return slices[:n_slices]  # Ensure we only return n_slices
        
    def rearrange_slices(self, slices, pattern=None):
        """
        Rearrange slices like finger drumming
        """
        if pattern is None:
            pattern = list(range(len(slices)))
            random.shuffle(pattern)
            
        return np.concatenate([slices[i] for i in pattern])
        
    def time_stretch_slices(self, slices, stretch_factors=None):
        """
        Apply different time stretches to each slice
        """
        if stretch_factors is None:
            stretch_factors = [random.uniform(0.5, 2.0) for _ in slices]
            
        stretched = [librosa.effects.time_stretch(s, rate=r) 
                    for s, r in zip(slices, stretch_factors)]
        return stretched
        
    def glitch_slice(self, audio, severity=0.5):
        """
        Add glitch effects like digital artifacts
        """
        # Randomly replace samples with noise
        glitch_points = np.random.random(len(audio)) < severity/10
        audio[glitch_points] = np.random.random(sum(glitch_points))
        
        # Add some bit-crushing
        bits = int(16 - severity * 14)  # Between 2 and 16 bits
        audio = np.round(audio * (2**bits)) / (2**bits)
        
        return audio