# beat_composer.py
import numpy as np
import torch
import torch.nn as nn
from typing import Dict, List

class BeatComposer:
    """
    AI-powered beat composition system
    Like having an AI producer in the studio
    """
    def __init__(self, style='trap'):
        self.style = style
        self.patterns = {
            'trap': {
                'kick_patterns': self._generate_kick_patterns(),
                'snare_patterns': self._generate_snare_patterns(),
                'hat_patterns': self._generate_hat_patterns()
            }
        }
        self.variation_engine = VariationGenerator()
        
    def _generate_kick_patterns(self):
        """
        Generate kick patterns based on style
        """
        base_patterns = [
            [1,0,0,0, 0,0,1,0, 0,0,0,0, 1,0,0,0],  # Classic trap
            [1,0,0,1, 0,0,0,0, 1,0,0,0, 0,1,0,0],  # Bouncy
            [1,0,0,0, 1,0,0,0, 1,0,0,1, 0,0,0,0]   # Aggressive
        ]
        return self.variation_engine.create_variations(base_patterns)
        
    def compose_beat(self, length_bars=4, complexity=0.7):
        """
        Compose a full beat with variations
        """
        composition = {
            'kick': self._compose_track('kick', length_bars, complexity),
            'snare': self._compose_track('snare', length_bars, complexity),
            'hats': self._compose_track('hat', length_bars, complexity),
            'variations': self._generate_variations(length_bars)
        }
        return composition

class VariationGenerator:
    """
    Generate variations of patterns
    """
    def create_variations(self, patterns, num_variations=4):
        variations = []
        for pattern in patterns:
            for _ in range(num_variations):
                variation = self._apply_variation(pattern)
                variations.append(variation)
        return variations + patterns
        
    def _apply_variation(self, pattern):
        variation = pattern.copy()
        # Apply random variations while keeping the groove
        for i in range(len(variation)):
            if np.random.random() < 0.2:  # 20% chance of variation
                if variation[i] == 1:
                    # Add ghost note or remove hit
                    variation[i] = np.random.choice([0, 0.5])
                else:
                    # Add new hit
                    variation[i] = np.random.choice([0, 1], p=[0.7, 0.3])
        return variation