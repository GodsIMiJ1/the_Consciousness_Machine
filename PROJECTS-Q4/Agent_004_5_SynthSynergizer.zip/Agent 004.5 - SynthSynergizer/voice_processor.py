# voice_processor.py
import numpy as np
import librosa
from scipy import signal

class VoiceProcessor:
    """
    Voice processing rack for that robot talk and auto-tune vibes
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.formant_freqs = {
            'a': [730, 1090, 2440],
            'e': [500, 1840, 2480],
            'i': [270, 2290, 3010],
            'o': [450, 800, 2830],
            'u': [325, 700, 2700]
        }

    def vocoder(self, voice, carrier, n_bands=24):
        """
        Classic vocoder effect like Daft Punk
        """
        # Split into frequency bands
        bands = []
        for i in range(n_bands):
            freq = 100 * (2 ** (i/4))  # logarithmic spacing
            b, a = signal.butter(4, freq/(self.sr/2), 'low')
            voice_band = signal.filtfilt(b, a, voice)
            carrier_band = signal.filtfilt(b, a, carrier)
            envelope = np.abs(signal.hilbert(voice_band))
            bands.append(carrier_band * envelope)
        return np.sum(bands, axis=0)

    def autotune(self, audio, scale=['C', 'D', 'E', 'F', 'G', 'A', 'B']):
        """
        Auto-tune effect for that modern vocal sound
        """
        # Extract pitch
        f0, voiced_flag, _ = librosa.pyin(audio, 
                                        fmin=librosa.note_to_hz('C2'),
                                        fmax=librosa.note_to_hz('C7'))
        
        # Snap to scale
        tuned = f0.copy()
        for i in range(len(f0)):
            if voiced_flag[i]:
                note = librosa.hz_to_note(f0[i])
                if note[:-1] not in scale:  # ignore octave number
                    closest = min(scale, key=lambda x: 
                                abs(librosa.note_to_hz(x+'4') - f0[i]))
                    tuned[i] = librosa.note_to_hz(closest+'4')
        
        return librosa.effects.pitch_shift(audio, sr=self.sr, 
                                         n_steps=tuned-f0)