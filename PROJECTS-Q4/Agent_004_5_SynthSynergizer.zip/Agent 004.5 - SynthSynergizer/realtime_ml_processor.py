# realtime_ml_processor.py
import numpy as np
import torch
import torch.nn as nn
from collections import deque
import threading
import queue

class RealtimeMLProcessor:
    """
    Real-time ML audio processing
    Like having an AI assistant in your signal chain
    """
    def __init__(self, model_path: str = None, 
                 buffer_size: int = 1024):
        self.buffer_size = buffer_size
        self.input_buffer = deque(maxlen=buffer_size)
        self.output_queue = queue.Queue()
        self.model = self._load_model(model_path)
        self.processing_thread = None
        self.running = False
        
    def _load_model(self, model_path):
        """
        Load ML model for processing
        """
        # Default to simple neural FX if no model provided
        if model_path is None:
            return nn.Sequential(
                nn.Linear(self.buffer_size, self.buffer_size * 2),
                nn.ReLU(),
                nn.Linear(self.buffer_size * 2, self.buffer_size),
                nn.Tanh()
            )
        return torch.load(model_path)
        
    def start_processing(self):
        """
        Start real-time processing thread
        """
        self.running = True
        self.processing_thread = threading.Thread(
            target=self._processing_loop
        )
        self.processing_thread.start()
        
    def _processing_loop(self):
        """
        Main processing loop
        """
        while self.running:
            if len(self.input_buffer) >= self.buffer_size:
                # Process buffer through ML model
                input_data = np.array(list(self.input_buffer))
                with torch.no_grad():
                    processed = self.model(
                        torch.FloatTensor(input_data)
                    ).numpy()
                self.output_queue.put(processed)
                self.input_buffer.clear()
                
    def process_sample(self, sample: float) -> float:
        """
        Process a single sample
        """
        self.input_buffer.append(sample)
        
        if not self.output_queue.empty():
            return self.output_queue.get()
        return sample