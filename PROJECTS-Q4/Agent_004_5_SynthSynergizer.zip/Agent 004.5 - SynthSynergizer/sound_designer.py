# sound_designer.py
import numpy as np
from scipy import signal
import random

class SoundDesigner:
    """
    Create custom synthesized sounds and textures
    """
    def __init__(self, sr=44100):
        self.sr = sr
        
    def create_pad(self, duration=1.0, base_freq=440):
        """
        Create atmospheric pad sound
        """
        t = np.linspace(0, duration, int(self.sr * duration))
        
        # Multiple detuned oscillators
        oscillators = []
        for i in range(6):
            detune = random.uniform(0.99, 1.01)
            phase = random.uniform(0, 2*np.pi)
            osc = np.sin(2 * np.pi * base_freq * detune * t + phase)
            oscillators.append(osc)
            
        # Mix oscillators
        pad = sum(oscillators) / len(oscillators)
        
        # Apply filtering
        b, a = signal.butter(4, 2000/(self.sr/2), 'low')
        pad = signal.filtfilt(b, a, pad)
        
        # Add slow modulation
        mod = np.sin(2 * np.pi * 0.5 * t)
        pad = pad * (1 + 0.1 * mod)
        
        return pad
        
    def create_impact(self, duration=0.5):
        """
        Create impact/hit sound effect
        """
        t = np.linspace(0, duration, int(self.sr * duration))
        
        # Noise burst with pitch envelope
        noise = np.random.normal(0, 1, len(t))
        freq_env = np.exp(-10 * t)
        filtered_noise = []
        
        for i in range(len(t)):
            cutoff = 2000 * freq_env[i]
            b, a = signal.butter(4, cutoff/(self.sr/2), 'low')
            filtered_noise.append(signal.filtfilt(b, a, noise[i]))
            
        impact = np.array(filtered_noise)
        
        # Apply amplitude envelope
        amp_env = np.exp(-5 * t)
        impact = impact * amp_env
        
        return impact