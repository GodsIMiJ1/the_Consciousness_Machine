# Agent 004.5 - SynthSynergizer/audio_processors.py

import librosa
import numpy as np
from scipy import signal
import soundfile as sf

class AudioProcessors:
    """
    Your rack of audio effects ready to process those beats
    """
    @staticmethod
    def pitch_shift(audio: np.ndarray, sr: int, steps: int = 4) -> np.ndarray:
        """
        Shift pitch like turning a synth knob
        """
        return librosa.effects.pitch_shift(y=audio, sr=sr, n_steps=steps)

    @staticmethod
    def time_stretch(audio: np.ndarray, sr: int, rate: float = 1.2) -> np.ndarray:
        """
        Stretch time like working with BPM
        """
        return librosa.effects.time_stretch(y=audio, rate=rate)

    @staticmethod
    def apply_fx_chain(audio: np.ndarray, sr: int, fx_chain: list) -> np.ndarray:
        """
        Stack effects like a producer's chain
        """
        processed = audio.copy()
        for fx in fx_chain:
            processed = fx(processed, sr)
        return processed

    @staticmethod
    def add_reverb(audio: np.ndarray, sr: int, reverb_time: float = 2.0) -> np.ndarray:
        """
        Add reverb like you're in a huge studio
        """
        reverb_len = int(sr * reverb_time)
        impulse_response = np.exp(-6.0 * np.linspace(0, reverb_time, reverb_len))
        return signal.convolve(audio, impulse_response, mode='same')

    @staticmethod
    def normalize(audio: np.ndarray) -> np.ndarray:
        """
        Normalize levels like mastering
        """
        return librosa.util.normalize(audio)

