# rhythm_processor.py
import numpy as np
import librosa

class RhythmAnalyzer:
    """
    Beat detection and rhythm analysis tools
    """
    def __init__(self, sr=44100):
        self.sr = sr

    def detect_beats(self, audio):
        """
        Find the beats like counting bars
        """
        tempo, beats = librosa.beat.beat_track(y=audio, sr=self.sr)
        beat_times = librosa.frames_to_time(beats, sr=self.sr)
        return tempo, beat_times

    def analyze_groove(self, audio):
        """
        Analyze the groove and swing
        """
        onset_env = librosa.onset.onset_strength(y=audio, sr=self.sr)
        pulse = librosa.beat.plp(onset_envelope=onset_env, sr=self.sr)
        return {
            'pulse': pulse,
            'groove_pattern': np.diff(pulse),
            'swing_ratio': np.mean(pulse[::2]) / np.mean(pulse[1::2])
        }

    def quantize_audio(self, audio, strength=0.5):
        """
        Quantize audio to the grid like MPC timing
        """
        tempo, beats = self.detect_beats(audio)
        beat_frames = librosa.time_to_frames(beats, sr=self.sr)
        
        # Create quantization grid
        grid = np.zeros_like(audio)
        for beat in beat_frames:
            if beat < len(audio):
                grid[beat] = 1
                
        return audio * (1-strength) + grid * strength