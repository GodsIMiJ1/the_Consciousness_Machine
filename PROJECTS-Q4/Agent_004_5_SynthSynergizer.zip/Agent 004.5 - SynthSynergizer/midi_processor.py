# midi_processor.py
import mido
import threading
import queue

class MIDIController:
    """
    MIDI control system for real-time parameter tweaking
    """
    def __init__(self):
        self.parameter_map = {}
        self.midi_queue = queue.Queue()
        self.running = False

    def start_midi_listener(self, port_name=None):
        """
        Start listening for MIDI control changes
        """
        self.running = True
        if port_name is None:
            # Use first available port
            ports = mido.get_input_names()
            if ports:
                port_name = ports[0]
            else:
                raise ValueError("No MIDI ports available")

        def midi_loop():
            with mido.open_input(port_name) as port:
                while self.running:
                    for msg in port.iter_pending():
                        if msg.type == 'control_change':
                            self.midi_queue.put(msg)

        self.midi_thread = threading.Thread(target=midi_loop)
        self.midi_thread.start()

    def map_parameter(self, cc_number, parameter_name, value_range=(0, 1)):
        """
        Map MIDI CC to parameter like mapping knobs in your DAW
        """
        self.parameter_map[cc_number] = {
            'name': parameter_name,
            'range': value_range
        }

    def get_parameter_updates(self):
        """
        Get the latest parameter updates from MIDI
        """
        updates = {}
        while not self.midi_queue.empty():
            msg = self.midi_queue.get()
            if msg.control in self.parameter_map:
                param = self.parameter_map[msg.control]
                min_val, max_val = param['range']
                normalized = msg.value / 127.0
                value = min_val + (max_val - min_val) * normalized
                updates[param['name']] = value
        return updates