# chord_generator.py
import numpy as np
import torch
import torch.nn as nn

class ChordProgressionGenerator:
    """
    Generate chord progressions using neural networks
    Like having a jazz pianist in your pocket
    """
    def __init__(self):
        self.chord_vocab = self._initialize_chord_vocab()
        self.progression_model = self._build_model()
        
    def _initialize_chord_vocab(self):
        """
        Initialize chord vocabulary
        """
        return {
            'major': ['C', 'Dm', 'Em', 'F', 'G', 'Am', 'Bdim'],
            'minor': ['Cm', 'Ddim', 'Eb', 'Fm', 'Gm', 'Ab', 'Bb'],
            'jazz': ['Cmaj7', 'Dm7', 'Em7', 'Fmaj7', 'G7', 'Am7', 'Bm7b5']
        }
        
    def generate_progression(self, style='trap', length=4):
        """
        Generate a chord progression
        """
        if style == 'trap':
            # Trap often uses minor progressions
            chords = self.chord_vocab['minor']
            # Common trap progression patterns
            patterns = [
                [0, 3, 4, 3],  # i-iv-v-iv
                [0, 4, 3, 0],  # i-v-iv-i
                [0, 5, 3, 4]   # i-vi-iv-v
            ]
            pattern = np.random.choice(patterns)
            return [chords[i] for i in pattern]
            
    def add_extensions(self, progression):
        """
        Add chord extensions for flavor
        """
        extended = []
        for chord in progression:
            if np.random.random() < 0.3:  # 30% chance of extension
                if 'm' not in chord:  # Major chord
                    ext = np.random.choice(['maj7', '6', 'maj9'])
                else:  # Minor chord
                    ext = np.random.choice(['m7', 'm9', 'm11'])
                extended.append(f"{chord}{ext}")
            else:
                extended.append(chord)
        return extended