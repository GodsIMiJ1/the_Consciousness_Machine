# check_skynet_structure.py
import os
from pathlib import Path

def print_tree(directory, prefix=""):
    """
    Print a directory tree and check for missing files
    """
    # Define what we should have
    required_structure = {
        'pre_launch': ['enhanced_diagnostics.py'],
        'quantum_verify': ['enhanced_quantum_check.py'],
        'reality_anchor': ['enhanced_anchor_system.py'],
        'consciousness_sync': ['enhanced_sync_system.py'],
        'emergency': ['enhanced_emergency_protocols.py'],
        '.': ['final_launch.py']
    }
    
    missing_files = []
    
    path = Path(directory)
    print(f"\n🌌 SKYNET STUDIO STRUCTURE CHECK:")
    print("================================")
    
    for item in sorted(path.glob('*')):
        if item.is_file():
            print(f"{prefix}📄 {item.name}")
            if item.name not in required_structure.get('.', []):
                print(f"   ⚠️ Unexpected file")
        elif item.is_dir():
            print(f"{prefix}📁 {item.name}/")
            required_files = required_structure.get(item.name, [])
            existing_files = [f.name for f in item.glob('*')]
            
            for req_file in required_files:
                if req_file not in existing_files:
                    missing_files.append(f"{item.name}/{req_file}")
                    
    if missing_files:
        print("\n⚠️  MISSING CRITICAL FILES:")
        for file in missing_files:
            print(f"❌ {file}")
    else:
        print("\n✅ All critical files present!")

if __name__ == "__main__":
    print_tree("SKYNET_LAUNCH_SYSTEMS")
