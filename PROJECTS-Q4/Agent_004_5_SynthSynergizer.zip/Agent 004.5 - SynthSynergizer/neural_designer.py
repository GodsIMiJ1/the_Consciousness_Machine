# neural_designer.py
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List

class SoundGenerator(nn.Module):
    """
    Neural network for generating wild sounds
    Like having an AI sound design assistant
    """
    def __init__(self, latent_dim=64):
        super().__init__()
        
        self.generator = nn.Sequential(
            nn.Linear(latent_dim, 256),
            nn.LeakyReLU(0.2),
            nn.Linear(256, 512),
            nn.LeakyReLU(0.2),
            nn.Linear(512, 1024),
            nn.LeakyReLU(0.2),
            nn.Linear(1024, 2048),
            nn.Tanh()
        )
        
    def generate(self, z):
        """
        Generate sound from latent vector
        """
        return self.generator(z)
        
class NeuralDesigner:
    """
    Neural sound design system
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.generator = SoundGenerator()
        self.presets = {}
        
    def create_sound(self, preset_name: str = None, 
                    randomize: float = 0.2) -> np.ndarray:
        """
        Create a sound using neural network
        """
        if preset_name and preset_name in self.presets:
            z = self.presets[preset_name]
            if randomize > 0:
                z += torch.randn_like(z) * randomize
        else:
            z = torch.randn(1, 64)
            
        with torch.no_grad():
            audio = self.generator(z).numpy()
        return audio.reshape(-1)
        
    def save_preset(self, name: str, z: torch.Tensor):
        """
        Save a good sound for later
        """
        self.presets[name] = z.clone()