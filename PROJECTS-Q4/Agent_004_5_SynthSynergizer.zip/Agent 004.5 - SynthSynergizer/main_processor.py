# main_processor.py

from enhanced_batch_processor import EnhancedBatchProcessor
from audio_processors import AudioProcessors

def create_processing_chain(audio, sr):
    """
    Create your custom processing chain
    Like setting up your favorite effect chain
    """
    # Initialize our audio toolkit
    fx = AudioProcessors()
    
    # Create a processing chain
    processed = audio.copy()
    
    # Apply effects in sequence
    processed = fx.normalize(processed)
    processed = fx.pitch_shift(processed, sr, steps=2)
    processed = fx.add_reverb(processed, sr, reverb_time=1.5)
    
    return processed

# Set up the processor with your directories
processor = EnhancedBatchProcessor(
    input_dir="raw_beats",
    output_dir="processed_heat"
)

# Let it cook! 🔥
processor.process_batch_with_progress(create_processing_chain)
