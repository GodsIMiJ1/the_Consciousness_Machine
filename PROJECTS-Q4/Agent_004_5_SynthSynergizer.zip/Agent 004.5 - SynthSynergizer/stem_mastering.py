# stem_mastering.py
import numpy as np
from typing import Dict, List

class StemMasteringProcessor:
    """
    Process stems for mastering
    Like having separate control over every element
    """
    def __init__(self, sr=44100):
        self.sr = sr
        self.stem_processors = {}
        
    def add_stem(self, name: str, audio: np.ndarray,
                processor_type: str = 'default'):
        """
        Add a stem for processing
        """
        self.stem_processors[name] = {
            'audio': audio,
            'type': processor_type,
            'settings': self._get_default_settings(processor_type)
        }
        
    def process_stems(self) -> np.ndarray:
        """
        Process all stems and sum
        """
        processed_stems = {}
        
        for name, stem in self.stem_processors.items():
            processed = self._process_stem(
                stem['audio'],
                stem['type'],
                stem['settings']
            )
            processed_stems[name] = processed
            
        # Intelligent stem summing
        return self._smart_sum(processed_stems)
        
    def _smart_sum(self, stems: Dict[str, np.ndarray]) -> np.ndarray:
        """
        Sum stems with intelligent gain staging
        """
        # Analyze frequency content
        stem_spectrums = {
            name: np.abs(librosa.stft(audio))
            for name, audio in stems.items()
        }
        
        # Apply intelligent gains
        gains = self._calculate_stem_gains(stem_spectrums)
        
        # Sum with calculated gains
        summed = sum(audio * gains[name] 
                    for name, audio in stems.items())
                    
        return summed