# mixing_console.py
import numpy as np
from typing import Dict, List
import threading
import queue

class MixingConsole:
    """
    Complete mixing console with routing
    Like having an SSL in the box
    """
    def __init__(self, num_channels=8):
        self.num_channels = num_channels
        self.channels = self._initialize_channels()
        self.buses = {'A': [], 'B': [], 'C': [], 'D': []}
        self.master = MasterChannel()
        
    def _initialize_channels(self) -> Dict:
        return {
            i: Channel(id=i) for i in range(self.num_channels)
        }
        
    def process_audio(self, audio_dict: Dict[int, np.ndarray]) -> np.ndarray:
        """
        Process audio through the console
        """
        # Process each channel
        bus_sums = {bus: 0 for bus in self.buses.keys()}
        
        for channel_id, audio in audio_dict.items():
            if channel_id in self.channels:
                # Process channel strip
                processed = self.channels[channel_id].process(audio)
                
                # Route to buses
                for bus, channels in self.buses.items():
                    if channel_id in channels:
                        bus_sums[bus] += processed
                        
        # Sum all buses
        mixed = sum(bus_sums.values())
        
        # Process through master
        return self.master.process(mixed)

class Channel:
    """
    Single channel strip
    """
    def __init__(self, id: int):
        self.id = id
        self.input_gain = 1.0
        self.eq = ParametricEQ()
        self.compressor = Compressor()
        self.sends = {'A': 0, 'B': 0, 'C': 0, 'D': 0}
        self.pan = 0.0
        self.fader = 1.0
        
    def process(self, audio: np.ndarray) -> np.ndarray:
        """
        Process audio through channel strip
        """
        processed = audio * self.input_gain
        processed = self.eq.process(processed)
        processed = self.compressor.process(processed)
        processed = self._apply_pan(processed)
        return processed * self.fader