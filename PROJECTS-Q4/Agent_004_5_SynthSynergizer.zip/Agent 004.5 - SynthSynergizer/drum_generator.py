# drum_generator.py
import numpy as np
import random
from typing import Dict, List

class DrumGenerator:
    """
    Create sick drum patterns like a rhythm scientist
    """
    def __init__(self, bpm=120):
        self.bpm = bpm
        self.patterns = {
            'trap': {
                'kick': [1,0,0,0, 0,0,1,0, 0,0,0,0, 1,0,0,0],
                'snare': [0,0,0,0, 1,0,0,0, 0,0,0,0, 1,0,0,0],
                'hihat': [1,0,1,0, 1,0,1,0, 1,0,1,0, 1,0,1,0]
            },
            'boom_bap': {
                'kick': [1,0,0,1, 0,0,1,0, 0,1,0,0, 1,0,0,0],
                'snare': [0,0,1,0, 0,0,1,0, 0,0,1,0, 0,0,1,0],
                'hihat': [1,1,1,1, 1,1,1,1, 1,1,1,1, 1,1,1,1]
            }
        }
        
    def generate_pattern(self, style='trap', variation=0.2):
        """
        Generate a drum pattern with random variations
        """
        base_pattern = self.patterns[style].copy()
        
        # Add variations
        for drum in base_pattern:
            for i in range(len(base_pattern[drum])):
                if random.random() < variation:
                    # Add ghost notes or remove hits
                    if base_pattern[drum][i] == 1:
                        base_pattern[drum][i] = 0.5  # Ghost note
                    elif random.random() < 0.3:
                        base_pattern[drum][i] = 1  # Add hit
                        
        return base_pattern
        
    def humanize(self, pattern: Dict[str, List[float]], amount=0.1):
        """
        Add human feel to the pattern
        """
        humanized = {}
        for drum, hits in pattern.items():
            humanized[drum] = []
            for hit in hits:
                if hit > 0:
                    # Add slight timing and velocity variations
                    timing = random.uniform(-amount, amount)
                    velocity = hit * random.uniform(1-amount, 1)
                    humanized[drum].append((timing, velocity))
                else:
                    humanized[drum].append((0, 0))
                    
        return humanized