import os

def create_directories(base_path):
    directories = [
        os.path.join(base_path, "nancy_ai", "models"),
        os.path.join(base_path, "nancy_ai", "cache"),
        os.path.join(base_path, "nancy_ai", "logs"),
        os.path.join(base_path, "nancy_ai", "data"),
        os.path.join(base_path, "highlight_chat", "models"),
        os.path.join(base_path, "highlight_chat", "cache"),
        os.path.join(base_path, "highlight_chat", "logs"),
        os.path.join(base_path, "highlight_chat", "data"),
        os.path.join(base_path, "system", "shared", "configs"),
        os.path.join(base_path, "system", "shared", "security"),
        os.path.join(base_path, "system", "shared", "temp"),
        os.path.join(base_path, "system", "shared", "monitoring"),
        os.path.join(base_path, "backup", "backups", "nancy_ai"),
        os.path.join(base_path, "backup", "backups", "highlight_chat"),
        os.path.join(base_path, "backup", "backups", "system_logs"),
        os.path.join(base_path, "backup", "backups", "2025_02")
    ]
    
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
        print(f"Created: {directory}")

if __name__ == '__main__':
    # Using D drive since you're setting up for the new server
    base_path = "D:/"
    create_directories(base_path)
