import os
import json
from datetime import datetime

def verify_system_setup():
    status = {
        "checks": [],
        "all_good": True
    }
    
    # Paths to verify
    paths_to_check = {
        "Memory System": [
            "D:/highlight_chat/memory_system/personality/core_traits/personality_profile.json",
            "D:/highlight_chat/memory_system/memory/user_interactions/interaction_preferences.json",
            "D:/highlight_chat/memory_system/knowledge/learned_patterns/behavior_patterns.json"
        ],
        "Backup System": [
            "D:/backup/backups/highlight_chat/daily_memory_backups/personality",
            "D:/backup/backups/highlight_chat/weekly_personality_snapshots/core_traits",
            "D:/backup/backups/highlight_chat/monthly_knowledge_archives/user_preferences",
            "D:/backup/backups/highlight_chat/emergency_backups"
        ]
    }
    
    def check_path(path, is_file=True):
        if is_file:
            exists = os.path.isfile(path)
            readable = os.access(path, os.R_OK) if exists else False
            if exists and readable:
                try:
                    with open(path, 'r') as f:
                        json.load(f)
                    return True
                except:
                    return False
            return False
        else:
            return os.path.isdir(path)
    
    # Run checks
    print("🎵 Running system verification...")
    for system, paths in paths_to_check.items():
        print(f"\n📊 Checking {system}:")
        for path in paths:
            is_file = path.endswith('.json')
            result = check_path(path, is_file)
            status["checks"].append({"path": path, "status": result})
            status["all_good"] &= result
            print(f"{'✅' if result else '❌'} {os.path.basename(path)}")
    
    # Write verification report
    report_path = "D:/highlight_chat/memory_system/system_verification.json"
    verification_data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status": status["all_good"],
        "checks": status["checks"]
    }
    
    with open(report_path, 'w') as f:
        json.dump(verification_data, f, indent=4)
    
    return status["all_good"]

if __name__ == "__main__":
    try:
        all_good = verify_system_setup()
        print(f"\n{'🎮 System fully operational!' if all_good else '⚠️ Some checks failed!'}")
    except Exception as e:
        print(f"Error during verification: {str(e)}")
