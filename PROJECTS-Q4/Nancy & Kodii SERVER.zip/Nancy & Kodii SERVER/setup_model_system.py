import os
import json
from datetime import datetime

def setup_model_system():
    base_path = "D:/highlight_chat/models"
    
    # Define model categories and their specific models
    model_structure = {
        "language_models": {
            "llama": ["llama-3.1", "llama-3.2"],
            "deepseek": ["deepseek-r1", "deepseek-coder-v2"]
        },
        "vision_models": {
            "llama": ["llama-3.2-vision"],
            "other": ["bakllava", "cogvlm"]
        },
        "specialized": {
            "coding": ["deepseek-coder", "wizardcoder"],
            "creative": ["stable-lm", "playground"]
        }
    }
    
    # Create model configuration
    model_config = {
        "active_models": {
            "primary": "llama-3.2",
            "vision": "llama-3.2-vision",
            "coding": "deepseek-coder-v2"
        },
        "resource_allocation": {
            "llama-3.2": {"ram": "24GB", "priority": "high"},
            "llama-3.2-vision": {"ram": "24GB", "priority": "medium"},
            "deepseek-coder-v2": {"ram": "16GB", "priority": "medium"},
            "deepseek-r1": {"ram": "16GB", "priority": "low"}
        },
        "load_balancing": {
            "max_concurrent_models": 3,
            "auto_scale": True,
            "priority_override": False
        }
    }
    
    # Create directories and config files
    for category, subcategories in model_structure.items():
        for subcategory, models in subcategories.items():
            path = os.path.join(base_path, category, subcategory)
            os.makedirs(path, exist_ok=True)
            print(f"Created model directory: {path}")
            
            # Create placeholder for each model
            for model in models:
                model_path = os.path.join(path, model)
                os.makedirs(model_path, exist_ok=True)
                print(f"Created model space: {model_path}")
    
    # Save configuration file
    config_path = os.path.join(base_path, "model_config.json")
    with open(config_path, 'w') as f:
        json.dump(model_config, f, indent=4)
    print(f"\nCreated model configuration at: {config_path}")

if __name__ == "__main__":
    try:
        setup_model_system()
        print("\n🚀 Model system setup complete! Ready to load those beast models!")
    except Exception as e:
        print(f"Error during setup: {str(e)}")
