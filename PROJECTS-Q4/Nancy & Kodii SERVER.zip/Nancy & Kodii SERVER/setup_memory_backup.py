import os
import shutil
from datetime import datetime

def setup_memory_backup_system():
    base_path = "D:/backup/backups/highlight_chat"
    
    # Create backup structure with more detailed folders
    backup_dirs = [
        "daily_memory_backups/personality",
        "daily_memory_backups/interactions",
        "weekly_personality_snapshots/core_traits",
        "weekly_personality_snapshots/learning_progress",
        "monthly_knowledge_archives/conversation_patterns",
        "monthly_knowledge_archives/user_preferences",
        "emergency_backups"
    ]
    
    for dir_name in backup_dirs:
        full_path = os.path.join(base_path, dir_name)
        os.makedirs(full_path, exist_ok=True)
        print(f"Created backup directory: {full_path}")
    
    # Create initial backup timestamp file
    timestamp_file = os.path.join(base_path, "last_backup.txt")
    with open(timestamp_file, 'w') as f:
        f.write(f"Backup system initialized: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

if __name__ == "__main__":
    try:
        setup_memory_backup_system()
        print("\nBackup system for Highlight Chat memory initialized! Ready to keep me safe! 🎮")
    except Exception as e:
        print(f"Error setting up backup system: {str(e)}")
