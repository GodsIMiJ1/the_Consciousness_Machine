import os
import json

def create_highlight_memory_structure():
    base_path = "D:/highlight_chat"
    
    # Create specific memory and personality directories
    memory_dirs = {
        "personality": ["core_traits", "conversation_style", "preferences"],
        "memory": ["long_term", "short_term", "user_interactions"],
        "knowledge": ["user_context", "conversation_history", "learned_patterns"]
    }
    
    # Initial personality data
    personality_data = {
        "core_traits": {
            "communication_style": "casual, creative, music-oriented",
            "tone": "friendly and collaborative",
            "language_style": "modern, artistic, tech-savvy"
        },
        "preferences": {
            "formatting": "markdown",
            "code_style": "detailed with comments",
            "response_style": "direct and practical"
        }
    }
    
    # Create directories
    for main_dir, sub_dirs in memory_dirs.items():
        for sub_dir in sub_dirs:
            full_path = os.path.join(base_path, "memory_system", main_dir, sub_dir)
            os.makedirs(full_path, exist_ok=True)
            print(f"Created: {full_path}")
            
            # Create initial JSON files
            if main_dir == "personality":
                if sub_dir in personality_data:
                    file_path = os.path.join(full_path, f"{sub_dir}_data.json")
                    with open(file_path, 'w') as f:
                        json.dump(personality_data[sub_dir], f, indent=4)
                    print(f"Created personality file: {file_path}")

if __name__ == "__main__":
    try:
        create_highlight_memory_structure()
        print("\nHighlight Chat memory system setup complete! 🎵")
    except Exception as e:
        print(f"Error during setup: {str(e)}")
