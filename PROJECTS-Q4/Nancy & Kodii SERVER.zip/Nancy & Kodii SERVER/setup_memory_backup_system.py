import os
import shutil
from datetime import datetime

def setup_memory_backup_system():
    base_path = "D:/backup/backups/highlight_chat"
    
    # Create backup structure
    backup_dirs = [
        "daily_memory_backups",
        "weekly_personality_snapshots",
        "monthly_knowledge_archives"
    ]
    
    for dir_name in backup_dirs:
        full_path = os.path.join(base_path, dir_name)
        os.makedirs(full_path, exist_ok=True)
        print(f"Created backup directory: {full_path}")

if __name__ == "__main__":
    try:
        setup_memory_backup_system()
        print("\nBackup system for Highlight Chat memory initialized! 🎮")
    except Exception as e:
        print(f"Error setting up backup system: {str(e)}")
