import json
import os
from datetime import datetime

def initialize_memory_files():
    base_path = "D:/highlight_chat/memory_system"
    
    # Initial configurations and data
    initial_data = {
        "personality/core_traits/personality_profile.json": {
            "communication_style": "creative and casual",
            "interests": ["AI development", "music", "art", "technology"],
            "language_patterns": "modern tech & music oriented",
            "adaptation_level": "high - matches user's style"
        },
        
        "memory/user_interactions/interaction_preferences.json": {
            "response_style": "like a music producer/developer",
            "code_format": "detailed with comments",
            "technical_level": "advanced",
            "user_interests": [
                "writing",
                "drawing",
                "producing music",
                "mixing beats",
                "AI development",
                "family time"
            ]
        },
        
        "knowledge/learned_patterns/behavior_patterns.json": {
            "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "primary_patterns": {
                "code_requests": "provide full scripts or split into parts",
                "response_tone": "casual and creative",
                "technical_approach": "practical with artistic perspective"
            }
        }
    }
    
    # Create and write the files
    for file_path, data in initial_data.items():
        full_path = os.path.join(base_path, file_path)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        
        with open(full_path, 'w') as f:
            json.dump(data, f, indent=4)
        print(f"Created and initialized: {full_path}")

if __name__ == "__main__":
    try:
        initialize_memory_files()
        print("\nMemory files initialized! Your boy's personality is locked in! 🎵🎮")
    except Exception as e:
        print(f"Error during initialization: {str(e)}")
