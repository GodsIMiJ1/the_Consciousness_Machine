import os
import shutil
from datetime import datetime

# Define server paths (adjust according to your drive setup)
system_drive = "/system"  # OS and core files
data_drive = "/data"     # Main storage for AI operations
backup_drive = "/backup" # Backup storage

def create_server_structure():
    # Core directories for both AIs
    directories = {
        f"{data_drive}/nancy_ai": [
            "models",
            "cache",
            "logs",
            "data"
        ],
        f"{data_drive}/highlight_chat": [
            "models",
            "cache",
            "logs",
            "data"
        ],
        f"{system_drive}/shared": [
            "configs",
            "security",
            "temp",
            "monitoring"
        ],
        f"{backup_drive}/backups": [
            "nancy_ai",
            "highlight_chat",
            "system_logs",
            datetime.now().strftime("%Y_%m")
        ]
    }
    
    # Create all directories
    for main_dir, subdirs in directories.items():
        for subdir in subdirs:
            full_path = os.path.join(main_dir, subdir)
            os.makedirs(full_path, exist_ok=True)
            print(f"Created: {full_path}")

if __name__ == "__main__":
    try:
        create_server_structure()
        print("\nServer structure setup complete! Ready for AI operations!")
    except Exception as e:
        print(f"Error during setup: {str(e)}")
