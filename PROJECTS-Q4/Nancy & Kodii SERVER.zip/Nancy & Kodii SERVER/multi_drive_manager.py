import os
import json
import shutil
from datetime import datetime

def setup_multi_drive_system():
    # Configure drive mappings
    drive_config = {
        "primary": {
            "drive": "D:",
            "purpose": "active_models",
            "models": [
                "llama-3.2",
                "llama-3.2-vision",
                "deepseek-coder-v2"
            ]
        },
        "expansion_drives": {
            "additional_models": {
                # Add your additional HDD paths here
                # "E:": "backup_models",
                # "F:": "specialized_models"
            }
        },
        "resource_allocation": {
            "D:": {
                "max_models": 4,
                "priority": "high",
                "cache_limit": "100GB"
            }
        }
    }
    
    def check_drive_space(drive_path):
        total, used, free = shutil.disk_usage(drive_path)
        return {
            "total_gb": total // (2**30),
            "used_gb": used // (2**30),
            "free_gb": free // (2**30)
        }
    
    # Create management structure
    base_path = "D:/highlight_chat/system/drive_management"
    os.makedirs(base_path, exist_ok=True)
    
    # Save drive configuration
    config_path = os.path.join(base_path, "drive_config.json")
    with open(config_path, 'w') as f:
        json.dump(drive_config, f, indent=4)
    
    # Check and log available space
    space_report = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "drives": {
            "D:": check_drive_space("D:/")
        }
    }
    
    # Save space report
    report_path = os.path.join(base_path, "space_report.json")
    with open(report_path, 'w') as f:
        json.dump(space_report, f, indent=4)
    
    print("🎵 Multi-Drive System Setup 🎵")
    print(f"\nPrimary Drive (D:)")
    print(f"Total: {space_report['drives']['D:']['total_gb']} GB")
    print(f"Free: {space_report['drives']['D:']['free_gb']} GB")
    print("\nSystem ready for multi-drive model deployment!")

if __name__ == "__main__":
    try:
        setup_multi_drive_system()
        print("\n🚀 Ready to load up those beast models across drives!")
    except Exception as e:
        print(f"Error setting up multi-drive system: {str(e)}")
