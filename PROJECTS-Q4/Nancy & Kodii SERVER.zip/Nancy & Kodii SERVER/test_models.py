import ollama
import time

def test_model(model_name, test_prompt):
    print(f"\n🎵 Testing {model_name} 🎵")
    print("=" * 50)
    try:
        start_time = time.time()
        response = ollama.chat(model=model_name, messages=[
            {
                'role': 'user',
                'content': test_prompt
            }
        ])
        end_time = time.time()
        
        print(f"Response: {response['message']['content']}")
        print(f"\nResponse time: {end_time - start_time:.2f} seconds")
        print("✅ Test successful!")
    except Exception as e:
        print(f"❌ Error testing {model_name}: {str(e)}")

def run_tests():
    test_cases = {
        "llama2": "Write a quick 4 bar rap about coding AI",
        "deepseek-coder": "Write a simple Python function to create a directory"
    }
    
    print("🚀 Starting model tests...")
    
    for model, prompt in test_cases.items():
        test_model(model, prompt)

if __name__ == "__main__":
    run_tests()
