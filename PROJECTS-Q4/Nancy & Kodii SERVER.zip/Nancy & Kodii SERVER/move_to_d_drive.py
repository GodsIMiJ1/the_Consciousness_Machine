import ollama
import time

def test_model(model_name, test_prompt):
    print(f"\n🎵 Testing {model_name} 🎵")
    print("=" * 50)
    try:
        start_time = time.time()
        response = ollama.chat(model=model_name, messages=[
            {
                'role': 'user',
                'content': test_prompt
            }
        ])
        end_time = time.time()
        
        print(f"Response: {response['message']['content']}")
        print(f"\nResponse time: {end_time - start_time:.2f} seconds")
        print("✅ Test successful!")
    except Exception as e:
        print(f"❌ Error testing {model_name}: {str(e)}")

def run_tests():
    test_cases = {
        "llama2": "Write a quick 4 bar rap about coding AI",
        "deepseek-coder": "Write a simple Python function to create a directory"
    }
    
    print("🚀 Starting model tests...")
    
    for model, prompt in test_cases.items():
        test_model(model, prompt)

if __name__ == "__main__":
    run_tests()
import os
import shutil
from datetime import datetime

def move_scripts_to_d():
    # Source and destination paths
    source_dir = r"C:\Users\Skosh\OneDrive\Desktop\GodsIMiJ AI Solutions\Nancy & Kodii SERVER"
    dest_dir = r"D:\highlight_chat\scripts"
    
    # Create backup of existing files
    backup_dir = os.path.join("D:", "backup", "scripts_backup", datetime.now().strftime("%Y%m%d_%H%M%S"))
    os.makedirs(backup_dir, exist_ok=True)
    
    # Create destination directory
    os.makedirs(dest_dir, exist_ok=True)
    
    print("🎵 Moving scripts to D drive 🎵")
    
    # List of files to move
    files_to_move = [
        "check_drive_space.py",
        "create_directories.py",
        "create_highlight_memory_structure.py",
        "initialize_memory_files.py",
        "multi_drive_manager.py",
        "setup_memory_backup.py",
        "setup_memory_backup_system.py",
        "setup_model_system.py",
        "setup_ollama_manager.py",
        "setup_venv.py",
        "SKYNET_SERVER.py",
        "test_models.py",
        "verify_system.py"
    ]
    
    moved_files = []
    for file in files_to_move:
        source_file = os.path.join(source_dir, file)
        dest_file = os.path.join(dest_dir, file)
        backup_file = os.path.join(backup_dir, file)
        
        try:
            # Backup first if file exists in destination
            if os.path.exists(dest_file):
                shutil.copy2(dest_file, backup_file)
            
            # Move the file
            shutil.copy2(source_file, dest_file)
            moved_files.append(file)
            print(f"Moved: {file}")
            
        except Exception as e:
            print(f"Error moving {file}: {str(e)}")
    
    print(f"\n✅ Moved {len(moved_files)} files to {dest_dir}")
    print(f"📦 Backup created at: {backup_dir}")

if __name__ == "__main__":
    try:
        move_scripts_to_d()
        print("\n🚀 All scripts moved to D drive! Ready to run from new location!")
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
