import os
import json

def create_ollama_manager():
    base_path = "D:/highlight_chat/system"
    
    ollama_config = {
        "model_management": {
            "auto_load": [
                "llama-3.2",
                "deepseek-coder-v2",
                "llama-3.2-vision"
            ],
            "load_order": {
                "1": "llama-3.2",
                "2": "deepseek-coder-v2",
                "3": "llama-3.2-vision"
            },
            "resource_limits": {
                "max_ram_usage": "80%",
                "gpu_allocation": "dynamic"
            }
        },
        "api_endpoints": {
            "main": "http://localhost:11434",
            "backup": "http://localhost:11435"
        },
        "performance_monitoring": {
            "enable_logging": True,
            "memory_threshold": 85,
            "auto_optimize": True
        }
    }
    
    # Create Ollama management directory
    ollama_path = os.path.join(base_path, "ollama_management")
    os.makedirs(ollama_path, exist_ok=True)
    
    # Save Ollama configuration
    config_path = os.path.join(ollama_path, "ollama_config.json")
    with open(config_path, 'w') as f:
        json.dump(ollama_config, f, indent=4)
    
    print("🔥 Ollama management system configured!")
    return True

if __name__ == "__main__":
    try:
        create_ollama_manager()
        print("\n🚀 Ready to run multiple models! Let's get this party started!")
    except Exception as e:
        print(f"Error setting up Ollama manager: {str(e)}")
