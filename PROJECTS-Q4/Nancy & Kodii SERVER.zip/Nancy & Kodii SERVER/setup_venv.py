import os
import subprocess
import sys

def setup_virtual_environment():
    # Set paths
    base_dir = "D:/highlight_chat"
    venv_path = os.path.join(base_dir, "venv")
    
    print("🎵 Setting up Virtual Environment 🎵")
    
    try:
        # Create base directory if it doesn't exist
        os.makedirs(base_dir, exist_ok=True)
        
        # Create virtual environment
        print("\nCreating virtual environment...")
        subprocess.run([sys.executable, "-m", "venv", venv_path], check=True)
        
        # Get the pip path in the new venv
        if os.name == 'nt':  # Windows
            pip_path = os.path.join(venv_path, "Scripts", "pip")
            activate_path = os.path.join(venv_path, "Scripts", "activate")
        else:  # Unix/Linux
            pip_path = os.path.join(venv_path, "bin", "pip")
            activate_path = os.path.join(venv_path, "bin", "activate")
        
        # Install required packages
        print("\nInstalling required packages...")
        requirements = [
            "requests",
            "numpy",
            "pandas",
            "torch",
            "transformers",
            "ollama",
            "pillow",
            "python-dotenv"
        ]
        
        for package in requirements:
            subprocess.run([pip_path, "install", package], check=True)
            print(f"Installed {package}")
        
        print("\n✅ Virtual environment setup complete!")
        print(f"\nTo activate the environment:")
        print(f"Windows: {activate_path}")
        print("\nThen you can run the model setup scripts!")
        
    except Exception as e:
        print(f"\n❌ Error setting up virtual environment: {str(e)}")

if __name__ == "__main__":
    setup_virtual_environment()
