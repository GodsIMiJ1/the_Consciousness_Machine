import shutil
import os

def check_drive_space():
    drive_path = "D:\\"
    
    # Get drive stats
    total, used, free = shutil.disk_usage(drive_path)
    
    # Convert to GB for readable format
    total_gb = total // (2**30)
    used_gb = used // (2**30)
    free_gb = free // (2**30)
    
    print(f"🎵 D Drive Space Check 🎵")
    print(f"Total: {total_gb} GB")
    print(f"Used: {used_gb} GB")
    print(f"Free: {free_gb} GB")
    
    # Check if we have enough space (200GB minimum recommended)
    if free_gb >= 200:
        print("\n✅ You've got enough space to run all models!")
    else:
        print(f"\n⚠️ You might need more space for all models.")
        print(f"Recommended: 200GB free")
        print(f"Current free space: {free_gb}GB")

if __name__ == "__main__":
    check_drive_space()
