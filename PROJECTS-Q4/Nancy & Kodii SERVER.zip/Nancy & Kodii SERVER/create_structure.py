import os

def create_project_structure():
    base_dir = "D:/highlight_chat/scripts"
    
    # All directories to create
    directories = [
        "core",
        "core/security",
        "core/security/encryption",
        "core/security/monitoring",
        "core/security/defense",
        "core/system",
        "core/system/setup",
        "core/system/config",
        "core/system/utils",
        "core/models",
        "core/models/management",
        "core/models/testing",
        "core/models/configs",
        "scripts",
        "scripts/setup",
        "scripts/security",
        "scripts/models",
        "scripts/utils",
        "tests",
        "tests/security",
        "tests/models",
        "tests/system",
        "docs",
        "docs/setup",
        "docs/api",
        "docs/guides",
        "backup",
        "backup/scripts",
        "backup/configs",
        "backup/logs"
    ]
    
    for dir_path in directories:
        full_path = os.path.join(base_dir, dir_path)
        try:
            os.makedirs(full_path, exist_ok=True)
            print(f"Created: {full_path}")
        except Exception as e:
            print(f"Error creating {full_path}: {str(e)}")

if __name__ == "__main__":
    create_project_structure()
